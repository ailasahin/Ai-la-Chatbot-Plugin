<?php
/**
 * Plugin Name: Ai-la
 * Description: WordPress için AI admin assistant popup arayüzü.
 * Version: 2.4.9
 * Author: Ai-la
 * Text Domain: ai-la
 */

if (!defined('ABSPATH')) {
    exit;
}

define('AILA_VERSION', '2.4.9');
define('AILA_PLUGIN_URL', plugin_dir_url(__FILE__));

// --- Hooks ---
add_action('admin_enqueue_scripts', 'aila_enqueue_assets');
add_action('admin_footer', 'aila_render_popup');
add_action('wp_ajax_aila_query', 'aila_handle_query');
add_action('admin_menu', 'aila_admin_menu');
add_action('admin_bar_menu', 'aila_admin_bar_item', 100);
add_action('admin_init', 'aila_register_settings');
register_activation_hook(__FILE__, 'aila_set_defaults');

// Ön yüz ve önizleme için — sadece manage_options yetkisi olanlara
// NOT: Sadece admin panelinde göster, ön yüzde değil
add_action('customize_preview_init', 'aila_enqueue_frontend');

function aila_enqueue_frontend() {
    if (!current_user_can('manage_options')) return;
    wp_enqueue_style('aila-popup-style', AILA_PLUGIN_URL . 'assets/css/aila-popup.css', array(), AILA_VERSION);
    wp_add_inline_style('aila-popup-style', '
        #ailaOverlay { background: #ffffff !important; color: #111827 !important; border-color: #e5e7eb !important; }
        #ailaOverlay .panel-header { background: #ffffff !important; border-color: #f3f4f6 !important; }
        #ailaOverlay .panel-body { background: #ffffff !important; }
        #ailaOverlay .message.bot { background: #ffffff !important; color: #111827 !important; }
        #ailaOverlay .composer-wrap { background: #ffffff !important; }
        #ailaOverlay .composer { background: #ffffff !important; border-color: #e5e7eb !important; }
        #ailaOverlay .composer textarea { color: #111827 !important; background: transparent !important; }
        #ailaOverlay .title { color: #111827 !important; }
        #ailaOverlay .result-card { background: #fafafa !important; }
        #ailaOverlay .quick { background: #ffffff !important; color: #374151 !important; }
    ');
    wp_enqueue_script('aila-popup-script', AILA_PLUGIN_URL . 'assets/js/aila-popup.js', array(), AILA_VERSION, true);
    wp_localize_script('aila-popup-script', 'ailaData', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('aila_nonce'),
        'hasAI'   => !empty(aila_get_gemini_key()),
    ));
}

function aila_render_frontend() {
    if (!current_user_can('manage_options')) return;
    aila_render_popup();
}

function aila_set_defaults() {
    // Defaults artık boş — kullanıcı kendi key'lerini girer
}

function aila_get_gemini_key() {
    return get_option('aila_gemini_key', '');
}

// --- Settings ---
function aila_admin_menu() {
    add_options_page('Ai-la Ayarları', 'Ai-la', 'manage_options', 'ai-la-settings', 'aila_settings_page');
}

function aila_admin_bar_item($wp_admin_bar) {
    if (!current_user_can('manage_options')) return;
    $wp_admin_bar->add_node(array(
        'id'    => 'aila-bar',
        'title' => '✦ Ai-la',
        'href'  => '#',
        'meta'  => array(
            'onclick' => 'document.getElementById("ailaOverlay").classList.toggle("open"); return false;',
            'title'   => 'Ai-la\'yı aç',
        ),
    ));
}

function aila_register_settings() {
    register_setting('aila_settings_group', 'aila_gemini_key', array(
        'sanitize_callback' => 'sanitize_text_field',
    ));
}

function aila_settings_page() {
    if (!current_user_can('manage_options')) return;
    $groq_key     = get_option('aila_gemini_key', '');
    $has_groq     = !empty($groq_key);
    ?>
    <div class="wrap">
    <style>
    /* ── Ai-la Settings — Modern Dark ── */
    .aila-set{max-width:860px;margin-top:16px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
    .aila-set *{box-sizing:border-box}

    /* Hero header */
    .aila-set-hero{
        background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);
        border-radius:24px;padding:32px 36px;margin-bottom:20px;
        display:flex;align-items:center;justify-content:space-between;
        position:relative;overflow:hidden;
    }
    .aila-set-hero::before{
        content:'';position:absolute;top:-60px;right:-60px;
        width:220px;height:220px;border-radius:50%;
        background:radial-gradient(circle,rgba(236,72,153,.25),transparent 70%);
    }
    .aila-set-hero-left{display:flex;align-items:center;gap:18px;position:relative}
    .aila-set-logo{
        width:56px;height:56px;border-radius:18px;
        background:linear-gradient(135deg,#ec4899,#be185d);
        display:grid;place-items:center;color:#fff;font-size:26px;font-weight:800;
        box-shadow:0 12px 30px rgba(236,72,153,.4);
    }
    .aila-set-title{margin:0;font-size:26px;font-weight:800;letter-spacing:-.03em;color:#fff}
    .aila-set-sub{margin:4px 0 0;color:#94a3b8;font-size:13px}
    .aila-set-ver{
        background:rgba(236,72,153,.15);border:1px solid rgba(236,72,153,.3);
        color:#f9a8d4;padding:6px 16px;border-radius:999px;font-size:13px;font-weight:600;
        position:relative;
    }

    /* Status cards */
    .aila-status-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:20px}
    .aila-stat{
        background:linear-gradient(135deg,#fff 0%,#fdf4ff 100%);
        border:1px solid #f3e8ff;border-radius:16px;padding:18px 20px;
        transition:transform .15s,box-shadow .15s;
    }
    .aila-stat:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(236,72,153,.1)}
    .aila-stat-label{font-size:11px;color:#9ca3af;font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px}
    .aila-badge{display:inline-flex;align-items:center;gap:6px;padding:5px 14px;border-radius:999px;font-size:13px;font-weight:700}
    .aila-badge.on{background:linear-gradient(135deg,#dcfce7,#bbf7d0);color:#166534;box-shadow:0 2px 8px rgba(22,163,74,.15)}
    .aila-badge.off{background:linear-gradient(135deg,#fef3c7,#fde68a);color:#92400e}
    .aila-stat-val{font-size:22px;font-weight:800;color:#111827;letter-spacing:-.02em;background:linear-gradient(135deg,#ec4899,#be185d);-webkit-background-clip:text;-webkit-text-fill-color:transparent}

    /* Sections */
    .aila-section{
        background:#fff;border:1px solid #f0e6ff;border-radius:20px;
        padding:24px 28px;margin-bottom:16px;
        box-shadow:0 2px 12px rgba(139,92,246,.06);
        transition:box-shadow .2s;
    }
    .aila-section:hover{box-shadow:0 4px 20px rgba(236,72,153,.08)}
    .aila-section-title{
        font-size:15px;font-weight:700;color:#111827;
        margin:0 0 20px;padding-bottom:14px;
        border-bottom:2px solid;
        border-image:linear-gradient(90deg,#ec4899,#8b5cf6,transparent) 1;
        display:flex;align-items:center;gap:8px;
    }
    .aila-field{margin-bottom:18px}
    .aila-field:last-child{margin-bottom:0}
    .aila-field label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:6px}
    .aila-field input[type=text],.aila-field input[type=password]{
        width:100%;max-width:480px;padding:10px 14px;
        border:2px solid #e5e7eb;border-radius:12px;
        font-size:14px;color:#111827;
        transition:border-color .15s,box-shadow .15s;
        background:#fafafa;
    }
    .aila-field input:focus{outline:none;border-color:#ec4899;box-shadow:0 0 0 3px rgba(236,72,153,.1);background:#fff}
    .aila-field .desc{font-size:12px;color:#9ca3af;margin-top:6px;line-height:1.5}
    .aila-field .desc a{color:#ec4899;text-decoration:none;font-weight:600}

    /* Buttons */
    .aila-save{
        background:linear-gradient(135deg,#ec4899,#be185d);color:#fff;border:none;
        padding:12px 28px;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;
        box-shadow:0 8px 20px rgba(236,72,153,.3);transition:transform .15s,box-shadow .15s;
    }
    .aila-save:hover{transform:translateY(-2px);box-shadow:0 12px 28px rgba(236,72,153,.4)}
    .aila-test-btn{
        background:linear-gradient(135deg,#f3f4f6,#e5e7eb);color:#374151;
        border:2px solid #e5e7eb;padding:10px 22px;border-radius:12px;
        font-size:13px;font-weight:700;cursor:pointer;transition:all .15s;
    }
    .aila-test-btn:hover{background:linear-gradient(135deg,#ec4899,#be185d);color:#fff;border-color:transparent;box-shadow:0 8px 20px rgba(236,72,153,.3)}
    .aila-test-result{margin-top:14px;padding:14px 18px;border-radius:14px;font-size:13px;display:none;line-height:1.6}
    .aila-test-result.ok{background:linear-gradient(135deg,#f0fdf4,#dcfce7);border:1px solid #86efac;color:#166534}
    .aila-test-result.err{background:linear-gradient(135deg,#fef2f2,#fee2e2);border:1px solid #fca5a5;color:#991b1b}
    @media(max-width:640px){.aila-status-row{grid-template-columns:1fr}.aila-set-hero{flex-direction:column;gap:16px;text-align:center}}
    </style>

    <div class="aila-set">
        <div class="aila-set-hero">
            <div class="aila-set-hero-left">
                <div class="aila-set-logo">✦</div>
                <div>
                    <h1 class="aila-set-title">Ai-la</h1>
                    <p class="aila-set-sub">WordPress AI Admin Assistant</p>
                </div>
            </div>
            <div class="aila-set-ver">v<?php echo esc_html(AILA_VERSION); ?></div>
        </div>

        <div class="aila-status-row" style="grid-template-columns:repeat(2,1fr)">
            <div class="aila-stat">
                <div class="aila-stat-label">AI Modu</div>
                <div class="aila-badge <?php echo $has_groq ? 'on' : 'off'; ?>">
                    <?php echo $has_groq ? '✓ Groq Aktif' : '⚠ Keyword Modu'; ?>
                </div>
            </div>
            <div class="aila-stat">
                <div class="aila-stat-label">Versiyon</div>
                <div class="aila-stat-val"><?php echo esc_html(AILA_VERSION); ?></div>
            </div>
        </div>

        <form method="post" action="options.php">
            <?php settings_fields('aila_settings_group'); ?>

            <div class="aila-section">
                <div class="aila-section-title">🤖 Groq AI</div>
                <div class="aila-field">
                    <label>Groq API Key</label>
                    <input type="password" name="aila_gemini_key" value="<?php echo esc_attr($groq_key); ?>" placeholder="gsk_..." autocomplete="new-password" />
                    <div class="desc">Ücretsiz key almak için → <a href="https://console.groq.com/keys" target="_blank">console.groq.com/keys</a><br>Boş bırakırsanız keyword modu çalışır.</div>
                </div>
            </div>

            <button type="submit" class="aila-save">Kaydet</button>
        </form>

        <div class="aila-section" style="margin-top:18px">
            <div class="aila-section-title">🧪 Bağlantı Testi</div>
            <p style="font-size:13px;color:#6b7280;margin:0 0 14px">Groq API bağlantısını test etmek için butona tıklayın.</p>
            <button id="aila-test-btn" class="aila-test-btn" type="button">Groq'u Test Et</button>
            <div id="aila-test-result" class="aila-test-result"></div>
        </div>
    </div>

    <script>
    document.getElementById('aila-test-btn').addEventListener('click', function(){
        var btn = this;
        var result = document.getElementById('aila-test-result');
        btn.disabled = true;
        btn.textContent = 'Test ediliyor...';
        result.style.display = 'none';
        result.className = 'aila-test-result';

        var body = new URLSearchParams();
        body.append('action', 'aila_query');
        body.append('nonce', '<?php echo esc_js(wp_create_nonce('aila_nonce')); ?>');
        body.append('query', 'bana kısa bir WordPress ipucu ver');

        fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: body.toString()
        })
        .then(r => r.json())
        .then(data => {
            result.style.display = 'block';
            if (data.source === 'Groq AI') {
                result.classList.add('ok');
                result.innerHTML = '<strong>✓ Groq bağlantısı başarılı!</strong><br>' + (data.message || '');
            } else {
                result.classList.add('err');
                result.innerHTML = '<strong>⚠ Groq\'a ulaşılamadı.</strong> Keyword modu çalışıyor.<br>Cevap: ' + (data.message || '');
            }
        })
        .catch(e => {
            result.style.display = 'block';
            result.classList.add('err');
            result.innerHTML = '<strong>✗ Hata:</strong> ' + e.message;
        })
        .finally(() => {
            btn.disabled = false;
            btn.textContent = 'Groq\'u Test Et';
        });
    });
    </script>
    </div>
    <?php
}

// --- Enqueue ---
function aila_enqueue_assets() {
    if (!current_user_can('manage_options')) return;

    wp_enqueue_style('aila-popup-style', AILA_PLUGIN_URL . 'assets/css/aila-popup.css', array(), AILA_VERSION);
    // Inline override — sunucu cache sorunlarına karşı
    wp_add_inline_style('aila-popup-style', '
        #ailaOverlay { background: #ffffff !important; color: #111827 !important; border-color: #e5e7eb !important; }
        #ailaOverlay .panel-header { background: #ffffff !important; border-color: #f3f4f6 !important; }
        #ailaOverlay .panel-body { background: #ffffff !important; }
        #ailaOverlay .message.bot { background: #ffffff !important; color: #111827 !important; }
        #ailaOverlay .composer-wrap { background: #ffffff !important; }
        #ailaOverlay .composer { background: #ffffff !important; border-color: #e5e7eb !important; }
        #ailaOverlay .composer textarea { color: #111827 !important; background: transparent !important; }
        #ailaOverlay .title { color: #111827 !important; }
        #ailaOverlay .result-card { background: #fafafa !important; }
        #ailaOverlay .quick { background: #ffffff !important; color: #374151 !important; }
    ');
    wp_enqueue_script('aila-popup-script', AILA_PLUGIN_URL . 'assets/js/aila-popup.js', array(), AILA_VERSION, true);

    wp_localize_script('aila-popup-script', 'ailaData', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('aila_nonce'),
        'hasAI'   => true,
    ));
}

// --- Popup HTML ---
function aila_render_popup() {
    if (!current_user_can('manage_options')) return;
    ?>
    <button class="aila-launcher" id="openAila" type="button" aria-label="Ai-la aç">
        <div class="launcher-mark">✦</div>
        <span>Ai-la'ya sor</span>
    </button>

    <div class="overlay" id="ailaOverlay" role="dialog" aria-modal="true" aria-labelledby="ailaTitle">
        <div class="panel-header">
            <div class="title-wrap">
                <div class="logo">✦</div>
                <div>
                    <h2 class="title" id="ailaTitle">Ai-la</h2>
                    <p class="subtitle">WordPress AI admin assistant</p>
                </div>
            </div>
            <div class="header-actions">
                <button class="icon-btn" id="ailaNewChat" type="button" title="Geçmişi sil">🗑</button>
                <button class="icon-btn" id="closeAila" type="button" title="Küçült">⌄</button>
            </div>
        </div>

        <div class="panel-body" id="ailaMessages">
            <div class="row">
                <div class="message bot">
                    <div class="bot-head">
                        <div class="bot-mini">✦</div>
                        <div>Ai-la</div>
                    </div>
                    Merhaba! 👋 Bugün size nasıl yardımcı olabilirim?
                    <div class="quick-row">
                        <button class="quick" type="button" data-query="logo değiştir">🖼 Logo</button>
                        <button class="quick" type="button" data-query="woocommerce sipariş">🛒 WooCommerce</button>
                        <button class="quick" type="button" data-query="yoast seo ayarları">🔍 SEO</button>
                        <button class="quick" type="button" data-query="elementor düzenleme">✏️ Elementor</button>
                        <button class="quick" type="button" data-query="menü ayarları">☰ Menü</button>
                        <button class="quick" type="button" data-query="kullanıcı yetkileri">👤 Yetkiler</button>
                    </div>
                </div>
            </div>

            <div class="row" id="ailaTypingRow" style="display:none;">
                <div class="message bot">
                    <div class="bot-head">
                        <div class="bot-mini">✦</div>
                        <div>Ai-la</div>
                    </div>
                    <div class="typing"><span></span><span></span><span></span></div>
                </div>
            </div>
        </div>

        <div class="composer-wrap">
            <div class="composer">
                <textarea id="ailaPrompt" placeholder="Sorunuzu yazın..." maxlength="500"></textarea>
                <div class="composer-bottom">
                    <div class="note">Yapay zeka yanlış bilgi üretebilir</div>
                    <button class="send" id="ailaSend" type="button">↑</button>
                </div>
            </div>
            <div class="footer-note">Ai-la v<?php echo esc_html(AILA_VERSION); ?> · AI destekli</div>
        </div>
    </div>
    <?php
}

// --- AJAX Handler ---
function aila_handle_query() {
    if (!current_user_can('manage_options')) {
        wp_send_json(array('success' => false, 'message' => 'Yetkiniz yok.'), 403);
    }

    check_ajax_referer('aila_nonce', 'nonce');

    $raw_query   = isset($_POST['query'])        ? sanitize_text_field(wp_unslash($_POST['query']))        : '';
    $current_url = isset($_POST['current_url'])  ? esc_url_raw(wp_unslash($_POST['current_url']))          : '';
    $current_page= isset($_POST['current_page']) ? sanitize_text_field(wp_unslash($_POST['current_page'])) : '';
    $query = trim($raw_query);

    if ($query === '') {
        wp_send_json(array(
            'success'     => false,
            'message'     => 'Lütfen bir soru yazın.',
            'suggestions' => array('logo değiştir', 'footer düzenle', 'menü ayarları', 'kullanıcı yetkileri'),
        ));
    }

    $gemini_key = aila_get_gemini_key();

    if (!empty($gemini_key)) {
        $result = aila_ask_groq($query, $gemini_key, $current_url, $current_page);
    } else {
        $result = aila_keyword_fallback($query);
    }

    wp_send_json($result);
}

// --- Groq AI ---
function aila_ask_groq($query, $api_key, $current_url = '', $current_page = '') {
    $wp_version   = get_bloginfo('version');
    $site_url     = get_site_url();
    $locale       = get_locale();
    $active_theme = wp_get_theme()->get('Name');

    $active_plugins = array();
    $plugins = get_option('active_plugins', array());
    foreach (array_slice($plugins, 0, 20) as $p) {
        $parts = explode('/', $p);
        $active_plugins[] = $parts[0];
    }
    $plugins_str = implode(', ', $active_plugins);

    $system_prompt = 'Sen Ai-la adında bir WordPress admin asistanısın. Samimi, yardımsever ve net cevaplar verirsin.

Site Bağlamı:
- WordPress: ' . $wp_version . ' | Tema: ' . $active_theme . ' | Dil: ' . $locale . '
- Eklentiler: ' . ($plugins_str ?: 'bilinmiyor') . '
- PHP: ' . PHP_VERSION . '
' . (!empty($current_url)  ? '- Kullanıcının bulunduğu sayfa: ' . $current_url  . "\n" : '')
. (!empty($current_page) ? '- Sayfa başlığı: ' . $current_page . "\n" : '') . '
Görevin: WordPress kullanıcılarına yardımcı olmak. Bulunduğu sayfaya göre adım adım yönlendir. Sohbet sorularına samimi cevap ver.

Her zaman JSON döndür:
- Yönlendirme: {"success":true,"title":"Sayfa","url_path":"options-general.php","message":"Açıklama","category":"Kategori","confidence":90}
- Bilgi/sohbet: {"success":false,"message":"Cevap","suggestions":["konu1","konu2"]}

Kurallar: Sadece JSON. Türkçeye Türkçe cevap. Sohbete samimi ve kısa cevap ver. ASLA "Merhaba ben Ai-la" veya kendini tanıtan bir giriş cümlesi yazma. Direkt soruya veya bağlama göre cevap ver.';

    $body = array(
        'model'    => 'llama-3.3-70b-versatile',
        'messages' => array(
            array('role' => 'system',  'content' => $system_prompt),
            array('role' => 'user',    'content' => $query),
        ),
        'temperature'  => 0.1,
        'max_tokens'   => 512,
        'response_format' => array('type' => 'json_object'),
    );

    $response = wp_remote_post(
        'https://api.groq.com/openai/v1/chat/completions',
        array(
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ),
            'body'    => wp_json_encode($body),
            'timeout' => 20,
        )
    );

    if (is_wp_error($response)) {
        return aila_keyword_fallback($query);
    }

    $code = wp_remote_retrieve_response_code($response);
    if ($code !== 200) {
        return aila_keyword_fallback($query);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    $text = isset($data['choices'][0]['message']['content'])
        ? trim($data['choices'][0]['message']['content'])
        : '';

    $text = preg_replace('/^```(?:json)?\s*/i', '', $text);
    $text = preg_replace('/\s*```$/', '', $text);
    $text = trim($text);

    $parsed = json_decode($text, true);

    if (!is_array($parsed)) {
        if (!empty($text)) {
            return array('success' => false, 'message' => $text, 'suggestions' => array());
        }
        return aila_keyword_fallback($query);
    }

    if (!empty($parsed['url_path'])) {
        $parsed['url'] = admin_url($parsed['url_path']);
        unset($parsed['url_path']);
    }

    if (empty($parsed['confidence'])) $parsed['confidence'] = 92;
    if (empty($parsed['source']))     $parsed['source']     = 'Groq AI';
    if (!isset($parsed['suggestions'])) $parsed['suggestions'] = array();

    return $parsed;
}

// --- Keyword Fallback ---
function aila_keyword_fallback($query) {
    $q = strtolower(trim($query));
    if (function_exists('remove_accents')) {
        $q = remove_accents($q);
    }

    // Eklenti kurulum kontrolü için yardımcı
    if (!function_exists('is_plugin_active')) {
        include_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $routes = array(
        // --- Temel WordPress ---
        array('keywords' => array('logo', 'site kimligi', 'favicon', 'ikon', 'site icon', 'site identity'), 'title' => 'Görünüm → Özelleştir → Site Kimliği', 'url' => admin_url('customize.php'), 'confidence' => 94, 'category' => 'Tema', 'source' => 'WordPress Özelleştirici', 'message' => 'Logo, site simgesi ve temel marka ayarları burada bulunur.'),
        array('keywords' => array('footer', 'alt bilgi', 'altbilgi', 'copyright'), 'title' => 'Görünüm → Bileşenler', 'url' => admin_url('widgets.php'), 'confidence' => 86, 'category' => 'Footer', 'source' => 'Tema alanı', 'message' => 'Footer alanı tema ayarları veya bileşenler ekranında bulunur.'),
        array('keywords' => array('menu', 'menü', 'navigasyon', 'ana menu', 'navigation', 'nav menu'), 'title' => 'Görünüm → Menüler', 'url' => admin_url('nav-menus.php'), 'confidence' => 93, 'category' => 'Gezinme', 'source' => 'Menü yönetimi', 'message' => 'Menü oluşturma ve düzenleme ekranı.'),
        array('keywords' => array('kullanici', 'kullanıcı', 'yetki', 'rol', 'editor', 'author', 'administrator', 'user', 'users', 'role', 'permission'), 'title' => 'Kullanıcılar → Tüm Kullanıcılar', 'url' => admin_url('users.php'), 'confidence' => 95, 'category' => 'Kullanıcı', 'source' => 'Rol yönetimi', 'message' => 'Kullanıcı rolleri ve yetkiler bu ekrandan yönetilir.'),
        array('keywords' => array('eklenti', 'plugin', 'pluginler', 'plugins'), 'title' => 'Eklentiler', 'url' => admin_url('plugins.php'), 'confidence' => 91, 'category' => 'Sistem', 'source' => 'Eklenti yönetimi', 'message' => 'Eklenti yükleme, etkinleştirme ve kapatma işlemleri burada yapılır.'),
        array('keywords' => array('tema', 'theme', 'gorunum', 'görünüm', 'appearance', 'themes'), 'title' => 'Görünüm → Temalar', 'url' => admin_url('themes.php'), 'confidence' => 88, 'category' => 'Tema', 'source' => 'Tema yönetimi', 'message' => 'Tema seçimi ve görünüm yönetimi.'),
        array('keywords' => array('sayfa', 'page', 'anasayfa', 'pages'), 'title' => 'Sayfalar', 'url' => admin_url('edit.php?post_type=page'), 'confidence' => 88, 'category' => 'İçerik', 'source' => 'Sayfa yönetimi', 'message' => 'Sabit sayfalar bu ekranda yönetilir.'),
        array('keywords' => array('yazi', 'yazı', 'post', 'blog', 'icerik', 'içerik', 'posts'), 'title' => 'Yazılar', 'url' => admin_url('edit.php'), 'confidence' => 86, 'category' => 'İçerik', 'source' => 'Yazı yönetimi', 'message' => 'Blog yazıları bu ekranda yönetilir.'),
        array('keywords' => array('medya', 'gorsel', 'görsel', 'resim', 'upload', 'media', 'image', 'images'), 'title' => 'Ortam Kütüphanesi', 'url' => admin_url('upload.php'), 'confidence' => 89, 'category' => 'Medya', 'source' => 'Medya yönetimi', 'message' => 'Görseller ve yüklenen dosyalar burada bulunur.'),
        array('keywords' => array('ayar', 'settings', 'genel', 'site basligi', 'site başlığı', 'general settings', 'site title'), 'title' => 'Ayarlar → Genel', 'url' => admin_url('options-general.php'), 'confidence' => 90, 'category' => 'Ayarlar', 'source' => 'Genel ayarlar', 'message' => 'Site başlığı, slogan ve temel ayarlar burada yer alır.'),
        array('keywords' => array('yorum', 'comment', 'spam', 'comments'), 'title' => 'Yorumlar', 'url' => admin_url('edit-comments.php'), 'confidence' => 90, 'category' => 'İçerik', 'source' => 'Yorum yönetimi', 'message' => 'Yorum onaylama, silme ve spam yönetimi burada yapılır.'),
        array('keywords' => array('kalici baglanti', 'kalıcı bağlantı', 'permalink', 'slug', 'url yapisi', 'url yapısı', 'permalinks', 'url structure'), 'title' => 'Ayarlar → Kalıcı Bağlantılar', 'url' => admin_url('options-permalink.php'), 'confidence' => 92, 'category' => 'Ayarlar', 'source' => 'Permalink ayarları', 'message' => 'URL yapısı ve kalıcı bağlantı ayarları burada değiştirilir.'),
        array('keywords' => array('widget', 'bileşen', 'bilesen', 'kenar cubugu', 'kenar çubuğu', 'sidebar', 'widgets'), 'title' => 'Görünüm → Bileşenler', 'url' => admin_url('widgets.php'), 'confidence' => 91, 'category' => 'Görünüm', 'source' => 'Widget yönetimi', 'message' => 'Kenar çubuğu ve footer widget alanları burada düzenlenir.'),
        array('keywords' => array('guncelleme', 'güncelleme', 'update', 'wordpress surumu', 'wordpress sürümü', 'updates', 'upgrade'), 'title' => 'Gösterge Paneli → Güncellemeler', 'url' => admin_url('update-core.php'), 'confidence' => 93, 'category' => 'Sistem', 'source' => 'Güncelleme yönetimi', 'message' => 'WordPress, tema ve eklenti güncellemeleri burada yapılır.'),
        array('keywords' => array('okuma', 'reading', 'on sayfa', 'ön sayfa', 'blog sayfasi', 'blog sayfası', 'homepage', 'front page', 'reading settings'), 'title' => 'Ayarlar → Okuma', 'url' => admin_url('options-reading.php'), 'confidence' => 91, 'category' => 'Ayarlar', 'source' => 'Okuma ayarları', 'message' => 'Ön sayfa ve blog sayfası ayarları burada yapılır.'),
        array('keywords' => array('menu', 'menü', 'navigasyon', 'ana menu'), 'title' => 'Görünüm → Menüler', 'url' => admin_url('nav-menus.php'), 'confidence' => 93, 'category' => 'Gezinme', 'source' => 'Menü yönetimi', 'message' => 'Menü oluşturma ve düzenleme ekranı.', 'next_steps' => array('Sol taraftan eklemek istediğin sayfaları/linkleri seç', '"Menüye Ekle" butonuna tıkla', 'Menü öğelerini sürükleyerek sırala', 'Alt menü için öğeyi sağa kaydır', '"Menüyü Kaydet" butonuna bas')),
        array('keywords' => array('kullanici', 'kullanıcı', 'yetki', 'rol', 'editor', 'author', 'administrator'), 'title' => 'Kullanıcılar → Tüm Kullanıcılar', 'url' => admin_url('users.php'), 'confidence' => 95, 'category' => 'Kullanıcı', 'source' => 'Rol yönetimi', 'message' => 'Kullanıcı rolleri ve yetkiler bu ekrandan yönetilir.', 'next_steps' => array('Yeni kullanıcı eklemek için "Yeni Ekle" butonuna tıkla', 'Kullanıcı adı, e-posta ve şifre gir', '"Rol" açılır menüsünden uygun rolü seç (Editör, Yazar, Abone vb.)', '"Yeni Kullanıcı Ekle" butonuna bas')),
        array('keywords' => array('eklenti', 'plugin', 'pluginler'), 'title' => 'Eklentiler', 'url' => admin_url('plugins.php'), 'confidence' => 91, 'category' => 'Sistem', 'source' => 'Eklenti yönetimi', 'message' => 'Eklenti yükleme, etkinleştirme ve kapatma işlemleri burada yapılır.', 'next_steps' => array('Yeni eklenti yüklemek için "Yeni Ekle" butonuna tıkla', 'Arama kutusuna eklenti adını yaz', '"Şimdi Yükle" butonuna bas', 'Yükleme tamamlanınca "Etkinleştir"e tıkla')),
        array('keywords' => array('tema', 'theme', 'gorunum', 'görünüm'), 'title' => 'Görünüm → Temalar', 'url' => admin_url('themes.php'), 'confidence' => 88, 'category' => 'Tema', 'source' => 'Tema yönetimi', 'message' => 'Tema seçimi ve görünüm yönetimi.', 'next_steps' => array('Yeni tema yüklemek için "Yeni Ekle" butonuna tıkla', 'Arama kutusuna tema adını yaz', '"Yükle" butonuna bas, ardından "Etkinleştir"e tıkla', 'Temayı özelleştirmek için "Özelleştir" butonunu kullan')),
        array('keywords' => array('sayfa', 'page', 'anasayfa'), 'title' => 'Sayfalar', 'url' => admin_url('edit.php?post_type=page'), 'confidence' => 88, 'category' => 'İçerik', 'source' => 'Sayfa yönetimi', 'message' => 'Sabit sayfalar bu ekranda yönetilir.', 'next_steps' => array('Yeni sayfa oluşturmak için "Yeni Ekle" butonuna tıkla', 'Sayfa başlığını gir', 'İçeriği Gutenberg blok editörüyle düzenle', 'Sağ panelden sayfa şablonunu seç', '"Yayınla" butonuna bas')),
        array('keywords' => array('yazi', 'yazı', 'post', 'blog', 'icerik', 'içerik'), 'title' => 'Yazılar', 'url' => admin_url('edit.php'), 'confidence' => 86, 'category' => 'İçerik', 'source' => 'Yazı yönetimi', 'message' => 'Blog yazıları bu ekranda yönetilir.', 'next_steps' => array('Yeni yazı için "Yeni Ekle" butonuna tıkla', 'Başlık ve içeriği gir', 'Sağ panelden kategori ve etiket seç', 'Öne çıkan görsel ekle', '"Yayınla" butonuna bas')),
        array('keywords' => array('medya', 'gorsel', 'görsel', 'resim', 'upload'), 'title' => 'Ortam Kütüphanesi', 'url' => admin_url('upload.php'), 'confidence' => 89, 'category' => 'Medya', 'source' => 'Medya yönetimi', 'message' => 'Görseller ve yüklenen dosyalar burada bulunur.'),
        array('keywords' => array('ayar', 'settings', 'genel', 'site basligi', 'site başlığı'), 'title' => 'Ayarlar → Genel', 'url' => admin_url('options-general.php'), 'confidence' => 90, 'category' => 'Ayarlar', 'source' => 'Genel ayarlar', 'message' => 'Site başlığı, slogan ve temel ayarlar burada yer alır.'),
        array('keywords' => array('yorum', 'comment', 'spam'), 'title' => 'Yorumlar', 'url' => admin_url('edit-comments.php'), 'confidence' => 90, 'category' => 'İçerik', 'source' => 'Yorum yönetimi', 'message' => 'Yorum onaylama, silme ve spam yönetimi burada yapılır.'),
        array('keywords' => array('kalici baglanti', 'kalıcı bağlantı', 'permalink', 'slug', 'url yapisi', 'url yapısı'), 'title' => 'Ayarlar → Kalıcı Bağlantılar', 'url' => admin_url('options-permalink.php'), 'confidence' => 92, 'category' => 'Ayarlar', 'source' => 'Permalink ayarları', 'message' => 'URL yapısı ve kalıcı bağlantı ayarları burada değiştirilir.'),
        array('keywords' => array('widget', 'bileşen', 'bilesen', 'kenar cubugu', 'kenar çubuğu', 'sidebar'), 'title' => 'Görünüm → Bileşenler', 'url' => admin_url('widgets.php'), 'confidence' => 91, 'category' => 'Görünüm', 'source' => 'Widget yönetimi', 'message' => 'Kenar çubuğu ve footer widget alanları burada düzenlenir.'),
        array('keywords' => array('guncelleme', 'güncelleme', 'update', 'wordpress surumu', 'wordpress sürümü'), 'title' => 'Gösterge Paneli → Güncellemeler', 'url' => admin_url('update-core.php'), 'confidence' => 93, 'category' => 'Sistem', 'source' => 'Güncelleme yönetimi', 'message' => 'WordPress, tema ve eklenti güncellemeleri burada yapılır.'),
        array('keywords' => array('okuma', 'reading', 'on sayfa', 'ön sayfa', 'blog sayfasi', 'blog sayfası'), 'title' => 'Ayarlar → Okuma', 'url' => admin_url('options-reading.php'), 'confidence' => 91, 'category' => 'Ayarlar', 'source' => 'Okuma ayarları', 'message' => 'Ön sayfa ve blog sayfası ayarları burada yapılır.'),

        // --- WooCommerce ---
        array('keywords' => array('woocommerce', 'woo', 'magaza', 'mağaza', 'e-ticaret', 'eticaret'), 'title' => 'WooCommerce → Genel Bakış', 'url' => admin_url('admin.php?page=wc-admin'), 'confidence' => 95, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'WooCommerce ana paneli. Satış istatistikleri ve genel bakış burada.'),
        array('keywords' => array('siparis', 'sipariş', 'order', 'satis', 'satış'), 'title' => 'WooCommerce → Siparişler', 'url' => admin_url('edit.php?post_type=shop_order'), 'confidence' => 95, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Tüm siparişleri görüntüleyip yönetebilirsiniz.'),
        array('keywords' => array('urun', 'ürün', 'product', 'stok', 'envanter'), 'title' => 'WooCommerce → Ürünler', 'url' => admin_url('edit.php?post_type=product'), 'confidence' => 94, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Ürün ekleme, düzenleme ve stok yönetimi burada yapılır.'),
        array('keywords' => array('kupon', 'indirim', 'coupon', 'kampanya'), 'title' => 'WooCommerce → Kuponlar', 'url' => admin_url('edit.php?post_type=shop_coupon'), 'confidence' => 93, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'İndirim kuponu oluşturma ve yönetimi burada yapılır.'),
        array('keywords' => array('odeme', 'ödeme', 'payment', 'kargo', 'shipping', 'vergi', 'tax'), 'title' => 'WooCommerce → Ayarlar', 'url' => admin_url('admin.php?page=wc-settings'), 'confidence' => 92, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Ödeme yöntemleri, kargo ve vergi ayarları burada yapılandırılır.'),
        array('keywords' => array('woo rapor', 'woocommerce rapor', 'satis raporu', 'satış raporu'), 'title' => 'WooCommerce → Raporlar', 'url' => admin_url('admin.php?page=wc-reports'), 'confidence' => 91, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Satış raporları ve istatistikler burada görüntülenir.'),

        // --- WooCommerce Detay ---
        array('keywords' => array('woo musteri', 'woocommerce müşteri', 'woo customer', 'musteri listesi', 'müşteri listesi'), 'title' => 'WooCommerce → Müşteriler', 'url' => admin_url('admin.php?page=wc-admin&path=/customers'), 'confidence' => 93, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Müşteri listesi, satın alma geçmişi ve müşteri detayları burada görüntülenir.'),
        array('keywords' => array('woo stok', 'woocommerce stok', 'stok yonetimi', 'stok yönetimi', 'envanter yonetimi'), 'title' => 'WooCommerce → Stok Ayarları', 'url' => admin_url('admin.php?page=wc-settings&tab=products&section=inventory'), 'confidence' => 93, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Stok takibi, düşük stok bildirimi ve envanter ayarları burada yapılandırılır.'),
        array('keywords' => array('woo kargo', 'woocommerce kargo', 'kargo bolge', 'kargo bölge', 'shipping zone'), 'title' => 'WooCommerce → Kargo Bölgeleri', 'url' => admin_url('admin.php?page=wc-settings&tab=shipping'), 'confidence' => 94, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Kargo bölgeleri, yöntemleri ve ücretleri burada yapılandırılır.'),
        array('keywords' => array('woo odeme yontemi', 'woocommerce ödeme yöntemi', 'stripe', 'paypal', 'iyzico', 'kapida odeme', 'kapıda ödeme'), 'title' => 'WooCommerce → Ödeme Yöntemleri', 'url' => admin_url('admin.php?page=wc-settings&tab=checkout'), 'confidence' => 94, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Ödeme yöntemleri (Stripe, PayPal, kapıda ödeme vb.) burada etkinleştirilir ve yapılandırılır.'),
        array('keywords' => array('woo vergi', 'woocommerce vergi', 'kdv', 'tax rate', 'vergi orani', 'vergi oranı'), 'title' => 'WooCommerce → Vergi Ayarları', 'url' => admin_url('admin.php?page=wc-settings&tab=tax'), 'confidence' => 93, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'KDV ve vergi oranları burada tanımlanır. Vergi sınıfları ve ülke bazlı oranlar ayarlanabilir.'),
        array('keywords' => array('woo e-posta', 'woocommerce eposta', 'woocommerce e-posta', 'siparis maili', 'sipariş maili', 'woo mail'), 'title' => 'WooCommerce → E-posta Ayarları', 'url' => admin_url('admin.php?page=wc-settings&tab=email'), 'confidence' => 93, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Sipariş onay, kargo bildirimi gibi otomatik e-postalar burada özelleştirilir.'),
        array('keywords' => array('woo urun kategorisi', 'woocommerce ürün kategorisi', 'urun etiketi', 'ürün etiketi', 'product category'), 'title' => 'WooCommerce → Ürün Kategorileri', 'url' => admin_url('edit-tags.php?taxonomy=product_cat&post_type=product'), 'confidence' => 92, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Ürün kategorileri ve etiketleri burada oluşturulur ve düzenlenir.'),
        array('keywords' => array('woo inceleme', 'woocommerce inceleme', 'urun yorumu', 'ürün yorumu', 'product review'), 'title' => 'WooCommerce → Ürün İncelemeleri', 'url' => admin_url('edit-comments.php?post_type=product'), 'confidence' => 91, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Ürün yorumları ve incelemeleri burada yönetilir.'),
        array('keywords' => array('woo sistem durumu', 'woocommerce sistem', 'woo status', 'woocommerce debug'), 'title' => 'WooCommerce → Sistem Durumu', 'url' => admin_url('admin.php?page=wc-status'), 'confidence' => 92, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'WooCommerce sistem bilgileri, PHP ayarları ve hata logları burada görüntülenir.'),
        array('keywords' => array('woo eklenti', 'woocommerce extension', 'woo uzantı', 'woocommerce uzantı'), 'title' => 'WooCommerce → Uzantılar', 'url' => admin_url('admin.php?page=wc-addons'), 'confidence' => 90, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'WooCommerce için ek eklentiler ve uzantılar burada bulunabilir.'),
        array('keywords' => array('woo hesabim', 'woocommerce hesabım', 'my account', 'musteri hesabi', 'müşteri hesabı'), 'title' => 'WooCommerce → Hesabım Sayfası', 'url' => admin_url('admin.php?page=wc-settings&tab=advanced'), 'confidence' => 91, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => '"Hesabım", "Sepet" ve "Ödeme" sayfaları WooCommerce → Ayarlar → Gelişmiş bölümünden yapılandırılır.'),

        // --- Jetpack ---
        array('keywords' => array('jetpack'), 'title' => 'Jetpack → Dashboard', 'url' => admin_url('admin.php?page=jetpack'), 'confidence' => 94, 'category' => 'Jetpack', 'source' => 'Jetpack', 'plugin' => 'jetpack/jetpack.php', 'plugin_name' => 'Jetpack', 'message' => 'Jetpack genel bakış ve modül yönetimi burada.'),
        array('keywords' => array('jetpack guvenlik', 'jetpack güvenlik', 'jetpack backup', 'jetpack yedek'), 'title' => 'Jetpack → Güvenlik', 'url' => admin_url('admin.php?page=jetpack#/security'), 'confidence' => 93, 'category' => 'Jetpack', 'source' => 'Jetpack', 'plugin' => 'jetpack/jetpack.php', 'plugin_name' => 'Jetpack', 'message' => 'Jetpack güvenlik taraması, yedekleme ve brute force koruması burada yönetilir.'),
        array('keywords' => array('jetpack performans', 'jetpack cdn', 'jetpack hiz', 'jetpack hız'), 'title' => 'Jetpack → Performans', 'url' => admin_url('admin.php?page=jetpack#/performance'), 'confidence' => 92, 'category' => 'Jetpack', 'source' => 'Jetpack', 'plugin' => 'jetpack/jetpack.php', 'plugin_name' => 'Jetpack', 'message' => 'Jetpack CDN, görsel optimizasyonu ve lazy load ayarları burada yapılandırılır.'),
        array('keywords' => array('jetpack istatistik', 'jetpack stats', 'jetpack analytics'), 'title' => 'Jetpack → İstatistikler', 'url' => admin_url('admin.php?page=stats'), 'confidence' => 93, 'category' => 'Jetpack', 'source' => 'Jetpack', 'plugin' => 'jetpack/jetpack.php', 'plugin_name' => 'Jetpack', 'message' => 'Site ziyaretçi istatistikleri Jetpack Stats ile burada görüntülenir.'),

        // --- WordPress Multisite ---
        array('keywords' => array('multisite', 'coklu site', 'çoklu site', 'network', 'ag yonetimi', 'ağ yönetimi'), 'title' => 'Ağ Yönetimi', 'url' => network_admin_url(), 'confidence' => 92, 'category' => 'Multisite', 'source' => 'WordPress Multisite', 'message' => 'WordPress Multisite ağ yönetim paneli. Tüm siteleri buradan yönetebilirsiniz.'),
        array('keywords' => array('network site', 'ag siteler', 'ağ siteler', 'alt site', 'subdomain'), 'title' => 'Ağ Yönetimi → Siteler', 'url' => network_admin_url('sites.php'), 'confidence' => 92, 'category' => 'Multisite', 'source' => 'WordPress Multisite', 'message' => 'Ağdaki tüm siteler burada listelenir, yeni site eklenebilir.'),
        array('keywords' => array('network kullanici', 'ağ kullanıcı', 'network user', 'super admin'), 'title' => 'Ağ Yönetimi → Kullanıcılar', 'url' => network_admin_url('users.php'), 'confidence' => 91, 'category' => 'Multisite', 'source' => 'WordPress Multisite', 'message' => 'Ağ genelindeki kullanıcılar ve süper admin yetkileri burada yönetilir.'),
        array('keywords' => array('network eklenti', 'ağ eklenti', 'network plugin', 'network aktif'), 'title' => 'Ağ Yönetimi → Eklentiler', 'url' => network_admin_url('plugins.php'), 'confidence' => 91, 'category' => 'Multisite', 'source' => 'WordPress Multisite', 'message' => 'Tüm ağda aktif edilecek eklentiler buradan yönetilir.'),

        // --- Hosting / Sunucu ---
        array('keywords' => array('cpanel', 'c panel', 'hosting panel', 'plesk'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 80, 'category' => 'Hosting', 'source' => 'Hosting', 'message' => 'Hosting kontrol paneline (cPanel/Plesk) hosting sağlayıcınızın verdiği URL üzerinden erişebilirsiniz. WordPress tarafında Site Durumu ekranı sunucu bilgilerini gösterir.'),
        array('keywords' => array('ftp', 'sftp', 'dosya yonetici', 'dosya yöneticisi', 'file manager'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 80, 'category' => 'Hosting', 'source' => 'Hosting', 'message' => 'FTP/SFTP erişimi için FileZilla gibi bir istemci kullanabilirsiniz. Hosting kontrol panelinizdeki File Manager da alternatif bir seçenektir.'),
        array('keywords' => array('php ini', 'php ayar', 'php config', 'php memory', 'php limit'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 88, 'category' => 'Hosting', 'source' => 'Hosting', 'message' => 'PHP ayarları (memory_limit, upload_max_filesize vb.) hosting kontrol panelinden veya wp-config.php / .htaccess dosyasından değiştirilebilir. Site Durumu ekranı mevcut değerleri gösterir.'),
        array('keywords' => array('mysql', 'phpmyadmin', 'veritabani yedek', 'veritabanı yedek', 'db backup'), 'title' => 'Araçlar → Dışa Aktar', 'url' => admin_url('export.php'), 'confidence' => 85, 'category' => 'Hosting', 'source' => 'Veritabanı', 'message' => 'WordPress içeriğini Araçlar → Dışa Aktar ile yedekleyebilirsiniz. Tam veritabanı yedeği için phpMyAdmin veya UpdraftPlus kullanmanız önerilir.'),
        array('keywords' => array('domain', 'alan adi', 'alan adı', 'dns', 'nameserver'), 'title' => 'Ayarlar → Genel', 'url' => admin_url('options-general.php'), 'confidence' => 82, 'category' => 'Hosting', 'source' => 'Domain', 'message' => 'Domain değişikliği için Ayarlar → Genel\'den WordPress ve Site URL\'lerini güncelleyin. DNS ayarları domain kayıt şirketinizin panelinden yapılır.'),
        array('keywords' => array('ssl sertifika', 'lets encrypt', "let's encrypt", 'https kurulum', 'ssl kurulum'), 'title' => 'Ayarlar → Genel', 'url' => admin_url('options-general.php'), 'confidence' => 87, 'category' => 'Hosting', 'source' => 'SSL', 'message' => 'SSL sertifikası hosting kontrol panelinden (cPanel → SSL/TLS) veya Let\'s Encrypt ile ücretsiz kurulabilir. Kurulum sonrası WordPress URL\'lerini https:// olarak güncelleyin.'),

        // --- Güvenlik Senaryoları ---
        array('keywords' => array('brute force', 'sifre deneme', 'şifre deneme', 'login saldiri', 'login saldırı', 'giris saldiri'), 'title' => 'Eklentiler → Güvenlik', 'url' => admin_url('plugins.php'), 'confidence' => 90, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'message' => 'Brute force saldırılarına karşı: Wordfence veya Limit Login Attempts eklentisi kur, güçlü şifre kullan, kullanıcı adı olarak "admin" kullanma, iki faktörlü doğrulama (2FA) ekle.'),
        array('keywords' => array('dosya izni', 'file permission', 'chmod', 'klasor izni', 'klasör izni'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 88, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'message' => 'Doğru dosya izinleri: klasörler 755, dosyalar 644, wp-config.php 600 olmalı. FTP veya hosting dosya yöneticisinden değiştirebilirsin.'),
        array('keywords' => array('wp-config gizle', 'wp-config koruma', 'htaccess guvenlik', '.htaccess güvenlik'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 87, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'message' => 'wp-config.php\'yi korumak için .htaccess dosyasına erişim engeli ekleyebilirsin. Wordfence bu ayarları otomatik yapılandırır.'),
        array('keywords' => array('iki faktorlu', 'iki faktörlü', '2fa', 'two factor', 'dogrulama kodu', 'doğrulama kodu'), 'title' => 'Kullanıcılar → Profiliniz', 'url' => admin_url('profile.php'), 'confidence' => 89, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'message' => 'İki faktörlü doğrulama için "Two Factor" veya "WP 2FA" eklentisini kurabilirsin. Wordfence Premium da 2FA desteği sunar.'),
        array('keywords' => array('sifre degistir', 'şifre değiştir', 'parola degistir', 'parola değiştir', 'admin sifresi', 'admin şifresi'), 'title' => 'Kullanıcılar → Profiliniz', 'url' => admin_url('profile.php'), 'confidence' => 95, 'category' => 'Güvenlik', 'source' => 'Kullanıcı', 'message' => 'Şifre değiştirmek için Kullanıcılar → Profiliniz sayfasının en altındaki "Yeni Şifre Oluştur" bölümünü kullan.'),
        array('keywords' => array('hack', 'hacklendi', 'site hacklendi', 'virus bulundu', 'malware temizle', 'kotu amacli', 'kötü amaçlı'), 'title' => 'Eklentiler → Güvenlik', 'url' => admin_url('plugins.php'), 'confidence' => 90, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'message' => 'Site hacklendiğinde: 1) Wordfence ile tam tarama yap, 2) Tüm şifreleri değiştir (WordPress, FTP, hosting, veritabanı), 3) WordPress, tema ve eklentileri güncelle, 4) Temiz yedekten geri yükle, 5) Hosting desteğiyle iletişime geç.'),
        array('keywords' => array('spam kayit', 'spam kayıt', 'bot kayit', 'bot kayıt', 'sahte kullanici', 'sahte kullanıcı'), 'title' => 'Ayarlar → Genel', 'url' => admin_url('options-general.php'), 'confidence' => 88, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'message' => 'Spam kayıtları önlemek için: Ayarlar → Genel\'den "Herkes kayıt olabilir" seçeneğini kapat veya kayıt formuna reCAPTCHA ekle. Wordfence ve Akismet de yardımcı olur.'),
        array('keywords' => array('xmlrpc', 'xml-rpc', 'xmlrpc kapat', 'xmlrpc engelle'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 87, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'message' => 'XML-RPC saldırılarına karşı "Disable XML-RPC" eklentisini kurabilir veya .htaccess ile xmlrpc.php\'ye erişimi engelleyebilirsin. Wordfence bu korumayı otomatik sağlar.'),

        // --- Medya ve Görsel Yönetimi ---
        array('keywords' => array('gorsel optimize', 'görsel optimize', 'resim optimize', 'resim sikistir', 'resim sıkıştır', 'webp'), 'title' => 'Ortam Kütüphanesi', 'url' => admin_url('upload.php'), 'confidence' => 88, 'category' => 'Medya', 'source' => 'Medya', 'message' => 'Görsel optimizasyonu için "Smush", "ShortPixel" veya "Imagify" eklentilerini kullanabilirsin. WebP dönüşümü için ShortPixel veya Imagify önerilir.'),
        array('keywords' => array('gorsel boyutu', 'görsel boyutu', 'resim boyutu', 'thumbnail boyutu', 'kucuk resim', 'küçük resim'), 'title' => 'Ayarlar → Ortam', 'url' => admin_url('options-media.php'), 'confidence' => 93, 'category' => 'Medya', 'source' => 'Medya ayarları', 'message' => 'Küçük resim, orta ve büyük boyut ayarları Ayarlar → Ortam sayfasından yapılandırılır.'),
        array('keywords' => array('medya klasoru', 'medya klasörü', 'upload klasoru', 'upload klasörü', 'medya duzenleme', 'medya düzenleme'), 'title' => 'Ayarlar → Ortam', 'url' => admin_url('options-media.php'), 'confidence' => 90, 'category' => 'Medya', 'source' => 'Medya ayarları', 'message' => 'Medya yükleme klasörü ve yıl/ay bazlı organizasyon Ayarlar → Ortam sayfasından yapılandırılır.'),
        array('keywords' => array('broken image', 'kırık resim', 'kirik resim', 'resim gozukmuyor', 'resim görünmüyor'), 'title' => 'Ortam Kütüphanesi', 'url' => admin_url('upload.php'), 'confidence' => 87, 'category' => 'Medya', 'source' => 'Medya', 'message' => 'Kırık görseller için: 1) Ortam kütüphanesinden dosyanın var olduğunu kontrol et, 2) "Regenerate Thumbnails" eklentisiyle küçük resimleri yeniden oluştur, 3) Dosya izinlerini kontrol et (klasörler 755, dosyalar 644).'),

        // --- WordPress Araçları ---
        array('keywords' => array('iceri aktar', 'içeri aktar', 'import', 'xml import', 'icerik aktar', 'içerik aktar'), 'title' => 'Araçlar → İçe Aktar', 'url' => admin_url('import.php'), 'confidence' => 93, 'category' => 'Araçlar', 'source' => 'WordPress Araçları', 'message' => 'WordPress XML, CSV veya diğer platformlardan içerik aktarımı Araçlar → İçe Aktar sayfasından yapılır.'),
        array('keywords' => array('disa aktar', 'dışa aktar', 'export', 'yedek al', 'icerik yedek', 'içerik yedek'), 'title' => 'Araçlar → Dışa Aktar', 'url' => admin_url('export.php'), 'confidence' => 93, 'category' => 'Araçlar', 'source' => 'WordPress Araçları', 'message' => 'Yazılar, sayfalar ve yorumları XML formatında dışa aktarmak için Araçlar → Dışa Aktar sayfasını kullan.'),
        array('keywords' => array('veritabani optimize', 'veritabanı optimize', 'db optimize', 'veritabani temizle', 'veritabanı temizle'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 87, 'category' => 'Araçlar', 'source' => 'WordPress Araçları', 'message' => 'Veritabanı optimizasyonu için "WP-Optimize" veya "Advanced Database Cleaner" eklentisini kullanabilirsin. Eski revizyonlar, spam yorumlar ve geçici verileri temizler.'),
        array('keywords' => array('revizyon', 'revision', 'eski versiyon', 'yazı versiyonu'), 'title' => 'Ayarlar → Yazma', 'url' => admin_url('options-writing.php'), 'confidence' => 86, 'category' => 'Araçlar', 'source' => 'WordPress Araçları', 'message' => 'WordPress revizyonları wp-config.php\'ye define(\'WP_POST_REVISIONS\', 5); ekleyerek sınırlayabilirsin. "WP-Optimize" ile eski revizyonları toplu silebilirsin.'),
        array('keywords' => array('debug modu', 'wp debug', 'hata ayiklama', 'hata ayıklama', 'wp_debug'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 89, 'category' => 'Araçlar', 'source' => 'WordPress Araçları', 'message' => 'Debug modu için wp-config.php\'ye define(\'WP_DEBUG\', true); ekle. Hataları dosyaya yazmak için define(\'WP_DEBUG_LOG\', true); da ekleyebilirsin. Canlı sitede kapalı tutmayı unutma!'),
        array('keywords' => array('bakım modu', 'bakim modu', 'maintenance mode', 'site kapali', 'site kapalı'), 'title' => 'Eklentiler', 'url' => admin_url('plugins.php'), 'confidence' => 86, 'category' => 'Araçlar', 'source' => 'WordPress Araçları', 'message' => 'Bakım modu için "WP Maintenance Mode" veya "Coming Soon Page & Maintenance Mode" eklentisini kullanabilirsin. Bazı cache eklentileri (WP Rocket vb.) de bakım modu özelliği sunar.'),
        array('keywords' => array('yazma ayari', 'yazma ayarı', 'writing settings', 'varsayilan kategori', 'varsayılan kategori'), 'title' => 'Ayarlar → Yazma', 'url' => admin_url('options-writing.php'), 'confidence' => 91, 'category' => 'Ayarlar', 'source' => 'Yazma ayarları', 'message' => 'Varsayılan yazı kategorisi, yazı formatı ve e-posta ile yazı yayınlama ayarları burada yapılandırılır.'),
        array('keywords' => array('tartisma ayari', 'tartışma ayarı', 'yorum ayari', 'yorum ayarı', 'discussion settings'), 'title' => 'Ayarlar → Tartışma', 'url' => admin_url('options-discussion.php'), 'confidence' => 91, 'category' => 'Ayarlar', 'source' => 'Tartışma ayarları', 'message' => 'Yorum onay, bildirim ve moderasyon ayarları Ayarlar → Tartışma sayfasından yapılandırılır.'),

        // --- Gutenberg / Blok Editör ---
        array('keywords' => array('gutenberg', 'blok editor', 'blok editör', 'block editor', 'yeni editor', 'yeni editör'), 'title' => 'Yazılar → Yeni Ekle', 'url' => admin_url('post-new.php'), 'confidence' => 91, 'category' => 'Editör', 'source' => 'Gutenberg', 'message' => 'Gutenberg blok editörü yeni yazı veya sayfa oluştururken açılır. Klasik editöre dönmek için "Classic Editor" eklentisini kurabilirsin.'),
        array('keywords' => array('klasik editor', 'klasik editör', 'classic editor', 'eski editor', 'eski editör'), 'title' => 'Eklentiler → Yeni Ekle', 'url' => admin_url('plugin-install.php?s=classic+editor'), 'confidence' => 92, 'category' => 'Editör', 'source' => 'Classic Editor', 'message' => 'Klasik editöre dönmek için "Classic Editor" eklentisini kur ve etkinleştir. WordPress.org\'un resmi eklentisi.'),
        array('keywords' => array('blok silinemiyor', 'blok eklenemiyor', 'gutenberg hata', 'editor hata', 'editör hata', 'editor calısmiyor', 'editör çalışmıyor'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 88, 'category' => 'Editör', 'source' => 'Gutenberg', 'message' => 'Gutenberg sorunları genellikle eklenti çakışmasından kaynaklanır. Tarayıcı konsolunu kontrol et, eklentileri tek tek devre dışı bırakarak sorunu tespit et.'),
        array('keywords' => array('tam genislik', 'tam genişlik', 'full width', 'wide block', 'genis blok', 'geniş blok'), 'title' => 'Görünüm → Özelleştir', 'url' => admin_url('customize.php'), 'confidence' => 87, 'category' => 'Editör', 'source' => 'Gutenberg', 'message' => 'Tam genişlik blok desteği temaya bağlıdır. Tema bu özelliği destekliyorsa blok araç çubuğundan "Tam Genişlik" seçeneği görünür.'),
        array('keywords' => array('yeniden kullanilabilir blok', 'yeniden kullanılabilir blok', 'reusable block', 'senkronize desen', 'synced pattern'), 'title' => 'Görünüm → Desenler', 'url' => admin_url('edit.php?post_type=wp_block'), 'confidence' => 91, 'category' => 'Editör', 'source' => 'Gutenberg', 'message' => 'Yeniden kullanılabilir bloklar (Desenler) Görünüm → Desenler sayfasından yönetilir.'),

        // --- Yazı Tipleri / Google Fonts ---
        array('keywords' => array('google fonts', 'yazi tipi ekle', 'yazı tipi ekle', 'font ekle', 'özel font', 'ozel font'), 'title' => 'Görünüm → Özelleştir', 'url' => admin_url('customize.php'), 'confidence' => 88, 'category' => 'Tema', 'source' => 'Yazı Tipleri', 'message' => 'Google Fonts eklemek için tema özelleştirici veya "Google Fonts Typography" eklentisini kullanabilirsin. Elementor Pro\'da global yazı tipi ayarları mevcuttur.'),
        array('keywords' => array('font agirlik', 'font ağırlık', 'font boyutu', 'font rengi', 'yazi tipi degistir', 'yazı tipi değiştir'), 'title' => 'Görünüm → Özelleştir', 'url' => admin_url('customize.php'), 'confidence' => 87, 'category' => 'Tema', 'source' => 'Yazı Tipleri', 'message' => 'Yazı tipi boyutu, rengi ve ağırlığı tema özelleştiriciden veya Elementor global ayarlarından değiştirilebilir.'),

        // --- GDPR / Çerez ---
        array('keywords' => array('gdpr', 'kvkk', 'cerez', 'çerez', 'cookie', 'gizlilik politikasi', 'gizlilik politikası', 'privacy policy'), 'title' => 'Ayarlar → Gizlilik', 'url' => admin_url('options-privacy.php'), 'confidence' => 93, 'category' => 'GDPR', 'source' => 'Gizlilik', 'message' => 'Gizlilik politikası sayfası Ayarlar → Gizlilik\'ten oluşturulur. Çerez onayı için "CookieYes" veya "Complianz" eklentisi önerilir.'),
        array('keywords' => array('cerez onay', 'çerez onay', 'cookie consent', 'cookieyes', 'complianz'), 'title' => 'Eklentiler → Yeni Ekle', 'url' => admin_url('plugin-install.php?s=cookie+consent'), 'confidence' => 92, 'category' => 'GDPR', 'source' => 'GDPR', 'plugin' => 'cookie-law-info/cookie-law-info.php', 'plugin_name' => 'CookieYes', 'message' => 'GDPR/KVKK uyumlu çerez onay bandı için "CookieYes" veya "Complianz" eklentisini kurabilirsin.'),

        // --- Sosyal Medya ---
        array('keywords' => array('sosyal medya', 'facebook', 'instagram', 'twitter', 'x.com', 'linkedin', 'youtube', 'sosyal paylasim', 'sosyal paylaşım'), 'title' => 'Görünüm → Özelleştir', 'url' => admin_url('customize.php'), 'confidence' => 85, 'category' => 'Sosyal Medya', 'source' => 'Sosyal Medya', 'message' => 'Sosyal medya linkleri genellikle tema özelleştiriciden eklenir. "Social Icons" bloğu veya Jetpack sosyal medya widget\'ı da kullanılabilir.'),
        array('keywords' => array('open graph', 'og image', 'sosyal paylasim gorseli', 'sosyal paylaşım görseli', 'facebook kart', 'twitter kart'), 'title' => 'Yoast SEO → Sosyal', 'url' => admin_url('admin.php?page=wpseo_social'), 'confidence' => 91, 'category' => 'Sosyal Medya', 'source' => 'Yoast SEO', 'message' => 'Facebook ve Twitter paylaşım görselleri Yoast SEO → Sosyal sekmesinden yapılandırılır. Rank Math\'ta da benzer ayarlar mevcuttur.'),

        // --- Üyelik Sistemleri ---
        array('keywords' => array('uyelik', 'üyelik', 'membership', 'uye sistemi', 'üye sistemi', 'ücretli içerik', 'ucretli icerik'), 'title' => 'Eklentiler → Yeni Ekle', 'url' => admin_url('plugin-install.php?s=membership'), 'confidence' => 86, 'category' => 'Üyelik', 'source' => 'Üyelik', 'message' => 'Üyelik sistemi için "MemberPress", "Paid Memberships Pro" veya "Restrict Content Pro" eklentilerini inceleyebilirsin.'),
        array('keywords' => array('memberpress', 'member press'), 'title' => 'MemberPress → Dashboard', 'url' => admin_url('admin.php?page=memberpress'), 'confidence' => 93, 'category' => 'Üyelik', 'source' => 'MemberPress', 'plugin' => 'memberpress/memberpress.php', 'plugin_name' => 'MemberPress', 'message' => 'MemberPress üyelik yönetimi ve içerik kısıtlama ayarları burada.'),
        array('keywords' => array('paid memberships', 'pmpro', 'paid memberships pro'), 'title' => 'Paid Memberships Pro', 'url' => admin_url('admin.php?page=pmpro-dashboard'), 'confidence' => 93, 'category' => 'Üyelik', 'source' => 'PMPro', 'plugin' => 'paid-memberships-pro/paid-memberships-pro.php', 'plugin_name' => 'Paid Memberships Pro', 'message' => 'Paid Memberships Pro üyelik seviyeleri ve ayarları burada yönetilir.'),

        // --- Geliştirici Araçları ---
        array('keywords' => array('query monitor', 'querymonitor', 'yavas sorgu', 'yavaş sorgu', 'sql sorgu'), 'title' => 'Araçlar → Query Monitor', 'url' => admin_url('tools.php'), 'confidence' => 90, 'category' => 'Geliştirici', 'source' => 'Query Monitor', 'plugin' => 'query-monitor/query-monitor.php', 'plugin_name' => 'Query Monitor', 'message' => 'Query Monitor, yavaş veritabanı sorgularını, hook\'ları ve HTTP isteklerini analiz eder. Admin bar\'dan erişilebilir.'),
        array('keywords' => array('asset cleanup', 'asset temizle', 'js devre disi', 'css devre dışı', 'gereksiz script'), 'title' => 'Eklentiler → Asset CleanUp', 'url' => admin_url('admin.php?page=wpacu_plugin_settings'), 'confidence' => 90, 'category' => 'Performans', 'source' => 'Asset CleanUp', 'plugin' => 'wp-asset-clean-up/wpacu.php', 'plugin_name' => 'Asset CleanUp', 'message' => 'Asset CleanUp ile sayfa bazında gereksiz CSS/JS dosyalarını devre dışı bırakarak sayfa hızını artırabilirsin.'),
        array('keywords' => array('wp optimize', 'wp-optimize', 'veritabani temizlik', 'veritabanı temizlik', 'tablo optimize'), 'title' => 'WP-Optimize', 'url' => admin_url('admin.php?page=wpo_settings'), 'confidence' => 91, 'category' => 'Performans', 'source' => 'WP-Optimize', 'plugin' => 'wp-optimize/wp-optimize.php', 'plugin_name' => 'WP-Optimize', 'message' => 'WP-Optimize ile veritabanı tablolarını optimize edebilir, eski revizyonları ve spam yorumları temizleyebilirsin.'),
        array('keywords' => array('broken link', 'kirik link', 'kırık link', 'olu link', 'ölü link', '404 link'), 'title' => 'Araçlar → Broken Link Checker', 'url' => admin_url('tools.php?page=blc_local'), 'confidence' => 89, 'category' => 'Araçlar', 'source' => 'Broken Link Checker', 'plugin' => 'broken-link-checker/broken-link-checker.php', 'plugin_name' => 'Broken Link Checker', 'message' => 'Kırık linkleri bulmak için "Broken Link Checker" eklentisini kullanabilirsin. Araçlar menüsünden erişilir.'),

        // --- Page Builders ---
        array('keywords' => array('beaver builder', 'beaverbuilder'), 'title' => 'Beaver Builder → Ayarlar', 'url' => admin_url('options-general.php?page=fl-builder-settings'), 'confidence' => 93, 'category' => 'Page Builder', 'source' => 'Beaver Builder', 'plugin' => 'beaver-builder-lite-version/fl-builder.php', 'plugin_name' => 'Beaver Builder', 'message' => 'Beaver Builder ayarları ve lisans yönetimi burada.'),
        array('keywords' => array('bricks builder', 'bricks tema', 'bricks theme'), 'title' => 'Bricks → Ayarlar', 'url' => admin_url('admin.php?page=bricks-settings'), 'confidence' => 93, 'category' => 'Page Builder', 'source' => 'Bricks Builder', 'message' => 'Bricks Builder tema ayarları burada yapılandırılır.'),
        array('keywords' => array('oxygen builder', 'oxygen tema'), 'title' => 'Oxygen → Ayarlar', 'url' => admin_url('admin.php?page=oxygen_vsb_settings'), 'confidence' => 93, 'category' => 'Page Builder', 'source' => 'Oxygen Builder', 'plugin' => 'oxygen/functions.php', 'plugin_name' => 'Oxygen Builder', 'message' => 'Oxygen Builder ayarları ve lisans yönetimi burada.'),
        array('keywords' => array('divi builder', 'divi ayar', 'divi settings'), 'title' => 'Divi → Tema Seçenekleri', 'url' => admin_url('admin.php?page=et_general_settings'), 'confidence' => 93, 'category' => 'Page Builder', 'source' => 'Divi', 'message' => 'Divi tema genel ayarları ve Divi Builder seçenekleri burada.'),

        // --- E-posta Pazarlama ---
        array('keywords' => array('fluentcrm', 'fluent crm', 'crm', 'email pazarlama', 'e-posta pazarlama', 'email marketing'), 'title' => 'FluentCRM → Dashboard', 'url' => admin_url('admin.php?page=fluentcrm-admin'), 'confidence' => 93, 'category' => 'E-posta', 'source' => 'FluentCRM', 'plugin' => 'fluent-crm/fluent-crm.php', 'plugin_name' => 'FluentCRM', 'message' => 'FluentCRM e-posta pazarlama ve CRM yönetimi burada.'),
        array('keywords' => array('fluentcrm liste', 'fluentcrm abone', 'email listesi', 'e-posta listesi'), 'title' => 'FluentCRM → Kişiler', 'url' => admin_url('admin.php?page=fluentcrm-admin#/contacts'), 'confidence' => 92, 'category' => 'E-posta', 'source' => 'FluentCRM', 'plugin' => 'fluent-crm/fluent-crm.php', 'plugin_name' => 'FluentCRM', 'message' => 'Abone listesi ve kişi yönetimi FluentCRM Kişiler bölümünde yapılır.'),
        array('keywords' => array('mailpoet', 'mail poet', 'newsletter eklenti', 'bülten eklenti'), 'title' => 'MailPoet → Dashboard', 'url' => admin_url('admin.php?page=mailpoet-newsletters'), 'confidence' => 93, 'category' => 'E-posta', 'source' => 'MailPoet', 'plugin' => 'mailpoet/mailpoet.php', 'plugin_name' => 'MailPoet', 'message' => 'MailPoet bülten ve e-posta kampanya yönetimi burada.'),

        // --- Rezervasyon / Randevu ---
        array('keywords' => array('rezervasyon', 'randevu', 'booking', 'appointment', 'takvim'), 'title' => 'Eklentiler → Rezervasyon', 'url' => admin_url('plugins.php'), 'confidence' => 85, 'category' => 'Rezervasyon', 'source' => 'Rezervasyon', 'message' => 'Rezervasyon sistemi için "Bookly", "Amelia" veya "WooCommerce Bookings" eklentilerini inceleyebilirsin.'),
        array('keywords' => array('amelia', 'amelia booking'), 'title' => 'Amelia → Dashboard', 'url' => admin_url('admin.php?page=wpamelia-dashboard'), 'confidence' => 93, 'category' => 'Rezervasyon', 'source' => 'Amelia', 'plugin' => 'ameliabooking/ameliabooking.php', 'plugin_name' => 'Amelia', 'message' => 'Amelia randevu ve rezervasyon yönetimi burada.'),
        array('keywords' => array('bookly', 'bookly rezervasyon'), 'title' => 'Bookly → Dashboard', 'url' => admin_url('admin.php?page=bookly-calendar'), 'confidence' => 93, 'category' => 'Rezervasyon', 'source' => 'Bookly', 'plugin' => 'bookly-responsive-appointment-booking-tool/main.php', 'plugin_name' => 'Bookly', 'message' => 'Bookly randevu takvimi ve yönetimi burada.'),

        // --- Çok Satıcılı Marketplace ---
        array('keywords' => array('dokan', 'dokan marketplace', 'cok satici', 'çok satıcı', 'vendor', 'marketplace'), 'title' => 'Dokan → Dashboard', 'url' => admin_url('admin.php?page=dokan'), 'confidence' => 93, 'category' => 'Marketplace', 'source' => 'Dokan', 'plugin' => 'dokan-lite/dokan.php', 'plugin_name' => 'Dokan', 'message' => 'Dokan çok satıcılı marketplace yönetimi burada.'),
        array('keywords' => array('wcfm', 'wc vendors', 'wc marketplace'), 'title' => 'WCFM → Dashboard', 'url' => admin_url('admin.php?page=wcfm-dashboard'), 'confidence' => 92, 'category' => 'Marketplace', 'source' => 'WCFM', 'plugin' => 'wc-frontend-manager/wc_frontend_manager.php', 'plugin_name' => 'WCFM', 'message' => 'WCFM Marketplace satıcı ve mağaza yönetimi burada.'),

        // --- İçerik / SEO Araçları ---
        array('keywords' => array('editorial calendar', 'icerik takvimi', 'içerik takvimi', 'yayin plani', 'yayın planı'), 'title' => 'Yazılar → Takvim', 'url' => admin_url('edit.php?page=cal'), 'confidence' => 88, 'category' => 'İçerik', 'source' => 'Editorial Calendar', 'plugin' => 'editorial-calendar/edcal.php', 'plugin_name' => 'Editorial Calendar', 'message' => 'İçerik takvimi için "Editorial Calendar" veya "CoSchedule" eklentisini kullanabilirsin.'),
        array('keywords' => array('duplicate post', 'sayfayi kopyala', 'sayfayı kopyala', 'yaziyi kopyala', 'yazıyı kopyala', 'kopya olustur', 'kopya oluştur'), 'title' => 'Yazılar / Sayfalar', 'url' => admin_url('edit.php'), 'confidence' => 90, 'category' => 'İçerik', 'source' => 'Duplicate Post', 'plugin' => 'duplicate-post/duplicate-post.php', 'plugin_name' => 'Yoast Duplicate Post', 'message' => '"Yoast Duplicate Post" eklentisiyle yazı ve sayfaları kolayca kopyalayabilirsin.'),
        array('keywords' => array('table of contents', 'icerik tablosu', 'içerik tablosu', 'toc'), 'title' => 'Eklentiler → TOC', 'url' => admin_url('plugins.php'), 'confidence' => 88, 'category' => 'İçerik', 'source' => 'TOC', 'message' => 'İçerik tablosu için "Table of Contents Plus" veya "Easy Table of Contents" eklentisini kullanabilirsin. Rank Math ve Yoast SEO da TOC bloğu sunar.'),
        array('keywords' => array('schema markup', 'yapisal veri', 'yapısal veri', 'rich snippet', 'zengin sonuc', 'zengin sonuç'), 'title' => 'Rank Math → Schema', 'url' => admin_url('admin.php?page=rank-math-options-titles'), 'confidence' => 91, 'category' => 'SEO', 'source' => 'Schema', 'message' => 'Schema markup (yapısal veri) için Rank Math veya Yoast SEO Premium kullanabilirsin. "Schema Pro" da güçlü bir alternatif.'),

        // --- WooCommerce Yaygın Sorunlar ---
        array('keywords' => array('woo odeme hatasi', 'woocommerce ödeme hatası', 'odeme gerceklesmedi', 'ödeme gerçekleşmedi', 'stripe hata', 'paypal hata'), 'title' => 'WooCommerce → Sistem Durumu', 'url' => admin_url('admin.php?page=wc-status'), 'confidence' => 90, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Ödeme hatalarını WooCommerce → Sistem Durumu → Loglar bölümünden inceleyebilirsin. SSL sertifikasının aktif olduğundan ve ödeme eklentisinin güncel olduğundan emin ol.'),
        array('keywords' => array('woo mail gitmiyor', 'woocommerce mail gitmiyor', 'siparis maili gelmiyor', 'sipariş maili gelmiyor'), 'title' => 'WooCommerce → E-posta Ayarları', 'url' => admin_url('admin.php?page=wc-settings&tab=email'), 'confidence' => 91, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'WooCommerce mailleri gitmiyorsa WP Mail SMTP eklentisiyle SMTP yapılandırması yap. WooCommerce → Ayarlar → E-posta\'dan test maili gönderebilirsin.'),
        array('keywords' => array('woo stok azaldi', 'woocommerce stok azaldı', 'stok bildirimi', 'dusuk stok', 'düşük stok'), 'title' => 'WooCommerce → Stok Ayarları', 'url' => admin_url('admin.php?page=wc-settings&tab=products&section=inventory'), 'confidence' => 92, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Düşük stok bildirimleri WooCommerce → Ayarlar → Ürünler → Envanter bölümünden yapılandırılır. Bildirim e-posta adresi ve eşik değeri burada ayarlanır.'),
        array('keywords' => array('woo sepet bos', 'woocommerce sepet boş', 'sepet calısmiyor', 'sepet çalışmıyor', 'checkout calısmiyor', 'checkout çalışmıyor'), 'title' => 'WooCommerce → Sistem Durumu', 'url' => admin_url('admin.php?page=wc-status'), 'confidence' => 89, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Sepet/checkout sorunları genellikle cache veya eklenti çakışmasından kaynaklanır. Cache\'i temizle, eklentileri tek tek devre dışı bırak. WooCommerce → Sistem Durumu\'ndan araçları çalıştır.'),

        // --- LMS / Online Kurs ---
        array('keywords' => array('learndash', 'learn dash', 'online kurs', 'kurs sistemi', 'lms', 'eğitim platformu', 'egitim platformu'), 'title' => 'LearnDash → Kurslar', 'url' => admin_url('admin.php?page=learndash-lms'), 'confidence' => 93, 'category' => 'LMS', 'source' => 'LearnDash', 'plugin' => 'sfwd-lms/sfwd_lms.php', 'plugin_name' => 'LearnDash', 'message' => 'LearnDash kurs yönetimi ve LMS ayarları burada.'),
        array('keywords' => array('lifterlms', 'lifter lms'), 'title' => 'LifterLMS → Dashboard', 'url' => admin_url('admin.php?page=llms-dashboard'), 'confidence' => 93, 'category' => 'LMS', 'source' => 'LifterLMS', 'plugin' => 'lifterlms/lifterlms.php', 'plugin_name' => 'LifterLMS', 'message' => 'LifterLMS kurs ve üyelik yönetimi burada.'),
        array('keywords' => array('tutor lms', 'tutorlms', 'tutor kurs'), 'title' => 'Tutor LMS → Dashboard', 'url' => admin_url('admin.php?page=tutor'), 'confidence' => 93, 'category' => 'LMS', 'source' => 'Tutor LMS', 'plugin' => 'tutor/tutor.php', 'plugin_name' => 'Tutor LMS', 'message' => 'Tutor LMS kurs oluşturma ve öğrenci yönetimi burada.'),
        array('keywords' => array('sensei lms', 'sensei kurs', 'woocommerce kurs'), 'title' => 'Sensei LMS → Kurslar', 'url' => admin_url('edit.php?post_type=course'), 'confidence' => 92, 'category' => 'LMS', 'source' => 'Sensei LMS', 'plugin' => 'sensei-lms/sensei-lms.php', 'plugin_name' => 'Sensei LMS', 'message' => 'Sensei LMS kurs listesi ve yönetimi burada.'),

        // --- Popup / Lead Generation ---
        array('keywords' => array('optinmonster', 'optin monster', 'popup eklenti', 'lead generation', 'email toplama'), 'title' => 'OptinMonster → Kampanyalar', 'url' => admin_url('admin.php?page=optinmonster-dashboard'), 'confidence' => 93, 'category' => 'Pazarlama', 'source' => 'OptinMonster', 'plugin' => 'optinmonster/optin-monster-wp-api.php', 'plugin_name' => 'OptinMonster', 'message' => 'OptinMonster popup ve lead generation kampanyaları burada yönetilir.'),
        array('keywords' => array('popup maker', 'popupmaker', 'popup olustur', 'popup oluştur'), 'title' => 'Popup Maker → Popuplar', 'url' => admin_url('edit.php?post_type=popup'), 'confidence' => 93, 'category' => 'Pazarlama', 'source' => 'Popup Maker', 'plugin' => 'popup-maker/popup-maker.php', 'plugin_name' => 'Popup Maker', 'message' => 'Popup Maker ile oluşturulan popuplar burada listelenir ve yönetilir.'),
        array('keywords' => array('sumo', 'sumo me', 'hellobar', 'hello bar', 'ziyaretci yakalama', 'ziyaretçi yakalama'), 'title' => 'Eklentiler → Pazarlama', 'url' => admin_url('plugins.php'), 'confidence' => 85, 'category' => 'Pazarlama', 'source' => 'Pazarlama', 'message' => 'Ziyaretçi yakalama için OptinMonster, Popup Maker veya Sumo gibi eklentileri kullanabilirsin.'),

        // --- 301 Yönlendirme ---
        array('keywords' => array('301 yonlendirme', '301 yönlendirme', 'redirect yonetimi', 'redirect yönetimi', 'url yonlendirme', 'url yönlendirme', 'redirection eklenti'), 'title' => 'Araçlar → Redirection', 'url' => admin_url('tools.php?page=redirection.php'), 'confidence' => 93, 'category' => 'SEO', 'source' => 'Redirection', 'plugin' => 'redirection/redirection.php', 'plugin_name' => 'Redirection', 'message' => '"Redirection" eklentisiyle 301/302 yönlendirmeleri kolayca yönetebilirsin. 404 logları da tutulur.'),
        array('keywords' => array('rank math redirect', 'yoast redirect', 'seo redirect'), 'title' => 'Rank Math → Yönlendirmeler', 'url' => admin_url('admin.php?page=rank-math-redirections'), 'confidence' => 92, 'category' => 'SEO', 'source' => 'Rank Math', 'plugin' => 'seo-by-rank-math/rank-math.php', 'plugin_name' => 'Rank Math SEO', 'message' => 'Rank Math\'ın yerleşik yönlendirme yöneticisiyle 301 yönlendirmeleri ekleyebilirsin.'),

        // --- REST API / Headless ---
        array('keywords' => array('rest api', 'wordpress api', 'json api', 'headless wordpress', 'headless wp'), 'title' => 'Ayarlar → Kalıcı Bağlantılar', 'url' => admin_url('options-permalink.php'), 'confidence' => 88, 'category' => 'Geliştirici', 'source' => 'REST API', 'message' => 'WordPress REST API /wp-json/ endpoint\'i üzerinden çalışır. Kalıcı bağlantıların düz olmayan bir yapıda olması gerekir. API erişimini kısıtlamak için "Disable REST API" eklentisini kullanabilirsin.'),
        array('keywords' => array('application password', 'uygulama sifresi', 'uygulama şifresi', 'api authentication', 'api kimlik dogrulama'), 'title' => 'Kullanıcılar → Profiliniz', 'url' => admin_url('profile.php'), 'confidence' => 91, 'category' => 'Geliştirici', 'source' => 'REST API', 'message' => 'REST API için uygulama şifreleri Kullanıcılar → Profiliniz sayfasının altında "Uygulama Şifreleri" bölümünden oluşturulur.'),

        // --- Cloudflare ---
        array('keywords' => array('cloudflare', 'cloud flare', 'cloudflare cache', 'cloudflare ayar'), 'title' => 'Ayarlar → Cloudflare', 'url' => admin_url('options-general.php?page=cloudflare'), 'confidence' => 90, 'category' => 'Performans', 'source' => 'Cloudflare', 'plugin' => 'cloudflare/cloudflare.php', 'plugin_name' => 'Cloudflare', 'message' => 'Cloudflare WordPress eklentisiyle cache temizleme ve ayarları doğrudan admin panelinden yönetilebilir.'),
        array('keywords' => array('cloudflare cache temizle', 'cloudflare purge', 'cf cache'), 'title' => 'Ayarlar → Cloudflare', 'url' => admin_url('options-general.php?page=cloudflare'), 'confidence' => 91, 'category' => 'Performans', 'source' => 'Cloudflare', 'message' => 'Cloudflare cache temizlemek için Cloudflare eklentisinden "Purge Cache" butonunu kullan veya Cloudflare dashboard\'undan manuel temizle.'),

        // --- Çok Dilli Sorunlar ---
        array('keywords' => array('ceviri eksik', 'çeviri eksik', 'turkce eksik', 'türkçe eksik', 'dil dosyasi eksik', 'dil dosyası eksik'), 'title' => 'Loco Translate → Ana Sayfa', 'url' => admin_url('admin.php?page=loco-translate-home'), 'confidence' => 91, 'category' => 'Çeviri', 'source' => 'Loco Translate', 'message' => 'Eksik çeviriler için Loco Translate kullanabilirsin. Tema veya eklentinin .po dosyasını düzenleyerek Türkçe çeviri ekleyebilirsin.'),
        array('keywords' => array('dil degistirmiyor', 'dil değiştirmiyor', 'dil secici calısmiyor', 'dil seçici çalışmıyor', 'language switcher'), 'title' => 'Eklentiler → Çeviri', 'url' => admin_url('plugins.php'), 'confidence' => 88, 'category' => 'Çeviri', 'source' => 'Çeviri', 'message' => 'Dil değiştirici sorunları genellikle cache veya tema uyumsuzluğundan kaynaklanır. Cache\'i temizle, çeviri eklentisinin güncel olduğundan emin ol.'),
        array('keywords' => array('rtl', 'sag dan sola', 'sağdan sola', 'arapca', 'arapça', 'ibranice'), 'title' => 'Ayarlar → Genel', 'url' => admin_url('options-general.php'), 'confidence' => 87, 'category' => 'Çeviri', 'source' => 'RTL', 'message' => 'RTL (sağdan sola) dil desteği için Ayarlar → Genel\'den site dilini RTL destekli bir dile ayarla. Tema RTL desteği sunuyorsa otomatik uygulanır.'),

        // --- Performans İzleme ---
        array('keywords' => array('google pagespeed', 'pagespeed insights', 'core web vitals', 'lcp', 'cls', 'fid', 'inp'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 88, 'category' => 'Performans', 'source' => 'Performans', 'message' => 'Core Web Vitals skorunu iyileştirmek için: LCP için görselleri optimize et ve cache kullan, CLS için görsel boyutlarını belirt, INP için gereksiz JS\'i azalt. WP Rocket veya LiteSpeed Cache bu metrikleri otomatik iyileştirir.'),
        array('keywords' => array('gtmetrix', 'pingdom', 'webpagetest', 'hiz testi', 'hız testi'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 86, 'category' => 'Performans', 'source' => 'Performans', 'message' => 'Hız testi için GTmetrix (gtmetrix.com), Pingdom veya Google PageSpeed Insights kullanabilirsin. Site Durumu ekranı da temel performans bilgilerini gösterir.'),

        // --- Portföy / Galeri ---
        array('keywords' => array('portfolyo', 'portföy', 'portfolio', 'galeri eklenti', 'fotograf galerisi', 'fotoğraf galerisi'), 'title' => 'Eklentiler → Galeri', 'url' => admin_url('plugins.php'), 'confidence' => 86, 'category' => 'Galeri', 'source' => 'Galeri', 'message' => 'Galeri için "Envira Gallery", "FooGallery" veya "Modula" eklentilerini kullanabilirsin. Portföy için Elementor veya tema portföy özelliği de yeterli olabilir.'),
        array('keywords' => array('envira gallery', 'envira galeri'), 'title' => 'Envira Gallery', 'url' => admin_url('admin.php?page=envira-gallery'), 'confidence' => 93, 'category' => 'Galeri', 'source' => 'Envira Gallery', 'plugin' => 'envira-gallery-lite/envira-gallery-lite.php', 'plugin_name' => 'Envira Gallery', 'message' => 'Envira Gallery yönetimi burada.'),
        array('keywords' => array('foogallery', 'foo gallery'), 'title' => 'FooGallery', 'url' => admin_url('admin.php?page=foogallery'), 'confidence' => 93, 'category' => 'Galeri', 'source' => 'FooGallery', 'plugin' => 'foogallery/foogallery.php', 'plugin_name' => 'FooGallery', 'message' => 'FooGallery galeri yönetimi burada.'),
        array('keywords' => array('modula', 'modula gallery'), 'title' => 'Modula Gallery', 'url' => admin_url('admin.php?page=modula'), 'confidence' => 93, 'category' => 'Galeri', 'source' => 'Modula', 'plugin' => 'modula-best-grid-gallery/modula-best-grid-gallery.php', 'plugin_name' => 'Modula', 'message' => 'Modula galeri yönetimi burada.'),

        // --- Sosyal Kanıt / Yorumlar ---
        array('keywords' => array('google reviews', 'google yorumlari', 'google yorumları', 'google degerlendirme', 'google değerlendirme'), 'title' => 'Eklentiler → Google Reviews', 'url' => admin_url('plugins.php'), 'confidence' => 86, 'category' => 'Sosyal Kanıt', 'source' => 'Google Reviews', 'message' => 'Google yorumlarını sitenizde göstermek için "Google Reviews Widget" veya "WP Google Review Slider" eklentisini kullanabilirsin.'),
        array('keywords' => array('trustpilot', 'trust pilot', 'site yorumlari', 'site yorumları', 'musteri yorumlari', 'müşteri yorumları'), 'title' => 'Eklentiler → Sosyal Kanıt', 'url' => admin_url('plugins.php'), 'confidence' => 85, 'category' => 'Sosyal Kanıt', 'source' => 'Sosyal Kanıt', 'message' => 'Trustpilot entegrasyonu için resmi Trustpilot WordPress eklentisini kullanabilirsin. Genel sosyal kanıt için "WP Social Proof" veya "TrustPulse" da iyi seçenekler.'),
        array('keywords' => array('yildiz puani', 'yıldız puanı', 'star rating', 'urun puani', 'ürün puanı'), 'title' => 'WooCommerce → Ürün İncelemeleri', 'url' => admin_url('edit-comments.php?post_type=product'), 'confidence' => 90, 'category' => 'Sosyal Kanıt', 'source' => 'WooCommerce', 'message' => 'WooCommerce ürün yıldız puanları ürün inceleme sistemiyle çalışır. WooCommerce → Ayarlar → Ürünler\'den inceleme ayarlarını yapılandırabilirsin.'),

        // --- WooCommerce Abonelik ---
        array('keywords' => array('woocommerce abonelik', 'woo subscription', 'woocommerce subscription', 'tekrarlayan odeme', 'tekrarlayan ödeme', 'aylik odeme', 'aylık ödeme'), 'title' => 'WooCommerce → Abonelikler', 'url' => admin_url('edit.php?post_type=shop_subscription'), 'confidence' => 93, 'category' => 'WooCommerce', 'source' => 'WooCommerce Subscriptions', 'plugin' => 'woocommerce-subscriptions/woocommerce-subscriptions.php', 'plugin_name' => 'WooCommerce Subscriptions', 'message' => 'WooCommerce Subscriptions ile tekrarlayan ödemeler ve abonelik yönetimi burada yapılır.'),
        array('keywords' => array('woo uyelik', 'woocommerce üyelik', 'woo membership', 'woocommerce membership'), 'title' => 'WooCommerce → Üyelikler', 'url' => admin_url('edit.php?post_type=wc_membership_plan'), 'confidence' => 92, 'category' => 'WooCommerce', 'source' => 'WooCommerce Memberships', 'plugin' => 'woocommerce-memberships/woocommerce-memberships.php', 'plugin_name' => 'WooCommerce Memberships', 'message' => 'WooCommerce Memberships ile üyelik planları ve içerik kısıtlama burada yönetilir.'),

        // --- Güvenlik Sertleştirme ---
        array('keywords' => array('wp-admin gizle', 'login url degistir', 'login url değiştir', 'admin url degistir', 'admin url değiştir', 'wps hide login'), 'title' => 'Ayarlar → WPS Hide Login', 'url' => admin_url('options-general.php?page=wps-hide-login'), 'confidence' => 91, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'plugin' => 'wps-hide-login/wps-hide-login.php', 'plugin_name' => 'WPS Hide Login', 'message' => '"WPS Hide Login" eklentisiyle wp-admin ve wp-login.php URL\'lerini özel bir URL ile değiştirebilirsin.'),
        array('keywords' => array('recaptcha', 're-captcha', 'captcha', 'bot koruması', 'bot korumasi', 'spam form'), 'title' => 'Ayarlar → reCAPTCHA', 'url' => admin_url('options-general.php'), 'confidence' => 89, 'category' => 'Güvenlik', 'source' => 'reCAPTCHA', 'message' => 'Form spam koruması için Google reCAPTCHA ekleyebilirsin. "Advanced Google reCAPTCHA" veya form eklentinizin yerleşik reCAPTCHA desteğini kullan.'),
        array('keywords' => array('kullanici adi admin', 'admin kullanici adi', 'admin username degistir', 'admin username değiştir'), 'title' => 'Kullanıcılar → Tüm Kullanıcılar', 'url' => admin_url('users.php'), 'confidence' => 90, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'message' => 'WordPress\'te kullanıcı adı doğrudan değiştirilemez. Yeni bir admin kullanıcı oluştur, eski "admin" kullanıcısını sil. Veya phpMyAdmin\'den wp_users tablosunu düzenle.'),
        array('keywords' => array('wp hardening', 'wordpress sertlestirme', 'wordpress sertleştirme', 'guvenlik onlemleri', 'güvenlik önlemleri'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 89, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'message' => 'WordPress güvenlik sertleştirme için: 1) Dosya düzenlemeyi kapat (define(\'DISALLOW_FILE_EDIT\', true)), 2) Login URL\'yi değiştir, 3) XML-RPC\'yi kapat, 4) Güçlü şifre politikası uygula, 5) Wordfence kur, 6) Düzenli yedek al.'),

        // --- Custom Post Types ---
        array('keywords' => array('custom post type', 'ozel icerik turu', 'özel içerik türü', 'cpt ui', 'cpt'), 'title' => 'CPT UI → Yönetim', 'url' => admin_url('admin.php?page=cptui_main_menu'), 'confidence' => 92, 'category' => 'İçerik', 'source' => 'CPT UI', 'plugin' => 'custom-post-type-ui/custom-post-type-ui.php', 'plugin_name' => 'Custom Post Type UI', 'message' => 'Custom Post Type UI ile özel içerik türleri ve taksonomiler burada oluşturulur.'),
        array('keywords' => array('taksonomi', 'taxonomy', 'ozel kategori', 'özel kategori', 'ozel etiket', 'özel etiket'), 'title' => 'CPT UI → Taksonomi Yönetimi', 'url' => admin_url('admin.php?page=cptui_manage_taxonomies'), 'confidence' => 91, 'category' => 'İçerik', 'source' => 'CPT UI', 'plugin' => 'custom-post-type-ui/custom-post-type-ui.php', 'plugin_name' => 'Custom Post Type UI', 'message' => 'Özel taksonomiler (kategori/etiket benzeri) CPT UI Taksonomi Yönetimi\'nden oluşturulur.'),

        // --- Sayfa Şablonları ---
        array('keywords' => array('sayfa sablonu', 'sayfa şablonu', 'page template', 'tam genislik sayfa', 'tam genişlik sayfa', 'kenar cubuksuz', 'kenar çubuksuz'), 'title' => 'Sayfalar → Düzenle', 'url' => admin_url('edit.php?post_type=page'), 'confidence' => 88, 'category' => 'İçerik', 'source' => 'Sayfa Şablonu', 'message' => 'Sayfa şablonu sayfa düzenleme ekranının sağ tarafındaki "Sayfa Özellikleri" bölümünden seçilir. Mevcut şablonlar temaya göre değişir.'),

        // --- Çoklu Dil Sorunları ---
        array('keywords' => array('wpml hata', 'wpml calısmiyor', 'wpml çalışmıyor', 'wpml sorunu'), 'title' => 'WPML → Sorun Giderme', 'url' => admin_url('admin.php?page=wpml-translation-management%2Fmenu%2Ftranslations-queue.php'), 'confidence' => 89, 'category' => 'Çeviri', 'source' => 'WPML', 'plugin' => 'sitepress-multilingual-cms/sitepress.php', 'plugin_name' => 'WPML', 'message' => 'WPML sorunları için: cache\'i temizle, WPML\'i güncelle, eklenti çakışmalarını kontrol et. WPML → Destek\'ten tanı aracını çalıştırabilirsin.'),
        array('keywords' => array('polylang hata', 'polylang calısmiyor', 'polylang çalışmıyor'), 'title' => 'Polylang → Diller', 'url' => admin_url('admin.php?page=mlang'), 'confidence' => 88, 'category' => 'Çeviri', 'source' => 'Polylang', 'plugin' => 'polylang/polylang.php', 'plugin_name' => 'Polylang', 'message' => 'Polylang sorunları için permalink ayarlarını yeniden kaydet, cache\'i temizle ve eklentiyi güncelle.'),

        // --- Affiliate / Ortaklık ---
        array('keywords' => array('affiliate', 'ortaklik', 'ortaklık', 'referans linki', 'komisyon sistemi', 'affiliate marketing'), 'title' => 'Eklentiler → Affiliate', 'url' => admin_url('plugins.php'), 'confidence' => 86, 'category' => 'Affiliate', 'source' => 'Affiliate', 'message' => 'Affiliate sistemi için "AffiliateWP", "YITH WooCommerce Affiliates" veya "SliceWP" eklentilerini inceleyebilirsin.'),
        array('keywords' => array('affiliatewp', 'affiliate wp'), 'title' => 'AffiliateWP → Dashboard', 'url' => admin_url('admin.php?page=affiliate-wp'), 'confidence' => 93, 'category' => 'Affiliate', 'source' => 'AffiliateWP', 'plugin' => 'affiliate-wp/affiliate-wp.php', 'plugin_name' => 'AffiliateWP', 'message' => 'AffiliateWP ortaklık programı yönetimi burada.'),
        array('keywords' => array('pretty links', 'prettylinks', 'link kisalt', 'link kısalt', 'affiliate link'), 'title' => 'Pretty Links → Linkler', 'url' => admin_url('admin.php?page=pretty-links'), 'confidence' => 92, 'category' => 'Affiliate', 'source' => 'Pretty Links', 'plugin' => 'pretty-link/pretty-link.php', 'plugin_name' => 'Pretty Links', 'message' => 'Pretty Links ile affiliate linklerini kısaltabilir ve tıklama istatistiklerini takip edebilirsin.'),
        array('keywords' => array('thirstyaffiliates', 'thirsty affiliates', 'link cloaking', 'link gizleme'), 'title' => 'ThirstyAffiliates → Linkler', 'url' => admin_url('admin.php?page=thirstyaffiliates'), 'confidence' => 92, 'category' => 'Affiliate', 'source' => 'ThirstyAffiliates', 'plugin' => 'thirstyaffiliates/thirstyaffiliates.php', 'plugin_name' => 'ThirstyAffiliates', 'message' => 'ThirstyAffiliates affiliate link yönetimi ve cloaking burada yapılır.'),

        // --- Checkout Optimizasyonu ---
        array('keywords' => array('checkout optimizasyon', 'tek sayfa checkout', 'one page checkout', 'hizli odeme', 'hızlı ödeme'), 'title' => 'WooCommerce → Ayarlar', 'url' => admin_url('admin.php?page=wc-settings&tab=advanced'), 'confidence' => 89, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Checkout optimizasyonu için "WooCommerce One Page Checkout" veya "CartFlows" eklentisini kullanabilirsin.'),
        array('keywords' => array('cartflows', 'cart flows', 'satis hunisi', 'satış hunisi', 'funnel'), 'title' => 'CartFlows → Dashboard', 'url' => admin_url('admin.php?page=cartflows'), 'confidence' => 93, 'category' => 'WooCommerce', 'source' => 'CartFlows', 'plugin' => 'cartflows/cartflows.php', 'plugin_name' => 'CartFlows', 'message' => 'CartFlows satış hunisi ve checkout akışı yönetimi burada.'),
        array('keywords' => array('terk edilmis sepet', 'terk edilmiş sepet', 'abandoned cart', 'sepet hatirlatma', 'sepet hatırlatma'), 'title' => 'WooCommerce → Terk Edilmiş Sepet', 'url' => admin_url('admin.php?page=wc-admin&path=/analytics/revenue'), 'confidence' => 90, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Terk edilmiş sepet kurtarma için "Abandoned Cart Lite for WooCommerce" veya "CartFlows" eklentisini kullanabilirsin. FluentCRM de bu özelliği sunar.'),

        // --- İçerik Koruma ---
        array('keywords' => array('icerik koruma', 'içerik koruma', 'kopya koruma', 'kopyalama engelle', 'sag tik engelle', 'sağ tık engelle', 'content protection'), 'title' => 'Eklentiler → İçerik Koruma', 'url' => admin_url('plugins.php'), 'confidence' => 87, 'category' => 'Güvenlik', 'source' => 'İçerik Koruma', 'message' => 'İçerik kopyalamayı engellemek için "WP Content Copy Protection" eklentisini kullanabilirsin. Ancak bu yöntemler teknik kullanıcılar tarafından aşılabilir.'),
        array('keywords' => array('pdf koruma', 'dosya koruma', 'indirme koruma', 'download koruma', 'secure download'), 'title' => 'Eklentiler → Dosya Koruma', 'url' => admin_url('plugins.php'), 'confidence' => 86, 'category' => 'Güvenlik', 'source' => 'Dosya Koruma', 'message' => 'Korumalı dosya indirme için "Download Monitor" veya "Easy Digital Downloads" eklentisini kullanabilirsin. Üyelik sistemiyle birleştirerek sadece üyelere özel indirme yapılabilir.'),

        // --- Video Hosting ---
        array('keywords' => array('video ekle', 'video yukle', 'video yükle', 'youtube embed', 'vimeo embed', 'video hosting'), 'title' => 'Ortam → Yeni Ekle', 'url' => admin_url('media-new.php'), 'confidence' => 87, 'category' => 'Medya', 'source' => 'Video', 'message' => 'Video için YouTube veya Vimeo\'ya yükleyip embed etmek önerilir — doğrudan WordPress\'e yüklemek sunucu yükü oluşturur. Gutenberg\'de URL yapıştırarak otomatik embed yapılır.'),
        array('keywords' => array('video üyelik', 'video koruma', 'video kısıtlama', 'video restriction', 'ozel video', 'özel video'), 'title' => 'Eklentiler → Video', 'url' => admin_url('plugins.php'), 'confidence' => 86, 'category' => 'Medya', 'source' => 'Video', 'message' => 'Korumalı video için "VideoWhisper" veya "Presto Player" eklentisini kullanabilirsin. Üyelik sistemiyle birleştirerek sadece üyelere özel video içerik sunulabilir.'),
        array('keywords' => array('presto player', 'prestoplayer', 'video oynatici', 'video oynatıcı'), 'title' => 'Presto Player → Videolar', 'url' => admin_url('admin.php?page=presto-player'), 'confidence' => 92, 'category' => 'Medya', 'source' => 'Presto Player', 'plugin' => 'presto-player/presto-player.php', 'plugin_name' => 'Presto Player', 'message' => 'Presto Player video yönetimi ve oynatıcı ayarları burada.'),

        // --- Arama Geliştirme ---
        array('keywords' => array('arama fonksiyonu', 'site arama', 'arama gelistir', 'arama geliştir', 'search', 'arama sonucu'), 'title' => 'Eklentiler → Arama', 'url' => admin_url('plugins.php'), 'confidence' => 86, 'category' => 'İçerik', 'source' => 'Arama', 'message' => 'WordPress\'in varsayılan araması zayıftır. "SearchWP", "Relevanssi" veya "ElasticPress" ile çok daha iyi arama deneyimi sunabilirsin.'),
        array('keywords' => array('searchwp', 'search wp', 'relevanssi', 'elasticpress'), 'title' => 'SearchWP → Ayarlar', 'url' => admin_url('admin.php?page=searchwp'), 'confidence' => 92, 'category' => 'İçerik', 'source' => 'SearchWP', 'plugin' => 'searchwp/index.php', 'plugin_name' => 'SearchWP', 'message' => 'SearchWP gelişmiş arama ayarları burada yapılandırılır.'),
        array('keywords' => array('ajax arama', 'canli arama', 'canlı arama', 'live search', 'anlik arama', 'anlık arama'), 'title' => 'Eklentiler → Arama', 'url' => admin_url('plugins.php'), 'confidence' => 87, 'category' => 'İçerik', 'source' => 'Arama', 'message' => 'Canlı AJAX arama için "Ajax Search Lite" veya "WP Live Search" eklentisini kullanabilirsin. Elementor Pro da canlı arama widget\'ı sunar.'),

        // --- Multisite Sorunları ---
        array('keywords' => array('multisite hata', 'network hata', 'alt site hata', 'subdomain hata', 'multisite calısmiyor', 'multisite çalışmıyor'), 'title' => 'Ağ Yönetimi → Siteler', 'url' => network_admin_url('sites.php'), 'confidence' => 88, 'category' => 'Multisite', 'source' => 'WordPress Multisite', 'message' => 'Multisite sorunları için: .htaccess dosyasını kontrol et, wp-config.php\'deki multisite sabitlerini doğrula, eklentilerin network düzeyinde aktif olduğundan emin ol.'),
        array('keywords' => array('multisite domain mapping', 'domain haritalama', 'alt site domain', 'custom domain multisite'), 'title' => 'Ağ Yönetimi → Siteler', 'url' => network_admin_url('sites.php'), 'confidence' => 88, 'category' => 'Multisite', 'source' => 'WordPress Multisite', 'message' => 'Multisite domain mapping için WordPress 4.5+ sürümünde yerleşik destek var. Site düzenleme ekranından domain eklenebilir. "Mercator" eklentisi de kullanılabilir.'),

        // --- E-ticaret Genel ---
        array('keywords' => array('easy digital downloads', 'edd', 'dijital urun', 'dijital ürün', 'dijital indirme'), 'title' => 'Easy Digital Downloads', 'url' => admin_url('admin.php?page=edd-dashboard'), 'confidence' => 93, 'category' => 'E-Ticaret', 'source' => 'Easy Digital Downloads', 'plugin' => 'easy-digital-downloads/easy-digital-downloads.php', 'plugin_name' => 'Easy Digital Downloads', 'message' => 'Easy Digital Downloads dijital ürün satışı yönetimi burada.'),
        array('keywords' => array('woocommerce vs edd', 'woocommerce mi edd mi', 'dijital satis eklentisi'), 'title' => 'Eklentiler → E-Ticaret', 'url' => admin_url('plugins.php'), 'confidence' => 85, 'category' => 'E-Ticaret', 'source' => 'E-Ticaret', 'message' => 'Fiziksel ürün satışı için WooCommerce, dijital ürün (PDF, yazılım, müzik) satışı için Easy Digital Downloads daha uygundur. EDD daha hafif ve dijital odaklıdır.'),

        // --- Etkinlik Yönetimi ---
        array('keywords' => array('etkinlik', 'event', 'takvim eklenti', 'etkinlik takvimi', 'konser', 'seminer', 'webinar'), 'title' => 'Etkinlikler → Tüm Etkinlikler', 'url' => admin_url('edit.php?post_type=tribe_events'), 'confidence' => 90, 'category' => 'Etkinlik', 'source' => 'The Events Calendar', 'plugin' => 'the-events-calendar/the-events-calendar.php', 'plugin_name' => 'The Events Calendar', 'message' => 'Etkinlik yönetimi için "The Events Calendar" eklentisi önerilir. Ücretsiz sürümü temel etkinlik ihtiyaçlarını karşılar.'),
        array('keywords' => array('the events calendar', 'events calendar', 'tribe events'), 'title' => 'Etkinlikler → Tüm Etkinlikler', 'url' => admin_url('edit.php?post_type=tribe_events'), 'confidence' => 93, 'category' => 'Etkinlik', 'source' => 'The Events Calendar', 'plugin' => 'the-events-calendar/the-events-calendar.php', 'plugin_name' => 'The Events Calendar', 'message' => 'The Events Calendar etkinlik listesi ve yönetimi burada.'),
        array('keywords' => array('eventon', 'event on', 'modern events calendar', 'mec'), 'title' => 'Eklentiler → Etkinlik', 'url' => admin_url('plugins.php'), 'confidence' => 88, 'category' => 'Etkinlik', 'source' => 'Etkinlik', 'message' => 'EventOn veya Modern Events Calendar da popüler etkinlik eklentileridir. Codecanyon\'dan satın alınabilir.'),
        array('keywords' => array('etkinlik bileti', 'event ticket', 'bilet satisi', 'bilet satışı', 'ticket'), 'title' => 'Etkinlikler → Biletler', 'url' => admin_url('edit.php?post_type=tribe_events'), 'confidence' => 91, 'category' => 'Etkinlik', 'source' => 'Event Tickets', 'plugin' => 'event-tickets/event-tickets.php', 'plugin_name' => 'Event Tickets', 'message' => '"Event Tickets" eklentisiyle etkinliklere bilet satışı ekleyebilirsin. WooCommerce entegrasyonu da mevcut.'),

        // --- Harita / Konum ---
        array('keywords' => array('harita', 'map', 'google maps', 'konum', 'adres harita', 'maps eklenti'), 'title' => 'Eklentiler → Harita', 'url' => admin_url('plugins.php'), 'confidence' => 87, 'category' => 'Harita', 'source' => 'Harita', 'message' => 'Google Maps eklemek için "WP Google Maps" veya "MapPress" eklentisini kullanabilirsin. Elementor Pro da harita widget\'ı sunar.'),
        array('keywords' => array('wp google maps', 'wpgooglemaps', 'mappress'), 'title' => 'WP Google Maps', 'url' => admin_url('admin.php?page=wp-google-maps-menu'), 'confidence' => 92, 'category' => 'Harita', 'source' => 'WP Google Maps', 'plugin' => 'wp-google-maps/wpGoogleMaps.php', 'plugin_name' => 'WP Google Maps', 'message' => 'WP Google Maps harita oluşturma ve yönetimi burada.'),
        array('keywords' => array('leaflet', 'openstreetmap', 'open street map', 'ucretsiz harita', 'ücretsiz harita'), 'title' => 'Eklentiler → Harita', 'url' => admin_url('plugins.php'), 'confidence' => 87, 'category' => 'Harita', 'source' => 'Harita', 'message' => 'Ücretsiz harita için "Leaflet Maps Marker" veya "OSM - OpenStreetMap" eklentisini kullanabilirsin. Google Maps API key gerektirmez.'),
        array('keywords' => array('woocommerce konum', 'magaza konumu', 'mağaza konumu', 'store locator'), 'title' => 'WooCommerce → Mağaza Konumu', 'url' => admin_url('admin.php?page=wc-settings&tab=general'), 'confidence' => 90, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'WooCommerce mağaza konumu WooCommerce → Ayarlar → Genel sekmesinden ayarlanır. Kargo hesaplamaları bu konuma göre yapılır.'),

        // --- Sosyal Giriş ---
        array('keywords' => array('sosyal giris', 'sosyal giriş', 'social login', 'google ile giris', 'google ile giriş', 'facebook ile giris', 'facebook ile giriş'), 'title' => 'Eklentiler → Sosyal Giriş', 'url' => admin_url('plugins.php'), 'confidence' => 88, 'category' => 'Kullanıcı', 'source' => 'Sosyal Giriş', 'message' => 'Sosyal giriş için "Nextend Social Login", "Super Socializer" veya "WP Social" eklentisini kullanabilirsin.'),
        array('keywords' => array('nextend social login', 'google login', 'facebook login', 'apple login'), 'title' => 'Nextend Social Login', 'url' => admin_url('admin.php?page=nextend-social-login'), 'confidence' => 92, 'category' => 'Kullanıcı', 'source' => 'Nextend Social Login', 'plugin' => 'nextend-facebook-connect/nextend-facebook-connect.php', 'plugin_name' => 'Nextend Social Login', 'message' => 'Nextend Social Login ile Google, Facebook ve Apple girişi ayarları burada yapılandırılır.'),

        // --- WooCommerce Ürün Tipleri ---
        array('keywords' => array('basit urun', 'basit ürün', 'simple product', 'woo urun tipi', 'woocommerce ürün tipi'), 'title' => 'WooCommerce → Ürün Ekle', 'url' => admin_url('post-new.php?post_type=product'), 'confidence' => 91, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'WooCommerce ürün tipleri: Basit (tek fiyat), Değişken (renk/beden seçenekli), Gruplu (birden fazla ürün), Harici/Affiliate (başka sitede satılan), Dijital (indirilebilir).'),
        array('keywords' => array('degisken urun', 'değişken ürün', 'variable product', 'urun varyasyonu', 'ürün varyasyonu', 'renk secenegi', 'renk seçeneği', 'beden secenegi'), 'title' => 'WooCommerce → Değişken Ürün', 'url' => admin_url('post-new.php?post_type=product'), 'confidence' => 92, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Değişken ürün için ürün düzenleme ekranında "Ürün Tipi" olarak "Değişken Ürün" seç. Özellikler sekmesinden renk/beden gibi özellikler ekle, Varyasyonlar sekmesinden fiyat ve stok belirle.'),
        array('keywords' => array('urun ozelligi', 'ürün özelliği', 'product attribute', 'urun etiketi', 'ürün etiketi', 'global ozellik', 'global özellik'), 'title' => 'WooCommerce → Özellikler', 'url' => admin_url('edit.php?post_type=product&page=product_attributes'), 'confidence' => 92, 'category' => 'WooCommerce', 'source' => 'WooCommerce', 'plugin' => 'woocommerce/woocommerce.php', 'plugin_name' => 'WooCommerce', 'message' => 'Global ürün özellikleri (renk, beden vb.) WooCommerce → Ürünler → Özellikler sayfasından tanımlanır.'),

        // --- İçerik Planlama ---
        array('keywords' => array('zamanlanmis yazi', 'zamanlanmış yazı', 'scheduled post', 'ileri tarih', 'otomatik yayinla', 'otomatik yayınla'), 'title' => 'Yazılar → Tüm Yazılar', 'url' => admin_url('edit.php?post_status=future&post_type=post'), 'confidence' => 92, 'category' => 'İçerik', 'source' => 'WordPress', 'message' => 'Zamanlanmış yazılar Yazılar → Tüm Yazılar sayfasında "Zamanlanmış" filtresiyle görüntülenir. Yazı düzenleme ekranında yayın tarihini ileri bir tarihe ayarlayarak zamanlama yapılır.'),
        array('keywords' => array('yazi durumu', 'yazı durumu', 'taslak', 'draft', 'beklemede', 'pending review', 'inceleme bekliyor'), 'title' => 'Yazılar → Tüm Yazılar', 'url' => admin_url('edit.php'), 'confidence' => 90, 'category' => 'İçerik', 'source' => 'WordPress', 'message' => 'WordPress yazı durumları: Taslak (kaydedildi, yayınlanmadı), İnceleme Bekliyor (editör onayı gerekiyor), Zamanlanmış (ileri tarihte yayınlanacak), Yayınlandı, Özel (sadece giriş yapanlara görünür).'),
        array('keywords' => array('co authors', 'co-authors', 'coklu yazar', 'çoklu yazar', 'birden fazla yazar'), 'title' => 'Eklentiler → Co-Authors', 'url' => admin_url('plugins.php'), 'confidence' => 87, 'category' => 'İçerik', 'source' => 'Co-Authors Plus', 'plugin' => 'co-authors-plus/co-authors-plus.php', 'plugin_name' => 'Co-Authors Plus', 'message' => '"Co-Authors Plus" eklentisiyle bir yazıya birden fazla yazar atayabilirsin.'),

        // --- Performans Profiling ---
        array('keywords' => array('new relic', 'apm', 'uygulama performans', 'uygulama performansı', 'server monitoring', 'sunucu izleme'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 85, 'category' => 'Performans', 'source' => 'Performans', 'message' => 'Sunucu düzeyinde performans izleme için New Relic veya hosting sağlayıcınızın APM araçlarını kullanabilirsin. WordPress tarafında Query Monitor detaylı profiling sunar.'),
        array('keywords' => array('p3 profiler', 'plugin profiler', 'eklenti hizi', 'eklenti hızı', 'hangi eklenti yavasliyor', 'hangi eklenti yavaşlıyor'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 88, 'category' => 'Performans', 'source' => 'Performans', 'message' => 'Hangi eklentinin siteyi yavaşlattığını bulmak için Query Monitor veya "Plugin Performance Profiler (P3)" eklentisini kullanabilirsin. Admin bar\'daki Query Monitor verileri de çok bilgi verir.'),

        // --- Yoast SEO ---
        array('keywords' => array('yoast', 'seo', 'meta', 'arama motoru', 'google indexleme', 'site haritasi', 'site haritası', 'sitemap'), 'title' => 'Yoast SEO → Genel', 'url' => admin_url('admin.php?page=wpseo_dashboard'), 'confidence' => 93, 'category' => 'SEO', 'source' => 'Yoast SEO', 'plugin' => 'wordpress-seo/wp-seo.php', 'plugin_name' => 'Yoast SEO', 'message' => 'SEO ayarları, site haritası ve arama motoru yapılandırması burada.'),
        array('keywords' => array('yoast ayar', 'seo ayar', 'robots', 'canonical'), 'title' => 'Yoast SEO → Ayarlar', 'url' => admin_url('admin.php?page=wpseo_page_settings'), 'confidence' => 91, 'category' => 'SEO', 'source' => 'Yoast SEO', 'plugin' => 'wordpress-seo/wp-seo.php', 'plugin_name' => 'Yoast SEO', 'message' => 'Yoast SEO detaylı ayarları burada yapılandırılır.'),

        // --- Elementor ---
        array('keywords' => array('elementor', 'sayfa duzenleyici', 'sayfa düzenleyici', 'page builder', 'blok editor'), 'title' => 'Elementor → Ayarlar', 'url' => admin_url('admin.php?page=elementor'), 'confidence' => 93, 'category' => 'Elementor', 'source' => 'Elementor', 'plugin' => 'elementor/elementor.php', 'plugin_name' => 'Elementor', 'message' => 'Elementor genel ayarları ve lisans yönetimi burada.'),
        array('keywords' => array('elementor template', 'elementor sablon', 'elementor şablon', 'elementor kit'), 'title' => 'Elementor → Şablonlar', 'url' => admin_url('edit.php?post_type=elementor_library'), 'confidence' => 92, 'category' => 'Elementor', 'source' => 'Elementor', 'plugin' => 'elementor/elementor.php', 'plugin_name' => 'Elementor', 'message' => 'Elementor şablon kütüphanesi ve kayıtlı tasarımlar burada.'),
        array('keywords' => array('elementor pro', 'elementor lisans', 'elementor license'), 'title' => 'Elementor → Lisans', 'url' => admin_url('admin.php?page=elementor-license'), 'confidence' => 92, 'category' => 'Elementor', 'source' => 'Elementor Pro', 'plugin' => 'elementor-pro/elementor-pro.php', 'plugin_name' => 'Elementor Pro', 'message' => 'Elementor Pro lisans aktivasyonu ve yönetimi burada yapılır.'),
        array('keywords' => array('elementor global', 'elementor renk', 'elementor font', 'elementor yazi tipi', 'elementor yazı tipi'), 'title' => 'Elementor → Global Ayarlar', 'url' => admin_url('admin.php?page=elementor#tab-style'), 'confidence' => 91, 'category' => 'Elementor', 'source' => 'Elementor', 'plugin' => 'elementor/elementor.php', 'plugin_name' => 'Elementor', 'message' => 'Global renkler ve yazı tipleri Elementor ayarlarının Stil sekmesinde bulunur.'),
        array('keywords' => array('elementor header', 'elementor footer', 'elementor theme builder', 'elementor tema'), 'title' => 'Elementor → Theme Builder', 'url' => admin_url('edit.php?post_type=elementor_library&tabs_group=theme'), 'confidence' => 92, 'category' => 'Elementor', 'source' => 'Elementor Pro', 'plugin' => 'elementor-pro/elementor-pro.php', 'plugin_name' => 'Elementor Pro', 'message' => 'Header, footer ve tema şablonları Elementor Theme Builder ile düzenlenir.'),
        array('keywords' => array('elementor popup', 'popup builder', 'elementor modal'), 'title' => 'Elementor → Popup Şablonları', 'url' => admin_url('edit.php?post_type=elementor_library&tabs_group=popup'), 'confidence' => 91, 'category' => 'Elementor', 'source' => 'Elementor Pro', 'plugin' => 'elementor-pro/elementor-pro.php', 'plugin_name' => 'Elementor Pro', 'message' => 'Elementor Pro popup şablonları bu ekrandan oluşturulur ve yönetilir.'),

        // --- Elementor Eklenti Paketleri ---
        array('keywords' => array('royal addons', 'royal addon', 'royal elementor'), 'title' => 'Royal Addons → Ayarlar', 'url' => admin_url('admin.php?page=royal-elementor-addons'), 'confidence' => 93, 'category' => 'Elementor Eklentisi', 'source' => 'Royal Addons', 'plugin' => 'royal-elementor-addons/royal-elementor-addons.php', 'plugin_name' => 'Royal Addons', 'message' => 'Royal Addons widget ve modül ayarları burada yönetilir.'),
        array('keywords' => array('essential addons', 'essential addon', 'eael'), 'title' => 'Essential Addons → Ayarlar', 'url' => admin_url('admin.php?page=eael-settings'), 'confidence' => 93, 'category' => 'Elementor Eklentisi', 'source' => 'Essential Addons', 'plugin' => 'essential-addons-for-elementor-lite/essential_adons_elementor.php', 'plugin_name' => 'Essential Addons', 'message' => 'Essential Addons for Elementor ayarları ve widget yönetimi burada.'),
        array('keywords' => array('jet elements', 'jetelements', 'crocoblock', 'jet plugin'), 'title' => 'JetPlugins → Dashboard', 'url' => admin_url('admin.php?page=jet-dashboard'), 'confidence' => 93, 'category' => 'Elementor Eklentisi', 'source' => 'Crocoblock', 'plugin' => 'jet-elements/jet-elements.php', 'plugin_name' => 'JetElements', 'message' => 'JetElements ve diğer Crocoblock eklentileri Jet Dashboard üzerinden yönetilir.'),
        array('keywords' => array('happy addons', 'happyaddons', 'happy elementor'), 'title' => 'Happy Addons → Ayarlar', 'url' => admin_url('admin.php?page=happy-addons'), 'confidence' => 93, 'category' => 'Elementor Eklentisi', 'source' => 'Happy Addons', 'plugin' => 'happy-elementor-addons/happy-elementor-addons.php', 'plugin_name' => 'Happy Addons', 'message' => 'Happy Addons widget ve özellik ayarları burada yönetilir.'),
        array('keywords' => array('premium addons', 'premium addon', 'premium elementor'), 'title' => 'Premium Addons → Ayarlar', 'url' => admin_url('admin.php?page=premium-addons'), 'confidence' => 93, 'category' => 'Elementor Eklentisi', 'source' => 'Premium Addons', 'plugin' => 'premium-addons-for-elementor/premium_addons.php', 'plugin_name' => 'Premium Addons', 'message' => 'Premium Addons for Elementor ayarları burada yönetilir.'),
        array('keywords' => array('unlimited elements', 'unlimited addon'), 'title' => 'Unlimited Elements → Ayarlar', 'url' => admin_url('admin.php?page=unlimited_elements'), 'confidence' => 92, 'category' => 'Elementor Eklentisi', 'source' => 'Unlimited Elements', 'plugin' => 'unlimited-elements-for-elementor/unlimited-elements-for-elementor.php', 'plugin_name' => 'Unlimited Elements', 'message' => 'Unlimited Elements widget kütüphanesi ve ayarları burada.'),
        array('keywords' => array('piotnet addons', 'pafe', 'piotnet'), 'title' => 'Piotnet Addons → Ayarlar', 'url' => admin_url('admin.php?page=pafe-settings'), 'confidence' => 92, 'category' => 'Elementor Eklentisi', 'source' => 'Piotnet Addons', 'plugin' => 'piotnet-addons-for-elementor/piotnet-addons-for-elementor.php', 'plugin_name' => 'Piotnet Addons', 'message' => 'Piotnet Addons for Elementor ayarları burada yönetilir.'),
        array('keywords' => array('dynamic tags', 'dynamic content', 'acf elementor', 'pods elementor'), 'title' => 'Elementor → Dinamik İçerik', 'url' => admin_url('admin.php?page=elementor'), 'confidence' => 89, 'category' => 'Elementor Eklentisi', 'source' => 'Elementor Dynamic', 'plugin' => 'elementor/elementor.php', 'plugin_name' => 'Elementor', 'message' => 'Dinamik etiketler ve ACF/Pods entegrasyonu Elementor Pro ile kullanılabilir.'),

        // --- Contact Form 7 / WPForms ---
        array('keywords' => array('form', 'iletisim formu', 'iletişim formu', 'contact form', 'wpforms', 'cf7'), 'title' => 'İletişim → Formlar', 'url' => admin_url('admin.php?page=wpcf7'), 'confidence' => 90, 'category' => 'Form', 'source' => 'Contact Form 7', 'plugin' => 'contact-form-7/wp-contact-form-7.php', 'plugin_name' => 'Contact Form 7', 'message' => 'İletişim formları Contact Form 7 veya WPForms üzerinden yönetilir.'),

        // --- Güvenlik / Yedek ---
        array('keywords' => array('yedek', 'backup', 'yedekleme'), 'title' => 'Eklentiler → Yedekleme', 'url' => admin_url('plugins.php'), 'confidence' => 85, 'category' => 'Güvenlik', 'source' => 'Yedekleme', 'plugin' => 'updraftplus/updraftplus.php', 'plugin_name' => 'UpdraftPlus', 'message' => 'UpdraftPlus veya benzeri bir yedekleme eklentisi kurmanız önerilir.'),
        array('keywords' => array('guvenlik', 'güvenlik', 'security', 'firewall', 'hack', 'virus', 'malware'), 'title' => 'Eklentiler → Güvenlik', 'url' => admin_url('plugins.php'), 'confidence' => 87, 'category' => 'Güvenlik', 'source' => 'Güvenlik', 'plugin' => 'wordfence/wordfence.php', 'plugin_name' => 'Wordfence', 'message' => 'Wordfence veya iThemes Security gibi bir güvenlik eklentisi önerilir.'),
        array('keywords' => array('cache', 'onbellek', 'önbellek', 'hiz', 'hız', 'performans', 'yavaş', 'yavas'), 'title' => 'Eklentiler → Önbellek', 'url' => admin_url('plugins.php'), 'confidence' => 86, 'category' => 'Performans', 'source' => 'Önbellek', 'plugin' => 'wp-super-cache/wp-cache.php', 'plugin_name' => 'WP Super Cache', 'message' => 'WP Super Cache veya W3 Total Cache ile sitenizi hızlandırabilirsiniz.'),

        // --- Cache Eklentileri ---
        array('keywords' => array('wp super cache', 'super cache'), 'title' => 'Ayarlar → WP Super Cache', 'url' => admin_url('options-general.php?page=wpsupercache'), 'confidence' => 95, 'category' => 'Performans', 'source' => 'WP Super Cache', 'plugin' => 'wp-super-cache/wp-cache.php', 'plugin_name' => 'WP Super Cache', 'message' => 'WP Super Cache ayarları ve önbellek temizleme burada yapılır.'),
        array('keywords' => array('w3 total cache', 'w3tc', 'w3 cache'), 'title' => 'Performans → W3 Total Cache', 'url' => admin_url('admin.php?page=w3tc_dashboard'), 'confidence' => 95, 'category' => 'Performans', 'source' => 'W3 Total Cache', 'plugin' => 'w3-total-cache/w3-total-cache.php', 'plugin_name' => 'W3 Total Cache', 'message' => 'W3 Total Cache genel ayarları ve önbellek yönetimi burada.'),
        array('keywords' => array('wp rocket', 'wprocket', 'rocket cache'), 'title' => 'Ayarlar → WP Rocket', 'url' => admin_url('options-general.php?page=wprocket'), 'confidence' => 95, 'category' => 'Performans', 'source' => 'WP Rocket', 'plugin' => 'wp-rocket/wp-rocket.php', 'plugin_name' => 'WP Rocket', 'message' => 'WP Rocket önbellek ve performans ayarları burada yapılandırılır.'),
        array('keywords' => array('litespeed', 'lscache', 'litespeed cache'), 'title' => 'LiteSpeed Cache', 'url' => admin_url('admin.php?page=litespeed'), 'confidence' => 95, 'category' => 'Performans', 'source' => 'LiteSpeed Cache', 'plugin' => 'litespeed-cache/litespeed-cache.php', 'plugin_name' => 'LiteSpeed Cache', 'message' => 'LiteSpeed Cache ayarları ve önbellek temizleme burada yapılır.'),
        array('keywords' => array('autoptimize', 'auto optimize', 'js minify', 'css minify', 'minify'), 'title' => 'Ayarlar → Autoptimize', 'url' => admin_url('options-general.php?page=autoptimize'), 'confidence' => 93, 'category' => 'Performans', 'source' => 'Autoptimize', 'plugin' => 'autoptimize/autoptimize.php', 'plugin_name' => 'Autoptimize', 'message' => 'JS/CSS küçültme ve birleştirme ayarları burada yapılır.'),
        array('keywords' => array('swift performance', 'swift cache'), 'title' => 'Swift Performance', 'url' => admin_url('admin.php?page=swift-performance'), 'confidence' => 93, 'category' => 'Performans', 'source' => 'Swift Performance', 'plugin' => 'swift-performance/swift-performance.php', 'plugin_name' => 'Swift Performance', 'message' => 'Swift Performance önbellek ve optimizasyon ayarları burada.'),

        // --- Hata Kodları ve Sayfa Hataları ---
        array('keywords' => array('404', 'sayfa bulunamadi', 'sayfa bulunamadı', 'not found'), 'title' => 'Ayarlar → Kalıcı Bağlantılar', 'url' => admin_url('options-permalink.php'), 'confidence' => 90, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => '404 hatası genellikle permalink ayarlarını yeniden kaydetmekle çözülür. Ayarlar → Kalıcı Bağlantılar sayfasına gidip kaydet butonuna basın.'),
        array('keywords' => array('500', 'internal server error', 'sunucu hatasi', 'sunucu hatası', 'beyaz ekran', 'white screen', 'wsod'), 'title' => 'Eklentiler (Sorun Giderme)', 'url' => admin_url('plugins.php'), 'confidence' => 88, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => '500 hatası genellikle eklenti veya tema çakışmasından kaynaklanır. Eklentileri tek tek devre dışı bırakarak sorunu tespit edebilirsiniz.'),
        array('keywords' => array('403', 'erisim engellendi', 'erişim engellendi', 'forbidden', 'yetki hatasi', 'yetki hatası'), 'title' => 'Kullanıcılar → Tüm Kullanıcılar', 'url' => admin_url('users.php'), 'confidence' => 87, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => '403 hatası yetki sorununa işaret eder. Kullanıcı rolünü ve eklenti izinlerini kontrol edin.'),
        array('keywords' => array('301', '302', 'yonlendirme', 'yönlendirme', 'redirect', 'dongu', 'döngü', 'redirect loop'), 'title' => 'Ayarlar → Genel', 'url' => admin_url('options-general.php'), 'confidence' => 88, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => 'Yönlendirme döngüsü genellikle WordPress ve Site URL ayarlarındaki tutarsızlıktan kaynaklanır. Genel ayarlardan URL\'leri kontrol edin.'),
        array('keywords' => array('veritabani hatasi', 'veritabanı hatası', 'database error', 'db error', 'error establishing'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 89, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => 'Veritabanı hatası için Site Durumu ekranını kontrol edin. wp-config.php dosyasındaki DB bilgilerini de doğrulayın.'),
        array('keywords' => array('memory limit', 'bellek hatasi', 'bellek hatası', 'memory exhausted', 'allowed memory size'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 88, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => 'PHP bellek limiti aşıldı. wp-config.php dosyasına define(\'WP_MEMORY_LIMIT\', \'256M\'); ekleyebilirsiniz.'),
        array('keywords' => array('ssl', 'https', 'sertifika', 'certificate', 'guvenli degil', 'güvenli değil'), 'title' => 'Ayarlar → Genel', 'url' => admin_url('options-general.php'), 'confidence' => 87, 'category' => 'Hata', 'source' => 'SSL', 'message' => 'SSL sorunları için WordPress ve Site URL\'lerinin https:// ile başladığını kontrol edin. Really Simple SSL eklentisi de yardımcı olabilir.'),
        array('keywords' => array('site sagligi', 'site sağlığı', 'site health', 'php surumu', 'php sürümü', 'debug'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 92, 'category' => 'Sistem', 'source' => 'Site Durumu', 'message' => 'PHP sürümü, veritabanı durumu ve genel site sağlığı burada görüntülenir.'),
        array('keywords' => array('kritik hata', 'critical error', 'bu sitede kritik', 'kurtarma modu'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 91, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => '"Bu sitede kritik bir hata oluştu" mesajı genellikle eklenti veya tema çakışmasından kaynaklanır. WordPress kurtarma moduna girmek için e-postanı kontrol et veya eklentileri FTP üzerinden devre dışı bırak.'),
        array('keywords' => array('max execution', 'maksimum sure', 'maksimum süre', 'zaman asimi', 'zaman aşımı', 'timeout', 'script timeout'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 88, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => 'PHP maksimum yürütme süresi aşıldı. Hosting kontrol panelinden veya php.ini dosyasından max_execution_time değerini artırabilirsin (önerilen: 300).'),
        array('keywords' => array('upload limit', 'dosya boyutu', 'dosya yukleme hatasi', 'dosya yükleme hatası', 'maximum upload', 'upload size', 'resim yuklenmiyor', 'resim yüklenmiyor'), 'title' => 'Ortam → Yeni Ekle', 'url' => admin_url('media-new.php'), 'confidence' => 87, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => 'Dosya yükleme boyut limiti aşıldı. Hosting kontrol panelinden upload_max_filesize ve post_max_size değerlerini artırabilirsin. Alternatif olarak wp-config.php\'ye @ini_set(\'upload_max_size\', \'64M\'); ekleyebilirsin.'),
        array('keywords' => array('login loop', 'giris dongusu', 'giriş döngüsü', 'admin girilemiyor', 'wp-admin girilemiyor', 'oturum sorunu', 'cookie sorunu', 'cerez sorunu', 'çerez sorunu'), 'title' => 'Ayarlar → Genel', 'url' => admin_url('options-general.php'), 'confidence' => 89, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => 'Giriş döngüsü genellikle çerez veya URL ayarı sorunudur. Ayarlar → Genel\'den WordPress ve Site URL\'lerinin doğru olduğunu kontrol et. Tarayıcı çerezlerini temizlemek de işe yarayabilir.'),
        array('keywords' => array('guncelleme sonrasi', 'güncelleme sonrası', 'update sonrasi', 'update sonrası', 'guncelleme bozdu', 'güncelleme bozdu'), 'title' => 'Eklentiler (Sorun Giderme)', 'url' => admin_url('plugins.php'), 'confidence' => 88, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => 'Güncelleme sonrası bozulma genellikle eklenti veya tema uyumsuzluğundan kaynaklanır. Son güncellenen eklentiyi devre dışı bırakarak test et. Yedekten geri dönmek için UpdraftPlus kullanabilirsin.'),
        array('keywords' => array('php uyumsuz', 'php version', 'php versiyonu', 'php hatasi', 'php hatası', 'parse error', 'syntax error'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 89, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => 'PHP uyumsuzluk hatası genellikle eski bir eklentinin yeni PHP sürümüyle çalışmamasından kaynaklanır. Site Durumu ekranından PHP sürümünü kontrol et, sorunlu eklentiyi devre dışı bırak.'),
        array('keywords' => array('disk doldu', 'disk alanı', 'disk alani', 'depolama doldu', 'no space left'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 87, 'category' => 'Hata', 'source' => 'Hata yönetimi', 'message' => 'Disk alanı dolduğunda WordPress düzgün çalışmaz. Hosting kontrol panelinden disk kullanımını kontrol et. Gereksiz yedekleri, büyük medya dosyalarını ve eski eklenti/tema dosyalarını temizle.'),
        array('keywords' => array('wp-cron', 'zamanlanmis gorev', 'zamanlanmış görev', 'cron job', 'otomatik guncelleme calısmiyor', 'otomatik güncelleme çalışmıyor'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 86, 'category' => 'Sistem', 'source' => 'Hata yönetimi', 'message' => 'WP-Cron sorunları için Site Durumu ekranını kontrol et. Yüksek trafikli sitelerde wp-config.php\'ye define(\'DISABLE_WP_CRON\', true); ekleyip sunucu tarafında gerçek cron job kurman önerilir.'),
        array('keywords' => array('yavaş admin', 'yavaş panel', 'admin yavaş', 'panel yavaş', 'wp-admin yavaş'), 'title' => 'Araçlar → Site Durumu', 'url' => admin_url('site-health.php'), 'confidence' => 87, 'category' => 'Performans', 'source' => 'Hata yönetimi', 'message' => 'Admin paneli yavaşlığı genellikle çok fazla eklenti, büyük veritabanı veya yetersiz hosting kaynaklarından kaynaklanır. Site Durumu ekranını kontrol et, Query Monitor eklentisiyle yavaş sorguları tespit edebilirsin.'),

        // --- Çeviri ---
        array('keywords' => array('wpml', 'wpml dil', 'wpml ayar'), 'title' => 'WPML → Diller', 'url' => admin_url('admin.php?page=wpml-translation-management%2Fmenu%2Ftranslations-queue.php'), 'confidence' => 95, 'category' => 'Çeviri', 'source' => 'WPML', 'plugin' => 'sitepress-multilingual-cms/sitepress.php', 'plugin_name' => 'WPML', 'message' => 'WPML çeviri kuyruğu ve dil yönetimi burada yapılır.'),
        array('keywords' => array('wpml string', 'wpml metin', 'wpml tema ceviri', 'wpml tema çeviri'), 'title' => 'WPML → String Çevirisi', 'url' => admin_url('admin.php?page=wpml-string-translation%2Fmenu%2Fstring-translation.php'), 'confidence' => 93, 'category' => 'Çeviri', 'source' => 'WPML', 'plugin' => 'sitepress-multilingual-cms/sitepress.php', 'plugin_name' => 'WPML', 'message' => 'Tema ve eklenti metinlerini WPML String Translation ile çevirebilirsiniz.'),
        array('keywords' => array('loco translate', 'loco', 'loco ceviri', 'loco çeviri', 'po dosya', 'mo dosya', 'po file'), 'title' => 'Loco Translate → Ana Sayfa', 'url' => admin_url('admin.php?page=loco-translate-home'), 'confidence' => 95, 'category' => 'Çeviri', 'source' => 'Loco Translate', 'plugin' => 'loco-translate/loco.php', 'plugin_name' => 'Loco Translate', 'message' => 'Loco Translate ile tema ve eklenti .po/.mo dosyalarını doğrudan tarayıcıdan düzenleyebilirsiniz.'),
        array('keywords' => array('loco tema', 'loco theme ceviri', 'loco tema çeviri'), 'title' => 'Loco Translate → Temalar', 'url' => admin_url('admin.php?page=loco-translate-theme'), 'confidence' => 94, 'category' => 'Çeviri', 'source' => 'Loco Translate', 'plugin' => 'loco-translate/loco.php', 'plugin_name' => 'Loco Translate', 'message' => 'Aktif temanın çeviri dosyaları Loco Translate Temalar bölümünde düzenlenir.'),
        array('keywords' => array('loco eklenti ceviri', 'loco plugin çeviri'), 'title' => 'Loco Translate → Eklentiler', 'url' => admin_url('admin.php?page=loco-translate-plugin'), 'confidence' => 94, 'category' => 'Çeviri', 'source' => 'Loco Translate', 'plugin' => 'loco-translate/loco.php', 'plugin_name' => 'Loco Translate', 'message' => 'Eklenti çeviri dosyaları Loco Translate Eklentiler bölümünde düzenlenir.'),
        array('keywords' => array('polylang', 'pll', 'polylang dil'), 'title' => 'Polylang → Diller', 'url' => admin_url('admin.php?page=mlang'), 'confidence' => 94, 'category' => 'Çeviri', 'source' => 'Polylang', 'plugin' => 'polylang/polylang.php', 'plugin_name' => 'Polylang', 'message' => 'Polylang dil yönetimi ve çeviri ayarları burada yapılır.'),
        array('keywords' => array('translatepress', 'translate press'), 'title' => 'TranslatePress → Ayarlar', 'url' => admin_url('admin.php?page=translatepress-settings'), 'confidence' => 94, 'category' => 'Çeviri', 'source' => 'TranslatePress', 'plugin' => 'translatepress-multilingual/index.php', 'plugin_name' => 'TranslatePress', 'message' => 'TranslatePress dil ve çeviri ayarları burada yapılandırılır.'),
        array('keywords' => array('weglot', 'we glot'), 'title' => 'Weglot → Ayarlar', 'url' => admin_url('admin.php?page=weglot'), 'confidence' => 93, 'category' => 'Çeviri', 'source' => 'Weglot', 'plugin' => 'weglot/weglot.php', 'plugin_name' => 'Weglot', 'message' => 'Weglot otomatik çeviri ve dil ayarları burada yönetilir.'),
        array('keywords' => array('dil', 'ceviri', 'çeviri', 'multilingual', 'cok dilli', 'çok dilli'), 'title' => 'Eklentiler → Çeviri', 'url' => admin_url('plugins.php'), 'confidence' => 82, 'category' => 'Çeviri', 'source' => 'Çeviri eklentisi', 'message' => 'WPML, Polylang, Loco Translate veya TranslatePress ile çok dilli site oluşturabilirsiniz.'),

        // --- Rank Math SEO ---
        array('keywords' => array('rank math', 'rankmath', 'rank math seo'), 'title' => 'Rank Math → Dashboard', 'url' => admin_url('admin.php?page=rank-math'), 'confidence' => 94, 'category' => 'SEO', 'source' => 'Rank Math', 'plugin' => 'seo-by-rank-math/rank-math.php', 'plugin_name' => 'Rank Math SEO', 'message' => 'Rank Math SEO genel bakış ve ayarlar burada.'),
        array('keywords' => array('rank math ayar', 'rank math settings'), 'title' => 'Rank Math → Genel Ayarlar', 'url' => admin_url('admin.php?page=rank-math-options-general'), 'confidence' => 93, 'category' => 'SEO', 'source' => 'Rank Math', 'plugin' => 'seo-by-rank-math/rank-math.php', 'plugin_name' => 'Rank Math SEO', 'message' => 'Rank Math genel SEO ayarları burada yapılandırılır.'),
        array('keywords' => array('rank math sitemap', 'rank math site haritası'), 'title' => 'Rank Math → Site Haritası', 'url' => admin_url('admin.php?page=rank-math-options-sitemap'), 'confidence' => 93, 'category' => 'SEO', 'source' => 'Rank Math', 'plugin' => 'seo-by-rank-math/rank-math.php', 'plugin_name' => 'Rank Math SEO', 'message' => 'Rank Math site haritası ayarları burada yapılandırılır.'),

        // --- ACF (Advanced Custom Fields) ---
        array('keywords' => array('acf', 'advanced custom fields', 'özel alan', 'ozel alan', 'custom field'), 'title' => 'ACF → Alan Grupları', 'url' => admin_url('edit.php?post_type=acf-field-group'), 'confidence' => 94, 'category' => 'İçerik', 'source' => 'ACF', 'plugin' => 'advanced-custom-fields/acf.php', 'plugin_name' => 'Advanced Custom Fields', 'message' => 'ACF alan grupları burada oluşturulur ve yönetilir.'),
        array('keywords' => array('acf pro', 'acf ayar', 'acf settings'), 'title' => 'ACF → Ayarlar', 'url' => admin_url('edit.php?post_type=acf-field-group&page=acf-settings'), 'confidence' => 92, 'category' => 'İçerik', 'source' => 'ACF', 'plugin' => 'advanced-custom-fields/acf.php', 'plugin_name' => 'Advanced Custom Fields', 'message' => 'ACF lisans ve genel ayarları burada yönetilir.'),

        // --- Gravity Forms ---
        array('keywords' => array('gravity forms', 'gravity form', 'gravityforms'), 'title' => 'Gravity Forms → Formlar', 'url' => admin_url('admin.php?page=gf_edit_forms'), 'confidence' => 94, 'category' => 'Form', 'source' => 'Gravity Forms', 'plugin' => 'gravityforms/gravityforms.php', 'plugin_name' => 'Gravity Forms', 'message' => 'Gravity Forms form listesi ve yönetimi burada.'),
        array('keywords' => array('gravity forms ayar', 'gravity settings'), 'title' => 'Gravity Forms → Ayarlar', 'url' => admin_url('admin.php?page=gf_settings'), 'confidence' => 93, 'category' => 'Form', 'source' => 'Gravity Forms', 'plugin' => 'gravityforms/gravityforms.php', 'plugin_name' => 'Gravity Forms', 'message' => 'Gravity Forms genel ayarları ve lisans yönetimi burada.'),
        array('keywords' => array('gravity forms giriş', 'gravity entries', 'form gönderim'), 'title' => 'Gravity Forms → Girişler', 'url' => admin_url('admin.php?page=gf_entries'), 'confidence' => 93, 'category' => 'Form', 'source' => 'Gravity Forms', 'plugin' => 'gravityforms/gravityforms.php', 'plugin_name' => 'Gravity Forms', 'message' => 'Form gönderimlerini ve girişleri burada görüntüleyebilirsiniz.'),

        // --- WPForms ---
        array('keywords' => array('wpforms', 'wp forms'), 'title' => 'WPForms → Tüm Formlar', 'url' => admin_url('admin.php?page=wpforms-overview'), 'confidence' => 94, 'category' => 'Form', 'source' => 'WPForms', 'plugin' => 'wpforms-lite/wpforms.php', 'plugin_name' => 'WPForms', 'message' => 'WPForms form listesi ve yönetimi burada.'),
        array('keywords' => array('wpforms ayar', 'wpforms settings'), 'title' => 'WPForms → Ayarlar', 'url' => admin_url('admin.php?page=wpforms-settings'), 'confidence' => 93, 'category' => 'Form', 'source' => 'WPForms', 'plugin' => 'wpforms-lite/wpforms.php', 'plugin_name' => 'WPForms', 'message' => 'WPForms genel ayarları burada yapılandırılır.'),

        // --- Ninja Forms ---
        array('keywords' => array('ninja forms', 'ninjaforms'), 'title' => 'Ninja Forms → Formlar', 'url' => admin_url('admin.php?page=ninja-forms'), 'confidence' => 93, 'category' => 'Form', 'source' => 'Ninja Forms', 'plugin' => 'ninja-forms/ninja-forms.php', 'plugin_name' => 'Ninja Forms', 'message' => 'Ninja Forms form listesi ve yönetimi burada.'),

        // --- Akismet ---
        array('keywords' => array('akismet', 'spam koruması', 'spam korumasi', 'yorum spam'), 'title' => 'Ayarlar → Akismet', 'url' => admin_url('options-general.php?page=akismet-key-config'), 'confidence' => 93, 'category' => 'Güvenlik', 'source' => 'Akismet', 'plugin' => 'akismet/akismet.php', 'plugin_name' => 'Akismet', 'message' => 'Akismet spam koruması ayarları ve API key yapılandırması burada.'),

        // --- MonsterInsights / Google Analytics ---
        array('keywords' => array('monsterinsights', 'monster insights', 'google analytics', 'analytics', 'istatistik', 'ziyaretçi'), 'title' => 'Insights → Dashboard', 'url' => admin_url('admin.php?page=monsterinsights_reports'), 'confidence' => 93, 'category' => 'Analitik', 'source' => 'MonsterInsights', 'plugin' => 'google-analytics-for-wordpress/googleanalytics.php', 'plugin_name' => 'MonsterInsights', 'message' => 'Site istatistikleri ve Google Analytics raporları burada görüntülenir.'),
        array('keywords' => array('monsterinsights ayar', 'analytics ayar'), 'title' => 'Insights → Ayarlar', 'url' => admin_url('admin.php?page=monsterinsights_settings'), 'confidence' => 92, 'category' => 'Analitik', 'source' => 'MonsterInsights', 'plugin' => 'google-analytics-for-wordpress/googleanalytics.php', 'plugin_name' => 'MonsterInsights', 'message' => 'MonsterInsights Google Analytics bağlantı ve ayarları burada yapılandırılır.'),

        // --- Mailchimp for WordPress ---
        array('keywords' => array('mailchimp', 'mail chimp', 'e-posta listesi', 'eposta listesi', 'newsletter', 'bülten'), 'title' => 'Mailchimp → Ayarlar', 'url' => admin_url('admin.php?page=mailchimp-for-wp'), 'confidence' => 93, 'category' => 'E-posta', 'source' => 'Mailchimp for WP', 'plugin' => 'mailchimp-for-wp/mailchimp-for-wp.php', 'plugin_name' => 'Mailchimp for WordPress', 'message' => 'Mailchimp bağlantısı ve form ayarları burada yapılandırılır.'),

        // --- WP Mail SMTP ---
        array('keywords' => array('wp mail smtp', 'mail smtp', 'smtp', 'e-posta gönderimi', 'eposta gönderimi', 'mail ayarı', 'mail ayari'), 'title' => 'WP Mail SMTP → Ayarlar', 'url' => admin_url('admin.php?page=wp-mail-smtp'), 'confidence' => 94, 'category' => 'E-posta', 'source' => 'WP Mail SMTP', 'plugin' => 'wp-mail-smtp/wp_mail_smtp.php', 'plugin_name' => 'WP Mail SMTP', 'message' => 'E-posta gönderim ayarları ve SMTP yapılandırması burada yapılır.'),
        array('keywords' => array('mail gitmiyor', 'mail gelmiyor', 'e-posta gitmiyor', 'eposta gitmiyor'), 'title' => 'WP Mail SMTP → Ayarlar', 'url' => admin_url('admin.php?page=wp-mail-smtp'), 'confidence' => 91, 'category' => 'E-posta', 'source' => 'WP Mail SMTP', 'message' => 'WordPress\'ten mail gitmiyorsa WP Mail SMTP eklentisiyle SMTP yapılandırması yapmanız gerekiyor.'),

        // --- Slider Revolution ---
        array('keywords' => array('slider revolution', 'revslider', 'rev slider', 'slider'), 'title' => 'Slider Revolution', 'url' => admin_url('admin.php?page=revslider'), 'confidence' => 93, 'category' => 'Görsel', 'source' => 'Slider Revolution', 'plugin' => 'revslider/revslider.php', 'plugin_name' => 'Slider Revolution', 'message' => 'Slider Revolution slider yönetimi ve düzenleme burada yapılır.'),

        // --- Custom Post Types ---
        array('keywords' => array('custom post type', 'özel içerik türü', 'ozel icerik turu', 'cpt'), 'title' => 'Araçlar → CPT UI', 'url' => admin_url('admin.php?page=cptui_main_menu'), 'confidence' => 88, 'category' => 'İçerik', 'source' => 'CPT UI', 'message' => 'Custom Post Type UI ile özel içerik türleri ve taksonomiler oluşturabilirsiniz.'),

        // --- Tema Bazlı ---
        array('keywords' => array('astra', 'astra tema', 'astra theme'), 'title' => 'Görünüm → Astra Seçenekleri', 'url' => admin_url('admin.php?page=astra'), 'confidence' => 93, 'category' => 'Tema', 'source' => 'Astra', 'message' => 'Astra tema ayarları ve özelleştirme seçenekleri burada.'),
        array('keywords' => array('divi', 'divi tema', 'divi builder'), 'title' => 'Divi → Tema Seçenekleri', 'url' => admin_url('admin.php?page=et_general_settings'), 'confidence' => 93, 'category' => 'Tema', 'source' => 'Divi', 'message' => 'Divi tema genel ayarları burada yapılandırılır.'),
        array('keywords' => array('generatepress', 'generate press'), 'title' => 'Görünüm → GeneratePress', 'url' => admin_url('themes.php?page=generate-options'), 'confidence' => 93, 'category' => 'Tema', 'source' => 'GeneratePress', 'message' => 'GeneratePress tema modülleri ve ayarları burada yönetilir.'),
        array('keywords' => array('oceanwp', 'ocean wp'), 'title' => 'Görünüm → OceanWP', 'url' => admin_url('admin.php?page=oceanwp-panel'), 'confidence' => 92, 'category' => 'Tema', 'source' => 'OceanWP', 'message' => 'OceanWP tema ayarları ve eklenti entegrasyonları burada.'),
        array('keywords' => array('flatsome', 'flatsome tema'), 'title' => 'Görünüm → Flatsome', 'url' => admin_url('admin.php?page=flatsome_panel'), 'confidence' => 92, 'category' => 'Tema', 'source' => 'Flatsome', 'message' => 'Flatsome tema ayarları ve UX Builder seçenekleri burada.'),
    );

    // --- Genel bilgi soruları (routes'tan ÖNCE kontrol et) ---
    $settings_url = admin_url('options-general.php?page=ai-la-settings');
    $has_groq_key = !empty(aila_get_gemini_key());

    $info_routes = array(

        // --- Ai-la kendi ayarları ---
        array(
            'keywords' => array('groq key', 'groq api', 'api key', 'ai aktif', 'ai nasıl', 'yapay zeka nasıl', 'ai modu', 'groq nasıl', 'key nasıl', 'key nereye', 'key gir', 'api gir'),
            'message'  => !$has_groq_key
                ? 'AI modunu aktifleştirmek için Groq\'tan ücretsiz bir API key alman gerekiyor. Ayarlar sayfasına gidip key\'ini girebilirsin. 🔑'
                : 'Groq API key zaten girilmiş, AI modu aktif! ✓ Ayarları değiştirmek istersen Ayarlar sayfasına gidebilirsin.',
            'suggestions' => array('groq.com\'dan key al', 'ai-la ayarları', 'bağlantıyı test et'),
            'route' => array(
                'success'    => true,
                'title'      => 'Ai-la → Ayarlar',
                'url'        => $settings_url,
                'confidence' => 98,
                'category'   => 'Ai-la',
                'source'     => 'Ai-la',
                'message'    => !$has_groq_key
                    ? 'Groq API key girerek AI modunu aktifleştirebilirsin. Ücretsiz key için console.groq.com/keys adresini ziyaret et.'
                    : 'Ai-la ayarları — Groq key ve Supabase bağlantısını buradan yönetebilirsin.',
                'next_steps' => array(
                    'console.groq.com/keys adresine git',
                    'Ücretsiz hesap oluştur ve API key al',
                    'Groq API Key alanına yapıştır',
                    '"Kaydet" butonuna bas',
                    '"Groq\'u Test Et" ile bağlantıyı doğrula',
                ),
            ),
        ),
        array(
            'keywords' => array('supabase', 'telemetri', 'istatistik', 'supabase key', 'supabase url', 'supabase nasıl', 'kullanım istatistik'),
            'message'  => 'Supabase bağlantısıyla kurulum ve kullanım istatistiklerini takip edebilirsin. Ayarlar sayfasından Supabase URL ve key\'ini girebilirsin. 📊',
            'suggestions' => array('supabase.com\'dan key al', 'ai-la ayarları'),
            'route' => array(
                'success'    => true,
                'title'      => 'Ai-la → Ayarlar',
                'url'        => $settings_url,
                'confidence' => 98,
                'category'   => 'Ai-la',
                'source'     => 'Ai-la',
                'message'    => 'Supabase URL ve key\'ini Ai-la ayarlarından girebilirsin. Telemetri isteğe bağlıdır.',
                'next_steps' => array(
                    'supabase.com\'dan ücretsiz proje oluştur',
                    'Project URL ve anon key\'i kopyala',
                    'Supabase URL ve Key alanlarına yapıştır',
                    '"Kaydet" butonuna bas',
                ),
            ),
        ),

        // Selamlama ve sohbet
        array('keywords' => array('merhaba', 'selam', 'hey', 'hi ', 'hello', 'mrb'), 'message' => 'Merhaba! 👋 Ben Ai-la. WordPress\'te ne üzerinde çalışıyoruz bugün?', 'suggestions' => array('woocommerce sipariş', 'elementor düzenleme', 'yoast seo ayarları', 'wordpress hızlandırma')),
        array('keywords' => array('nasılsın', 'nasilsin', 'naber', 'ne haber', 'iyi misin', 'keyifler nasıl'), 'message' => 'İyiyim, teşekkürler! 😊 Kod yazıp WordPress sorunları çözmek benim için en iyi şey zaten. Sen nasılsın, bugün ne takıldı?', 'suggestions' => array('woocommerce sipariş', 'elementor düzenleme', 'site hızlandırma', 'güvenlik')),
        array('keywords' => array('ne yapıyorsun', 'ne yapiyorsun', 'ne yapıyorsun', 'meşgul müsün', 'boş musun'), 'message' => 'Seninle WordPress konuşmayı bekliyordum! 😄 Söyle bakalım, ne lazım?', 'suggestions' => array('logo değiştir', 'menü ayarları', 'eklenti yükle', 'kullanıcı yetkileri')),
        array('keywords' => array('teşekkür', 'tesekkur', 'sağ ol', 'sag ol', 'eyvallah', 'thanks', 'thank you'), 'message' => 'Rica ederim! 🙂 Başka takıldığın bir şey olursa buradayım.', 'suggestions' => array('logo değiştir', 'menü ayarları', 'eklenti yükle', 'kullanıcı yetkileri')),
        array('keywords' => array('süper', 'harika', 'mükemmel', 'çok iyi', 'bravo', 'aferin', 'efsane', 'muhteşem'), 'message' => 'Teşekkürler, motive oldum! 💪 Devam edelim mi?', 'suggestions' => array('woocommerce sipariş', 'elementor düzenleme', 'yoast seo ayarları', 'wordpress hızlandırma')),
        array('keywords' => array('günaydın', 'gunaydin', 'iyi sabahlar', 'good morning'), 'message' => 'Günaydın! ☀️ Umarım güzel bir gün geçirirsin. WordPress\'te bugün ne yapıyoruz?', 'suggestions' => array('woocommerce sipariş', 'elementor düzenleme', 'yoast seo ayarları', 'site hızlandırma')),
        array('keywords' => array('iyi günler', 'iyi akşamlar', 'iyi geceler', 'good evening', 'good night'), 'message' => 'İyi günler! 🙂 Yardımcı olabileceğim bir şey var mı?', 'suggestions' => array('woocommerce sipariş', 'elementor düzenleme', 'yoast seo ayarları', 'wordpress hızlandırma')),
        array('keywords' => array('kimsin', 'kim sin', 'sen kimsin', 'hakkında', 'hakkinda', 'ne yaparsın', 'ne yapabilirsin'), 'message' => 'Ben Ai-la — WordPress için yapılmış bir AI asistanım. ✦ Ayar bulmak, eklenti sorunlarını çözmek, hata gidermek ve WordPress hakkında her türlü soruyu yanıtlamak için buradayım. Gemini AI ile çalışıyorum.', 'suggestions' => array('woocommerce nedir', 'elementor ne işe yarar', 'wordpress hızlandırma', 'wordpress güvenlik')),
        array('keywords' => array('yardım', 'yardim', 'help', 'ne sorabilir', 'nasıl kullanılır'), 'message' => 'Şu konularda yardımcı olabilirim:\n\n🔧 Admin ayarlarını bulmak\n🛒 WooCommerce sorunları\n🎨 Elementor ve tema soruları\n🔍 SEO ayarları\n⚡ Performans ve cache\n🔒 Güvenlik\n🌐 Çeviri eklentileri\n❌ Hata çözümleri\n\nNe sormak istersin?', 'suggestions' => array('woocommerce sipariş', 'elementor düzenleme', '404 hatası', 'wordpress hızlandırma')),
        array('keywords' => array('sıkıldım', 'sikildim', 'canım sıkılıyor', 'bıktım', 'biktim'), 'message' => 'Anlarım, WordPress bazen öyle yapıyor 😅 Ama çözemeyeceğimiz sorun yok. Ne takıldı?', 'suggestions' => array('woocommerce sipariş', 'elementor düzenleme', '404 hatası', 'wordpress hızlandırma')),
        array('keywords' => array('çok zor', 'cok zor', 'anlamıyorum', 'anlamiyorum', 'kafam karıştı', 'kafam karisti'), 'message' => 'Merak etme, birlikte çözeriz! 💪 Hangi konuda takıldın, anlat bakalım.', 'suggestions' => array('woocommerce sipariş', 'elementor düzenleme', '404 hatası', 'wordpress hızlandırma')),
        array('keywords' => array('kimsin', 'kim sin', 'sen kimsin', 'ne yaparsın', 'ne yapabilirsin', 'ne yapabilirsin', 'hakkında', 'hakkinda'), 'message' => 'Ben Ai-la — WordPress için yapılmış bir AI asistanım. ✦ Ayar bulmak, eklenti sorunlarını çözmek, hata gidermek ve WordPress hakkında her türlü soruyu yanıtlamak için buradayım. Gemini AI ile çalışıyorum.', 'suggestions' => array('woocommerce nedir', 'elementor ne işe yarar', 'wordpress hızlandırma', 'wordpress güvenlik')),
        array('keywords' => array('yardım', 'yardim', 'help', 'ne sorabilir', 'nasıl kullanılır', 'nasil kullanilir'), 'message' => 'Sana şu konularda yardımcı olabilirim:\n\n🔧 Admin ayarlarını bulmak\n🛒 WooCommerce sorunları\n🎨 Elementor ve tema soruları\n🔍 SEO ayarları\n⚡ Performans ve cache\n🔒 Güvenlik\n🌐 Çeviri eklentileri\n❌ Hata çözümleri\n\nNe sormak istersin?', 'suggestions' => array('woocommerce sipariş', 'elementor düzenleme', '404 hatası', 'wordpress hızlandırma')),
        array('keywords' => array('günaydın', 'gunaydin', 'iyi günler', 'iyi akşamlar', 'iyi geceler'), 'message' => 'Günaydın! ☀️ Bugün WordPress\'te ne üzerinde çalışıyoruz?', 'suggestions' => array('woocommerce sipariş', 'elementor düzenleme', 'yoast seo ayarları', 'site hızlandırma')),
        array('keywords' => array('woocommerce nasıl kurulur', 'woocommerce nasil kurulur'), 'message' => 'WooCommerce\'i kurmak çok kolay! Eklentiler → Yeni Ekle\'ye git, "WooCommerce" ara, kur ve etkinleştir. Kurulum sihirbazı seni adım adım yönlendirecek.'),
        array('keywords' => array('woocommerce ne işe yarar', 'woocommerce ne ise yarar'), 'message' => 'WooCommerce, WordPress sitenizi tam özellikli bir e-ticaret mağazasına dönüştürür. Ürün satışı, ödeme alma, kargo yönetimi, stok takibi gibi her şeyi yapabilirsiniz. Temel sürümü ücretsiz!'),
        array('keywords' => array('woocommerce ücretsiz mi', 'woocommerce ucretsiz mi'), 'message' => 'WooCommerce\'in temel sürümü tamamen ücretsiz. Ancak bazı ödeme yöntemleri ve gelişmiş özellikler için ücretli eklentiler gerekebilir.'),

        // Elementor
        array('keywords' => array('elementor nasıl kurulur', 'elementor nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Elementor" ara, kur ve etkinleştir. Sonra herhangi bir sayfayı "Elementor ile Düzenle" butonuyla açabilirsin.'),
        array('keywords' => array('elementor ne işe yarar', 'elementor ne ise yarar'), 'message' => 'Elementor, sürükle-bırak ile sayfa tasarlamanı sağlayan bir sayfa oluşturucudur. Kod bilmeden profesyonel sayfalar, header, footer ve popup\'lar tasarlayabilirsin.'),
        array('keywords' => array('elementor ücretsiz mi', 'elementor ucretsiz mi'), 'message' => 'Elementor\'un ücretsiz sürümü oldukça güçlü. Elementor Pro daha fazla widget ve tema oluşturucu sunar, yıllık ~$59\'dan başlıyor.'),
        array('keywords' => array('elementor pro ne işe yarar', 'elementor pro ne ise yarar'), 'message' => 'Elementor Pro; Theme Builder (header/footer tasarımı), WooCommerce builder, popup builder, form widget ve 100+ pro widget içerir. Profesyonel site yapımı için ideal.'),

        // Yoast SEO
        array('keywords' => array('yoast nasıl kurulur', 'yoast nasil kurulur', 'yoast seo nasıl kurulur', 'yoast seo nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Yoast SEO" ara, kur ve etkinleştir. Kurulum sihirbazı temel SEO ayarlarını yapmanı sağlar.'),
        array('keywords' => array('yoast ne işe yarar', 'yoast ne ise yarar', 'yoast seo ne işe yarar'), 'message' => 'Yoast SEO, sitenizin Google\'da daha iyi sıralanmasına yardımcı olur. Meta açıklamaları, site haritası, robots.txt ve içerik analizi sunar.'),
        array('keywords' => array('yoast ücretsiz mi', 'yoast ucretsiz mi', 'yoast seo ücretsiz mi'), 'message' => 'Yoast SEO\'nun ücretsiz sürümü çoğu ihtiyacı karşılar. Premium sürüm iç bağlantı önerileri ve çoklu anahtar kelime gibi özellikler ekler, yıllık ~$99.'),

        // WPML
        array('keywords' => array('wpml nasıl kurulur', 'wpml nasil kurulur'), 'message' => 'WPML ücretlidir. wpml.org\'dan satın alıp indirdikten sonra Eklentiler → Eklenti Yükle\'den zip dosyasını yükleyebilirsin.'),
        array('keywords' => array('wpml ne işe yarar', 'wpml ne ise yarar'), 'message' => 'WPML, WordPress sitenizi çok dilli hale getirir. İçerikleri farklı dillere çevirebilir, dil bazlı URL yapısı oluşturabilirsin. En kapsamlı çok dilli çözümlerden biri.'),
        array('keywords' => array('wpml ücretsiz mi', 'wpml ucretsiz mi'), 'message' => 'WPML ücretlidir. Blog planı ~$39, CMS planı ~$99, Agency planı ~$199/yıl. Ücretsiz alternatif: Polylang veya Loco Translate.'),

        // Loco Translate
        array('keywords' => array('loco translate nasıl kurulur', 'loco translate nasil kurulur', 'loco nasıl kurulur', 'loco nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Loco Translate" ara, kur ve etkinleştir. Tamamen ücretsiz!'),
        array('keywords' => array('loco translate ne işe yarar', 'loco translate ne ise yarar', 'loco ne işe yarar'), 'message' => 'Loco Translate, tema ve eklentilerin .po/.mo çeviri dosyalarını doğrudan admin panelinden düzenlemenizi sağlar. Türkçe çeviri düzeltmeleri için çok kullanışlı.'),
        array('keywords' => array('loco translate ücretsiz mi', 'loco ucretsiz mi'), 'message' => 'Loco Translate tamamen ücretsiz ve açık kaynaklı. Pro sürümü de var ama ücretsiz sürüm çoğu ihtiyacı karşılar.'),

        // Polylang
        array('keywords' => array('polylang nasıl kurulur', 'polylang nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Polylang" ara, kur ve etkinleştir. Ücretsiz sürümü çoğu site için yeterli.'),
        array('keywords' => array('polylang ne işe yarar', 'polylang ne ise yarar'), 'message' => 'Polylang, WordPress sitenizi çok dilli yapar. WPML\'e ücretsiz bir alternatif. Yazılar, sayfalar, kategoriler ve menüleri farklı dillerde yönetebilirsin.'),
        array('keywords' => array('polylang ücretsiz mi', 'polylang ucretsiz mi'), 'message' => 'Polylang\'ın ücretsiz sürümü oldukça kapsamlı. WooCommerce entegrasyonu için Polylang Pro gerekir, ~$99/yıl.'),

        // TranslatePress
        array('keywords' => array('translatepress nasıl kurulur', 'translatepress nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "TranslatePress" ara, kur ve etkinleştir. Sitenizi görsel olarak ön yüzden çevirebilirsin.'),
        array('keywords' => array('translatepress ne işe yarar', 'translatepress ne ise yarar'), 'message' => 'TranslatePress, sitenizi doğrudan ön yüzden görsel olarak çevirmenizi sağlar. Sayfayı görürken üzerine tıklayıp çevirebilirsiniz. Çok kullanıcı dostu bir yaklaşım.'),
        array('keywords' => array('translatepress ücretsiz mi', 'translatepress ucretsiz mi'), 'message' => 'TranslatePress\'in ücretsiz sürümü 1 ek dil destekler. Birden fazla dil için Personal planı ~$89/yıl.'),

        // Weglot
        array('keywords' => array('weglot nasıl kurulur', 'weglot nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Weglot" ara, kur ve etkinleştir. weglot.com\'dan API key alman gerekiyor.'),
        array('keywords' => array('weglot ne işe yarar', 'weglot ne ise yarar'), 'message' => 'Weglot, sitenizi otomatik olarak çevirir ve dil değiştirici ekler. Makine çevirisi + manuel düzenleme imkânı sunar. Kurulumu çok hızlı.'),
        array('keywords' => array('weglot ücretsiz mi', 'weglot ucretsiz mi'), 'message' => 'Weglot\'un ücretsiz planı 2000 kelimeye kadar 1 dil destekler. Daha fazlası için Starter planı ~$99/yıl\'dan başlıyor.'),

        // WP Rocket
        array('keywords' => array('wp rocket nasıl kurulur', 'wp rocket nasil kurulur'), 'message' => 'WP Rocket ücretlidir. wp-rocket.me\'den satın alıp indirdikten sonra Eklentiler → Eklenti Yükle\'den zip dosyasını yükleyebilirsin.'),
        array('keywords' => array('wp rocket ne işe yarar', 'wp rocket ne ise yarar'), 'message' => 'WP Rocket, sitenizi hızlandıran premium bir önbellek eklentisidir. Sayfa önbellekleme, CSS/JS küçültme, lazy load, CDN entegrasyonu gibi özellikler sunar.'),
        array('keywords' => array('wp rocket ücretsiz mi', 'wp rocket ucretsiz mi'), 'message' => 'WP Rocket tamamen ücretlidir. Tek site ~$59/yıl. Ücretsiz alternatif: LiteSpeed Cache veya WP Super Cache.'),

        // LiteSpeed Cache
        array('keywords' => array('litespeed cache nasıl kurulur', 'litespeed nasil kurulur', 'litespeed cache nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "LiteSpeed Cache" ara, kur ve etkinleştir. LiteSpeed sunucu olmasa da bazı özellikler çalışır.'),
        array('keywords' => array('litespeed cache ne işe yarar', 'litespeed ne ise yarar', 'litespeed cache ne ise yarar'), 'message' => 'LiteSpeed Cache, sunucu düzeyinde önbellekleme yapan güçlü bir performans eklentisidir. CSS/JS optimizasyonu, görsel sıkıştırma, CDN desteği içerir.'),
        array('keywords' => array('litespeed cache ücretsiz mi', 'litespeed ucretsiz mi'), 'message' => 'LiteSpeed Cache tamamen ücretsiz! LiteSpeed sunucuyla en iyi performansı verir ama diğer sunucularda da kullanılabilir.'),

        // WP Super Cache
        array('keywords' => array('wp super cache nasıl kurulur', 'wp super cache nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "WP Super Cache" ara, kur ve etkinleştir. Automattic tarafından geliştirilmiş güvenilir bir eklenti.'),
        array('keywords' => array('wp super cache ne işe yarar', 'wp super cache ne ise yarar'), 'message' => 'WP Super Cache, sayfaları statik HTML dosyalarına dönüştürerek sitenizi hızlandırır. Basit yapısıyla yeni başlayanlar için idealdir.'),
        array('keywords' => array('wp super cache ücretsiz mi', 'wp super cache ucretsiz mi'), 'message' => 'WP Super Cache tamamen ücretsiz ve açık kaynaklı.'),

        // W3 Total Cache
        array('keywords' => array('w3 total cache nasıl kurulur', 'w3 total cache nasil kurulur', 'w3tc nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "W3 Total Cache" ara, kur ve etkinleştir. Ayarları biraz karmaşık olabilir ama çok güçlü.'),
        array('keywords' => array('w3 total cache ne işe yarar', 'w3 total cache ne ise yarar'), 'message' => 'W3 Total Cache, sayfa/veritabanı/nesne önbellekleme, CDN entegrasyonu ve minify özellikleriyle kapsamlı bir performans çözümü sunar.'),
        array('keywords' => array('w3 total cache ücretsiz mi', 'w3tc ucretsiz mi'), 'message' => 'W3 Total Cache\'in ücretsiz sürümü çok kapsamlı. Pro sürümü ek özellikler sunar, ~$99/yıl.'),

        // Autoptimize
        array('keywords' => array('autoptimize nasıl kurulur', 'autoptimize nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Autoptimize" ara, kur ve etkinleştir. Genellikle diğer cache eklentileriyle birlikte kullanılır.'),
        array('keywords' => array('autoptimize ne işe yarar', 'autoptimize ne ise yarar'), 'message' => 'Autoptimize, CSS, JavaScript ve HTML dosyalarını küçültüp birleştirerek sayfa yükleme hızını artırır. Görsel optimizasyonu da yapabilir.'),
        array('keywords' => array('autoptimize ücretsiz mi', 'autoptimize ucretsiz mi'), 'message' => 'Autoptimize tamamen ücretsiz. Ücretli "Autoptimize Pro" sürümü de var ama ücretsiz sürüm çoğu ihtiyacı karşılar.'),

        // Contact Form 7
        array('keywords' => array('contact form 7 nasıl kurulur', 'contact form 7 nasil kurulur', 'cf7 nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Contact Form 7" ara, kur ve etkinleştir. Sonra İletişim menüsünden form oluşturabilirsin.'),
        array('keywords' => array('contact form 7 ne işe yarar', 'contact form 7 ne ise yarar', 'cf7 ne işe yarar'), 'message' => 'Contact Form 7, WordPress\'in en popüler form eklentisidir. İletişim formları, anket formları ve daha fazlasını oluşturabilirsin. Tamamen ücretsiz.'),
        array('keywords' => array('contact form 7 ücretsiz mi', 'cf7 ucretsiz mi'), 'message' => 'Contact Form 7 tamamen ücretsiz ve açık kaynaklı. Ek özellikler için Flamingo (e-posta kayıt) gibi ücretsiz eklentiler de kullanabilirsin.'),

        // Royal Addons
        array('keywords' => array('royal addons nasıl kurulur', 'royal addons nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Royal Elementor Addons" ara, kur ve etkinleştir. Elementor\'un kurulu olması gerekiyor.'),
        array('keywords' => array('royal addons ne işe yarar', 'royal addons ne ise yarar'), 'message' => 'Royal Addons, Elementor için 80+ ek widget sunar. Slider, mega menü, pricing table, timeline, WooCommerce widget\'ları ve daha fazlası içerir.'),
        array('keywords' => array('royal addons ücretsiz mi', 'royal addons ucretsiz mi'), 'message' => 'Royal Addons\'ın ücretsiz sürümü oldukça kapsamlı. Pro sürümü daha fazla widget ve özellik sunar, ~$49/yıl.'),

        // Essential Addons
        array('keywords' => array('essential addons nasıl kurulur', 'essential addons nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Essential Addons for Elementor" ara, kur ve etkinleştir.'),
        array('keywords' => array('essential addons ne işe yarar', 'essential addons ne ise yarar'), 'message' => 'Essential Addons, Elementor için 80+ widget ve 25+ template sunar. Data table, filtrelenebilir galeri, WooCommerce ürün grid gibi özellikler içerir.'),
        array('keywords' => array('essential addons ücretsiz mi', 'essential addons ucretsiz mi'), 'message' => 'Essential Addons\'ın ücretsiz sürümü mevcut. Pro sürümü ~$39/yıl\'dan başlıyor.'),

        // Happy Addons
        array('keywords' => array('happy addons nasıl kurulur', 'happy addons nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Happy Addons for Elementor" ara, kur ve etkinleştir.'),
        array('keywords' => array('happy addons ne işe yarar', 'happy addons ne ise yarar'), 'message' => 'Happy Addons, Elementor için 100+ widget ve copy-paste tasarım özelliği sunar. Farklı siteler arasında tasarım kopyalayabilirsin.'),
        array('keywords' => array('happy addons ücretsiz mi', 'happy addons ucretsiz mi'), 'message' => 'Happy Addons\'ın ücretsiz sürümü mevcut. Pro sürümü ~$39/yıl.'),

        // Premium Addons
        array('keywords' => array('premium addons nasıl kurulur', 'premium addons nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Premium Addons for Elementor" ara, kur ve etkinleştir.'),
        array('keywords' => array('premium addons ne işe yarar', 'premium addons ne ise yarar'), 'message' => 'Premium Addons, Elementor için 55+ widget sunar. Parallax efektleri, parçacık animasyonları, gelişmiş carousel gibi görsel özellikler içerir.'),
        array('keywords' => array('premium addons ücretsiz mi', 'premium addons ucretsiz mi'), 'message' => 'Premium Addons\'ın ücretsiz sürümü mevcut. Pro sürümü ~$49/yıl.'),

        // JetElements / Crocoblock
        array('keywords' => array('jet elements nasıl kurulur', 'jetelements nasil kurulur', 'crocoblock nasıl kurulur'), 'message' => 'Crocoblock ücretlidir. crocoblock.com\'dan satın alıp indirdikten sonra Eklentiler → Eklenti Yükle\'den yükleyebilirsin.'),
        array('keywords' => array('jet elements ne işe yarar', 'jetelements ne ise yarar', 'crocoblock ne işe yarar'), 'message' => 'Crocoblock/JetPlugins, Elementor için JetElements, JetEngine, JetSmartFilters gibi güçlü eklentiler sunar. Özellikle dinamik içerik ve custom post type\'lar için idealdir.'),
        array('keywords' => array('crocoblock ücretsiz mi', 'jet elements ucretsiz mi'), 'message' => 'Crocoblock ücretlidir. All-inclusive paket ~$130/yıl. Bireysel eklentiler ayrı satılır.'),

        // Wordfence
        array('keywords' => array('wordfence nasıl kurulur', 'wordfence nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Wordfence Security" ara, kur ve etkinleştir. Kurulum sonrası tarama başlatmanı önerir.'),
        array('keywords' => array('wordfence ne işe yarar', 'wordfence ne ise yarar'), 'message' => 'Wordfence, WordPress için kapsamlı bir güvenlik eklentisidir. Firewall, malware tarama, brute force koruması ve gerçek zamanlı tehdit tespiti sunar.'),
        array('keywords' => array('wordfence ücretsiz mi', 'wordfence ucretsiz mi'), 'message' => 'Wordfence\'in ücretsiz sürümü çoğu site için yeterli. Premium sürüm gerçek zamanlı firewall kuralları ve IP engelleme sunar, ~$119/yıl.'),

        // UpdraftPlus
        array('keywords' => array('updraftplus nasıl kurulur', 'updraftplus nasil kurulur', 'updraft nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "UpdraftPlus" ara, kur ve etkinleştir. Ayarlar → UpdraftPlus\'tan yedekleme zamanlaması yapabilirsin.'),
        array('keywords' => array('updraftplus ne işe yarar', 'updraftplus ne ise yarar', 'updraft ne işe yarar'), 'message' => 'UpdraftPlus, WordPress sitenizi otomatik olarak yedekler. Google Drive, Dropbox, Amazon S3 gibi bulut depolama alanlarına yedek alabilirsin.'),
        array('keywords' => array('updraftplus ücretsiz mi', 'updraft ucretsiz mi'), 'message' => 'UpdraftPlus\'ın ücretsiz sürümü manuel ve zamanlanmış yedekleme yapabilir. Premium sürüm artımlı yedekleme ve daha fazla depolama seçeneği sunar, ~$70/yıl.'),

        // Rank Math SEO
        array('keywords' => array('rank math nasıl kurulur', 'rank math nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Rank Math SEO" ara, kur ve etkinleştir. Kurulum sihirbazı Google Search Console bağlantısı dahil her şeyi adım adım yapılandırır.'),
        array('keywords' => array('rank math ne işe yarar', 'rank math ne ise yarar'), 'message' => 'Rank Math, Yoast SEO\'ya güçlü bir alternatiftir. Schema markup, 404 monitör, yönlendirme yöneticisi, anahtar kelime sıralaması takibi gibi gelişmiş özellikler sunar.'),
        array('keywords' => array('rank math ücretsiz mi', 'rank math ucretsiz mi'), 'message' => 'Rank Math\'ın ücretsiz sürümü çok kapsamlı — Yoast\'ın premium özelliklerinin çoğunu ücretsiz sunar. Pro sürümü ~$59/yıl\'dan başlıyor.'),

        // ACF
        array('keywords' => array('acf nasıl kurulur', 'acf nasil kurulur', 'advanced custom fields nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Advanced Custom Fields" ara, kur ve etkinleştir. ACF Pro için acfpro.com\'dan satın alman gerekiyor.'),
        array('keywords' => array('acf ne işe yarar', 'acf ne ise yarar', 'advanced custom fields ne işe yarar'), 'message' => 'ACF, WordPress içeriklerine özel alanlar eklemenizi sağlar. Metin, resim, ilişki, tekrarlayan alan gibi 30+ alan tipiyle içerik yapısını tamamen özelleştirebilirsin.'),
        array('keywords' => array('acf ücretsiz mi', 'acf ucretsiz mi'), 'message' => 'ACF\'nin ücretsiz sürümü temel alanları destekler. Tekrarlayan alanlar (Repeater), esnek içerik ve galeri alanları için ACF Pro gerekir, ~$49/yıl.'),

        // Gravity Forms
        array('keywords' => array('gravity forms nasıl kurulur', 'gravity forms nasil kurulur'), 'message' => 'Gravity Forms ücretlidir. gravityforms.com\'dan satın alıp indirdikten sonra Eklentiler → Eklenti Yükle\'den zip dosyasını yükleyebilirsin.'),
        array('keywords' => array('gravity forms ne işe yarar', 'gravity forms ne ise yarar'), 'message' => 'Gravity Forms, WordPress\'in en güçlü form eklentilerinden biridir. Koşullu mantık, çok adımlı formlar, ödeme entegrasyonu, hesaplama alanları gibi gelişmiş özellikler sunar.'),
        array('keywords' => array('gravity forms ücretsiz mi', 'gravity forms ucretsiz mi'), 'message' => 'Gravity Forms tamamen ücretlidir. Basic lisans ~$59/yıl, Elite lisans ~$259/yıl. Ücretsiz alternatif: WPForms Lite veya Contact Form 7.'),

        // WPForms
        array('keywords' => array('wpforms nasıl kurulur', 'wpforms nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "WPForms" ara, kur ve etkinleştir. Ücretsiz Lite sürümü hemen kullanılabilir.'),
        array('keywords' => array('wpforms ne işe yarar', 'wpforms ne ise yarar'), 'message' => 'WPForms, sürükle-bırak form oluşturucusuyla iletişim formları, anketler, ödeme formları ve daha fazlasını kolayca oluşturmanı sağlar.'),
        array('keywords' => array('wpforms ücretsiz mi', 'wpforms ucretsiz mi'), 'message' => 'WPForms Lite tamamen ücretsiz. Pro sürümü koşullu mantık, ödeme entegrasyonu ve daha fazlasını sunar, ~$49/yıl\'dan başlıyor.'),

        // Ninja Forms
        array('keywords' => array('ninja forms nasıl kurulur', 'ninja forms nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Ninja Forms" ara, kur ve etkinleştir. Ücretsiz sürümü hemen kullanılabilir.'),
        array('keywords' => array('ninja forms ne işe yarar', 'ninja forms ne ise yarar'), 'message' => 'Ninja Forms, sürükle-bırak arayüzüyle form oluşturmayı kolaylaştırır. Koşullu mantık, çok adımlı formlar ve çeşitli entegrasyonlar sunar.'),
        array('keywords' => array('ninja forms ücretsiz mi', 'ninja forms ucretsiz mi'), 'message' => 'Ninja Forms\'un ücretsiz sürümü temel form ihtiyaçlarını karşılar. Eklentiler ve gelişmiş özellikler için ücretli planlar mevcut.'),

        // Akismet
        array('keywords' => array('akismet nasıl kurulur', 'akismet nasil kurulur'), 'message' => 'Akismet çoğu WordPress kurulumunda önceden yüklü gelir. Etkinleştirmek için wordpress.com\'dan ücretsiz API key almanız gerekiyor.'),
        array('keywords' => array('akismet ne işe yarar', 'akismet ne ise yarar'), 'message' => 'Akismet, yorum ve form spam\'ini otomatik olarak filtreler. Milyonlarca siteden öğrendiği verilerle spam tespitinde çok başarılıdır.'),
        array('keywords' => array('akismet ücretsiz mi', 'akismet ucretsiz mi'), 'message' => 'Akismet kişisel siteler için ücretsiz. Ticari siteler için Plus planı ~$10/ay\'dan başlıyor.'),

        // MonsterInsights
        array('keywords' => array('monsterinsights nasıl kurulur', 'monsterinsights nasil kurulur', 'google analytics nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "MonsterInsights" ara, kur ve etkinleştir. Kurulum sihirbazı Google Analytics hesabını bağlamanı sağlar.'),
        array('keywords' => array('monsterinsights ne işe yarar', 'monsterinsights ne ise yarar', 'google analytics ne işe yarar'), 'message' => 'MonsterInsights, Google Analytics verilerini doğrudan WordPress admin panelinde gösterir. Ziyaretçi istatistikleri, en çok okunan sayfalar, dönüşüm takibi gibi raporlar sunar.'),
        array('keywords' => array('monsterinsights ücretsiz mi', 'google analytics ucretsiz mi'), 'message' => 'MonsterInsights Lite ücretsiz. Pro sürümü e-ticaret takibi ve gelişmiş raporlar sunar, ~$99/yıl\'dan başlıyor. Google Analytics\'in kendisi ücretsiz.'),

        // Mailchimp
        array('keywords' => array('mailchimp nasıl kurulur', 'mailchimp nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Mailchimp for WordPress" ara, kur ve etkinleştir. mailchimp.com\'dan ücretsiz hesap açıp API key almanız gerekiyor.'),
        array('keywords' => array('mailchimp ne işe yarar', 'mailchimp ne ise yarar'), 'message' => 'Mailchimp, e-posta listesi yönetimi ve bülten gönderimi için kullanılır. WordPress formlarınızı Mailchimp listelerinize bağlayarak otomatik abone toplama yapabilirsiniz.'),
        array('keywords' => array('mailchimp ücretsiz mi', 'mailchimp ucretsiz mi'), 'message' => 'Mailchimp 500 aboneye kadar ücretsiz. Daha fazlası için Essentials planı ~$13/ay\'dan başlıyor. WordPress eklentisi ücretsiz.'),

        // WP Mail SMTP
        array('keywords' => array('wp mail smtp nasıl kurulur', 'smtp nasıl kurulur', 'smtp nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "WP Mail SMTP" ara, kur ve etkinleştir. Sonra Gmail, SendGrid veya başka bir SMTP sağlayıcısıyla yapılandır.'),
        array('keywords' => array('wp mail smtp ne işe yarar', 'smtp ne işe yarar'), 'message' => 'WP Mail SMTP, WordPress\'in varsayılan PHP mail fonksiyonu yerine güvenilir bir SMTP sunucusu kullanmasını sağlar. Mail gitmiyor sorununu çözer.'),
        array('keywords' => array('wp mail smtp ücretsiz mi', 'smtp ucretsiz mi'), 'message' => 'WP Mail SMTP\'nin ücretsiz sürümü çoğu ihtiyacı karşılar. Pro sürümü e-posta log ve gelişmiş özellikler sunar, ~$49/yıl.'),

        // Slider Revolution
        array('keywords' => array('slider revolution nasıl kurulur', 'revslider nasıl kurulur'), 'message' => 'Slider Revolution ücretlidir. codecanyon.net\'ten satın alıp indirdikten sonra Eklentiler → Eklenti Yükle\'den zip dosyasını yükleyebilirsin.'),
        array('keywords' => array('slider revolution ne işe yarar', 'revslider ne işe yarar'), 'message' => 'Slider Revolution, animasyonlu slider, hero bölümü ve tam sayfa efektleri oluşturmak için kullanılır. 200+ hazır şablon içerir.'),
        array('keywords' => array('slider revolution ücretsiz mi', 'revslider ucretsiz mi'), 'message' => 'Slider Revolution ücretlidir. Codecanyon\'da ~$89 (tek seferlik). Bazı temalar Slider Revolution\'ı ücretsiz dahil eder.'),

        // Tema bilgileri
        array('keywords' => array('astra nasıl kurulur', 'astra nasil kurulur'), 'message' => 'Görünüm → Temalar → Yeni Ekle\'ye git, "Astra" ara ve kur. Ücretsiz sürümü hemen kullanılabilir.'),
        array('keywords' => array('astra ne işe yarar', 'astra ne ise yarar'), 'message' => 'Astra, hafif ve hızlı bir WordPress temasıdır. Elementor, Beaver Builder ve Gutenberg ile mükemmel uyum sağlar. Starter şablonlarıyla dakikalar içinde profesyonel site kurabilirsin.'),
        array('keywords' => array('astra ücretsiz mi', 'astra ucretsiz mi'), 'message' => 'Astra\'nın ücretsiz sürümü oldukça kapsamlı. Astra Pro daha fazla özelleştirme seçeneği sunar, ~$47/yıl.'),
        array('keywords' => array('divi nasıl kurulur', 'divi nasil kurulur'), 'message' => 'Divi ücretlidir. elegantthemes.com\'dan satın alıp indirdikten sonra Görünüm → Temalar → Yükle\'den kurabilirsin.'),
        array('keywords' => array('divi ne işe yarar', 'divi ne ise yarar'), 'message' => 'Divi, Elegant Themes\'in hem tema hem sayfa oluşturucusudur. Divi Builder ile sürükle-bırak tasarım yapabilir, 800+ hazır layout kullanabilirsin.'),
        array('keywords' => array('divi ücretsiz mi', 'divi ucretsiz mi'), 'message' => 'Divi ücretlidir. Yıllık ~$89 veya tek seferlik ~$249 (ömür boyu). Tüm Elegant Themes ürünlerini kapsar.'),
        array('keywords' => array('generatepress nasıl kurulur', 'generatepress nasil kurulur'), 'message' => 'Görünüm → Temalar → Yeni Ekle\'ye git, "GeneratePress" ara ve kur. Ücretsiz sürümü hemen kullanılabilir.'),
        array('keywords' => array('generatepress ne işe yarar', 'generatepress ne ise yarar'), 'message' => 'GeneratePress, son derece hafif (~30KB) ve hızlı bir WordPress temasıdır. Modüler yapısıyla sadece ihtiyacın olan özellikleri etkinleştirebilirsin.'),
        array('keywords' => array('generatepress ücretsiz mi', 'generatepress ucretsiz mi'), 'message' => 'GeneratePress\'in ücretsiz sürümü mevcut. GP Premium tüm modülleri açar, ~$59/yıl.'),

        // WooCommerce detay soruları
        array('keywords' => array('woocommerce stripe nasıl', 'stripe kurulum', 'stripe entegrasyon'), 'message' => 'Stripe entegrasyonu için WooCommerce → Eklentiler\'den "WooCommerce Stripe Payment Gateway" eklentisini kur. Stripe hesabından API key alıp WooCommerce → Ayarlar → Ödemeler bölümüne gir.'),
        array('keywords' => array('woocommerce iyzico', 'iyzico entegrasyon', 'iyzico kurulum'), 'message' => 'iyzico entegrasyonu için WordPress eklenti dizininden "iyzico WooCommerce" eklentisini kur. iyzico.com\'dan merchant hesabı açıp API key\'leri WooCommerce ödeme ayarlarına gir.'),
        array('keywords' => array('woocommerce paypal', 'paypal entegrasyon', 'paypal kurulum'), 'message' => 'PayPal entegrasyonu WooCommerce\'de varsayılan olarak gelir. WooCommerce → Ayarlar → Ödemeler → PayPal bölümünden PayPal e-posta adresini girerek etkinleştirebilirsin.'),
        array('keywords' => array('woocommerce kargo ücretsiz', 'ucretsiz kargo', 'ücretsiz kargo'), 'message' => 'Ücretsiz kargo için WooCommerce → Ayarlar → Kargo → Kargo Bölgeleri\'ne git, bölgeyi seç ve "Ücretsiz Kargo" yöntemi ekle. Minimum sipariş tutarı veya kupon koşulu belirleyebilirsin.'),
        array('keywords' => array('woocommerce siparis durumu', 'sipariş durumu', 'order status'), 'message' => 'WooCommerce sipariş durumları: Beklemede, İşleniyor, Tamamlandı, İptal Edildi, İade Edildi, Başarısız. Sipariş detay sayfasından durumu manuel olarak değiştirebilirsin.'),
        array('keywords' => array('woocommerce fatura', 'woocommerce invoice', 'fatura eklentisi'), 'message' => 'WooCommerce\'de fatura için "WooCommerce PDF Invoices & Packing Slips" eklentisini kurabilirsin. Ücretsiz sürümü temel fatura ihtiyaçlarını karşılar.'),
        array('keywords' => array('woocommerce para birimi', 'woocommerce currency', 'tl para birimi', 'türk lirası'), 'message' => 'Para birimi için WooCommerce → Ayarlar → Genel sekmesine git. Para birimi olarak "Türk Lirası (₺)" seçip konumu "Türkiye" olarak ayarlayabilirsin.'),

        // Jetpack
        array('keywords' => array('jetpack nasıl kurulur', 'jetpack nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Jetpack" ara, kur ve etkinleştir. Kurulum için WordPress.com hesabına bağlanman gerekiyor.'),
        array('keywords' => array('jetpack ne işe yarar', 'jetpack ne ise yarar'), 'message' => 'Jetpack, güvenlik, performans, istatistik, CDN, yedekleme ve daha fazlasını tek eklentide sunar. Automattic tarafından geliştirilir. Özellikle küçük siteler için hepsi bir arada çözüm.'),
        array('keywords' => array('jetpack ücretsiz mi', 'jetpack ucretsiz mi'), 'message' => 'Jetpack\'in ücretsiz sürümü istatistik, CDN ve temel güvenlik sunar. Otomatik yedekleme ve gerçek zamanlı güvenlik için Jetpack Security planı ~$9/ay\'dan başlıyor.'),

        // Multisite
        array('keywords' => array('multisite nasıl kurulur', 'multisite nasil kurulur', 'wordpress network kurulum'), 'message' => 'WordPress Multisite için wp-config.php dosyasına define(\'WP_ALLOW_MULTISITE\', true); ekle. Sonra Araçlar → Ağ Kur menüsü belirecek. Subdomain veya alt dizin yapısını seçip kurulumu tamamla.'),
        array('keywords' => array('multisite ne işe yarar', 'multisite ne ise yarar', 'wordpress network ne işe yarar'), 'message' => 'WordPress Multisite, tek bir WordPress kurulumundan birden fazla site yönetmeni sağlar. Ajanslar, eğitim kurumları ve çok şubeli işletmeler için idealdir.'),
        array('keywords' => array('multisite ücretsiz mi', 'multisite ucretsiz mi'), 'message' => 'WordPress Multisite tamamen ücretsiz, WordPress core\'un bir parçası. Sadece hosting maliyeti var — tüm siteleri tek bir hosting hesabında barındırabilirsin.'),

        // Hosting soruları
        array('keywords' => array('hangi hosting', 'hosting önerisi', 'hosting tavsiye', 'en iyi hosting'), 'message' => 'WordPress için popüler hosting seçenekleri: SiteGround ve Kinsta (yönetilen, hızlı), Cloudways (bulut tabanlı, esnek), Hostinger ve Bluehost (uygun fiyatlı). Türkiye\'de Turhost ve Natro da yaygın kullanılıyor.'),
        array('keywords' => array('hosting tasima', 'hosting taşıma', 'site tasima', 'site taşıma', 'migrate'), 'message' => 'Site taşıma için "All-in-One WP Migration" veya "Duplicator" eklentilerini kullanabilirsin. Ücretsiz sürümleri çoğu site için yeterli. UpdraftPlus ile yedek alıp yeni hostinge geri yüklemek de işe yarar.'),
        array('keywords' => array('wordpress hizlandirma', 'wordpress hızlandırma', 'site hizlandirma', 'site hızlandırma', 'core web vitals'), 'message' => 'WordPress hızlandırma için: 1) Cache eklentisi kur (WP Rocket veya LiteSpeed Cache), 2) Görselleri optimize et (Smush veya ShortPixel), 3) CDN kullan (Cloudflare ücretsiz), 4) Kaliteli hosting seç, 5) Gereksiz eklentileri kaldır.'),

        // Güvenlik soruları
        array('keywords' => array('wordpress güvenli mi', 'wordpress guvenli mi', 'wordpress güvenlik'), 'message' => 'WordPress güvenli bir platformdur ama doğru yapılandırma şart. Temel önlemler: güncel tut, güçlü şifre kullan, güvenlik eklentisi kur (Wordfence), düzenli yedek al, gereksiz eklentileri kaldır.'),
        array('keywords' => array('wordfence nasıl kullanılır', 'wordfence nasil kullanilir', 'wordfence tarama'), 'message' => 'Wordfence kurulumdan sonra otomatik tarama başlatır. Manuel tarama için Wordfence → Tarama menüsüne git. Firewall kurallarını Wordfence → Firewall bölümünden yapılandırabilirsin.'),
        array('keywords' => array('cloudflare nedir', 'cloudflare ne işe yarar', 'cloudflare kurulum'), 'message' => 'Cloudflare, CDN ve güvenlik hizmeti sunan ücretsiz bir platformdur. DNS\'ini Cloudflare\'e yönlendirerek DDoS koruması, SSL ve hız iyileştirmesi elde edersin. cloudflare.com\'dan ücretsiz hesap aç.'),

        // Medya soruları
        array('keywords' => array('smush nedir', 'smush ne işe yarar', 'smush nasıl kurulur'), 'message' => 'Smush, görselleri otomatik olarak sıkıştıran ve optimize eden bir eklentidir. Eklentiler → Yeni Ekle\'den "Smush" ara ve kur. Ücretsiz sürümü çoğu site için yeterli.'),
        array('keywords' => array('shortpixel nedir', 'shortpixel ne işe yarar'), 'message' => 'ShortPixel, görselleri WebP formatına dönüştürüp sıkıştıran bir optimizasyon eklentisidir. Ücretsiz planda aylık 100 görsel işlenir. Daha fazlası için kredi satın alınabilir.'),
        array('keywords' => array('regenerate thumbnails', 'kucuk resim yenile', 'küçük resim yenile', 'thumbnail yenile'), 'message' => '"Regenerate Thumbnails" eklentisini kur. Araçlar → Regenerate Thumbnails menüsünden tüm görsellerin küçük resimlerini yeniden oluşturabilirsin. Tema değişikliği sonrası özellikle gerekli.'),

        // Genel WordPress soruları
        array('keywords' => array('wordpress nedir', 'wordpress ne işe yarar', 'wordpress ne ise yarar'), 'message' => 'WordPress, dünyanın en popüler içerik yönetim sistemidir (CMS). Tüm web sitelerinin ~43%\'ü WordPress ile çalışır. Blog, kurumsal site, e-ticaret, portfolyo gibi her türlü site yapılabilir. Tamamen ücretsiz ve açık kaynaklı.'),
        array('keywords' => array('wordpress com fark', 'wordpress.com fark', 'wordpress org fark', 'wordpress.org fark'), 'message' => 'WordPress.com: hazır barındırma, sınırlı özelleştirme, ücretsiz plan mevcut. WordPress.org: kendi hostingine kurarsın, tam kontrol, sınırsız özelleştirme. Profesyonel kullanım için WordPress.org önerilir.'),
        array('keywords' => array('gutenberg nedir', 'gutenberg ne işe yarar', 'blok editor nedir'), 'message' => 'Gutenberg, WordPress\'in varsayılan blok editörüdür. İçerikleri bloklar halinde oluşturursun — metin, görsel, video, buton gibi. Elementor veya Divi gibi sayfa oluşturucularla birlikte veya alternatif olarak kullanılabilir.'),
        array('keywords' => array('child theme', 'alt tema', 'child tema', 'tema bozuldu'), 'message' => 'Child theme (alt tema), ana temanın güncellemelerinden etkilenmeden özelleştirme yapmanı sağlar. "Child Theme Configurator" eklentisiyle kolayca oluşturabilirsin. Tema düzenlemelerini her zaman child theme üzerinde yap.'),
        array('keywords' => array('wp cli nedir', 'wp-cli nedir', 'wp cli ne işe yarar'), 'message' => 'WP-CLI, WordPress\'i komut satırından yönetmeni sağlayan bir araçtır. Eklenti kurma, güncelleme, veritabanı işlemleri gibi her şeyi terminal üzerinden yapabilirsin. Geliştiriciler ve sistem yöneticileri için çok kullanışlı.'),
        array('keywords' => array('hooks nedir', 'action nedir', 'filter nedir', 'wordpress hook'), 'message' => 'WordPress hooks sistemi, eklenti ve tema geliştirmenin temelidir. Action hooks (add_action) bir olayda kod çalıştırır, Filter hooks (add_filter) veriyi değiştirir. Bu sistem WordPress\'i son derece esnek kılar.'),
        array('keywords' => array('shortcode nedir', 'shortcode nasıl kullanılır', 'kısa kod'), 'message' => 'Shortcode\'lar köşeli parantez içinde yazılan kısa kodlardır: [gallery], [contact-form-7] gibi. Sayfa veya yazı içine ekleyerek eklenti özelliklerini çağırırsın. Gutenberg\'de shortcode bloğu kullanabilirsin.'),

        // Gutenberg
        array('keywords' => array('gutenberg nasıl kullanılır', 'gutenberg nasil kullanilir', 'blok editör nasıl'), 'message' => 'Gutenberg\'de içerik bloklardan oluşur. "+" butonuyla yeni blok eklersin — metin, görsel, video, buton, tablo gibi. Blokları sürükleyerek yeniden sıralayabilirsin. "/" yazarak hızlı blok arama yapabilirsin.'),
        array('keywords' => array('gutenberg elementor fark', 'gutenberg mı elementor mu', 'hangi editör'), 'message' => 'Gutenberg ücretsiz ve WordPress\'e entegre, basit içerikler için idealdir. Elementor daha gelişmiş tasarım araçları sunar, görsel düzenleme daha güçlüdür. Karmaşık sayfa tasarımları için Elementor, blog yazıları için Gutenberg tercih edilir.'),
        array('keywords' => array('classic editor nasıl kurulur', 'klasik editör nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Classic Editor" ara, kur ve etkinleştir. Ayarlar → Yazma\'dan varsayılan editörü seçebilirsin.'),

        // GDPR / Çerez
        array('keywords' => array('gdpr nedir', 'kvkk nedir', 'gdpr ne işe yarar'), 'message' => 'GDPR (Avrupa) ve KVKK (Türkiye), kullanıcı verilerinin korunmasına dair yasal düzenlemelerdir. WordPress siteniz için gizlilik politikası sayfası, çerez onay bandı ve veri işleme kayıtları gereklidir.'),
        array('keywords' => array('cookieyes nasıl kurulur', 'çerez eklentisi nasıl kurulur', 'cookie consent nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "CookieYes" ara, kur ve etkinleştir. Ücretsiz planı çoğu site için yeterli. Alternatif: Complianz veya GDPR Cookie Consent.'),
        array('keywords' => array('gizlilik politikası nasıl oluşturulur', 'privacy policy nasıl'), 'message' => 'Ayarlar → Gizlilik\'e git, WordPress\'in hazır şablonunu kullanarak gizlilik politikası sayfası oluştur. İçeriği kendi site koşullarına göre düzenle. Hukuki danışmanlık almak da önerilir.'),

        // Sosyal medya
        array('keywords' => array('sosyal medya eklentisi', 'sosyal medya butonu', 'paylaşım butonu'), 'message' => 'Sosyal medya paylaşım butonları için "Social Warfare", "Monarch" veya "AddToAny" eklentilerini kullanabilirsin. Jetpack da sosyal paylaşım özelliği sunar.'),
        array('keywords' => array('facebook pixel', 'meta pixel', 'pixel kurulum'), 'message' => 'Facebook/Meta Pixel kurmak için "PixelYourSite" veya "Meta Pixel for WordPress" eklentisini kullanabilirsin. Alternatif olarak Google Tag Manager üzerinden de eklenebilir.'),
        array('keywords' => array('google tag manager', 'gtm kurulum', 'tag manager'), 'message' => 'Google Tag Manager için "GTM4WP" eklentisini kur. GTM hesabından container ID\'ni alıp eklenti ayarlarına gir. Tüm izleme kodlarını GTM üzerinden yönetmek daha pratiktir.'),

        // Üyelik
        array('keywords' => array('memberpress nasıl kurulur', 'memberpress nasil kurulur'), 'message' => 'MemberPress ücretlidir. memberpress.com\'dan satın alıp indirdikten sonra Eklentiler → Eklenti Yükle\'den zip dosyasını yükleyebilirsin.'),
        array('keywords' => array('memberpress ne işe yarar', 'memberpress ne ise yarar'), 'message' => 'MemberPress, WordPress sitenize üyelik sistemi ekler. Ücretli içerik, kurs satışı, abonelik planları ve içerik kısıtlama özelliklerini kolayca yönetebilirsin.'),
        array('keywords' => array('paid memberships pro nasıl kurulur', 'pmpro nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'ye git, "Paid Memberships Pro" ara, kur ve etkinleştir. Temel sürümü ücretsiz, gelişmiş özellikler için ücretli planlar mevcut.'),

        // Geliştirici araçları
        array('keywords' => array('query monitor nasıl kurulur', 'query monitor ne işe yarar'), 'message' => 'Eklentiler → Yeni Ekle\'den "Query Monitor" kur. Admin bar\'da yeni bir menü belirir. Veritabanı sorguları, hook\'lar, HTTP istekleri ve PHP hatalarını gerçek zamanlı izleyebilirsin.'),
        array('keywords' => array('wp optimize nasıl kurulur', 'wp-optimize nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "WP-Optimize" kur. Veritabanı temizleme, önbellek ve görsel sıkıştırma özelliklerini tek eklentide sunar. Ücretsiz sürümü çoğu ihtiyacı karşılar.'),
        array('keywords' => array('broken link checker nasıl kurulur', 'kırık link nasıl bulunur'), 'message' => 'Eklentiler → Yeni Ekle\'den "Broken Link Checker" kur. Kurulum sonrası tüm linkleri otomatik tarar ve kırık olanları Araçlar menüsünde listeler. Büyük sitelerde sunucu yükü oluşturabileceğinden dikkatli kullan.'),

        // Page Builders
        array('keywords' => array('beaver builder nasıl kurulur', 'beaver builder nasil kurulur'), 'message' => 'Beaver Builder\'ın ücretsiz "Lite" sürümü WordPress eklenti dizininde mevcut. Pro sürüm için wpbeaverbuilder.com\'dan satın alabilirsin.'),
        array('keywords' => array('beaver builder ne işe yarar', 'beaver builder ne ise yarar'), 'message' => 'Beaver Builder, sürükle-bırak sayfa oluşturucudur. Elementor\'a benzer ama daha temiz kod üretir ve geliştiriciler arasında popülerdir. Frontend ve backend editörü birlikte çalışır.'),
        array('keywords' => array('bricks builder nedir', 'bricks builder ne işe yarar'), 'message' => 'Bricks Builder, hem tema hem sayfa oluşturucu olan modern bir WordPress aracıdır. Temiz kod üretimi ve hız odaklı yapısıyla geliştiriciler arasında hızla popülerleşiyor. Tek seferlik ~$149.'),
        array('keywords' => array('oxygen builder nedir', 'oxygen builder ne işe yarar'), 'message' => 'Oxygen Builder, WordPress için düşük kod üreten güçlü bir sayfa oluşturucudur. Tema yerine geçer, çok temiz HTML/CSS üretir. Geliştiriciler için idealdir. Tek seferlik ~$129.'),

        // E-posta pazarlama
        array('keywords' => array('fluentcrm nasıl kurulur', 'fluentcrm nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "FluentCRM" ara ve kur. Ücretsiz sürümü temel CRM özelliklerini sunar. Pro sürüm otomasyon ve gelişmiş segmentasyon ekler.'),
        array('keywords' => array('fluentcrm ne işe yarar', 'fluentcrm ne ise yarar'), 'message' => 'FluentCRM, WordPress içinde çalışan bir e-posta pazarlama ve CRM aracıdır. Abone yönetimi, e-posta kampanyaları, otomasyon ve WooCommerce entegrasyonu sunar. Mailchimp\'e uygun fiyatlı alternatif.'),
        array('keywords' => array('mailpoet nasıl kurulur', 'mailpoet nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "MailPoet" ara ve kur. 1000 aboneye kadar ücretsiz. WordPress içinden bülten gönderimi için çok kullanışlı.'),
        array('keywords' => array('mailpoet ne işe yarar', 'mailpoet ne ise yarar'), 'message' => 'MailPoet, WordPress\'ten doğrudan bülten ve e-posta kampanyası göndermenizi sağlar. WooCommerce ile entegre çalışır, terk edilmiş sepet e-postaları da gönderebilir.'),

        // Rezervasyon
        array('keywords' => array('amelia nasıl kurulur', 'amelia nasil kurulur'), 'message' => 'Amelia\'nın ücretsiz "Lite" sürümü WordPress eklenti dizininde mevcut. Pro sürüm için wpamelia.com\'dan satın alabilirsin.'),
        array('keywords' => array('amelia ne işe yarar', 'amelia ne ise yarar'), 'message' => 'Amelia, güzel arayüzlü bir randevu ve rezervasyon eklentisidir. Çoklu hizmet, çoklu personel, ödeme entegrasyonu ve takvim senkronizasyonu sunar. Güzellik salonları, klinikler ve danışmanlar için idealdir.'),
        array('keywords' => array('bookly nasıl kurulur', 'bookly nasil kurulur'), 'message' => 'Bookly\'nin ücretsiz sürümü WordPress eklenti dizininde mevcut. Ücretli eklentilerle özellikler genişletilebilir.'),

        // Marketplace
        array('keywords' => array('dokan nasıl kurulur', 'dokan nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "Dokan" ara ve kur. WooCommerce\'in kurulu olması gerekiyor. Ücretsiz sürümü temel marketplace özelliklerini sunar.'),
        array('keywords' => array('dokan ne işe yarar', 'dokan ne ise yarar'), 'message' => 'Dokan, WooCommerce üzerine çok satıcılı marketplace sistemi kurar. Her satıcının kendi mağazası, ürünleri ve komisyon ayarları olur. Amazon/Etsy benzeri bir yapı oluşturabilirsin.'),
        array('keywords' => array('dokan ücretsiz mi', 'dokan ucretsiz mi'), 'message' => 'Dokan\'ın ücretsiz sürümü temel marketplace özelliklerini sunar. Pro sürüm gelişmiş komisyon, abonelik ve raporlama ekler, ~$149/yıl\'dan başlıyor.'),

        // İçerik araçları
        array('keywords' => array('duplicate post nasıl kurulur', 'sayfa kopyalama eklentisi'), 'message' => 'Eklentiler → Yeni Ekle\'den "Yoast Duplicate Post" ara ve kur. Kurulum sonrası yazı/sayfa listesinde "Klonla" seçeneği belirir.'),
        array('keywords' => array('schema markup nasıl eklenir', 'yapısal veri nasıl eklenir'), 'message' => 'Schema markup için Rank Math (ücretsiz, kapsamlı) veya "Schema Pro" eklentisini kullanabilirsin. Rank Math\'ta her yazı/sayfa için otomatik schema tipi atanır.'),

        // LMS
        array('keywords' => array('learndash nasıl kurulur', 'learndash nasil kurulur'), 'message' => 'LearnDash ücretlidir. learndash.com\'dan satın alıp indirdikten sonra Eklentiler → Eklenti Yükle\'den zip dosyasını yükleyebilirsin.'),
        array('keywords' => array('learndash ne işe yarar', 'learndash ne ise yarar'), 'message' => 'LearnDash, WordPress için en güçlü LMS eklentilerinden biridir. Kurs oluşturma, quiz, sertifika, damla içerik (drip content) ve WooCommerce entegrasyonu sunar. Üniversiteler ve büyük eğitim platformları tarafından kullanılır.'),
        array('keywords' => array('lifterlms nasıl kurulur', 'lifterlms nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "LifterLMS" ara ve kur. Temel sürümü ücretsiz. Ödeme entegrasyonu ve gelişmiş özellikler için eklentiler satın alınabilir.'),
        array('keywords' => array('lifterlms ne işe yarar', 'lifterlms ne ise yarar'), 'message' => 'LifterLMS, kurs, üyelik ve topluluk özelliklerini bir arada sunan kapsamlı bir LMS çözümüdür. Stripe ve PayPal entegrasyonu, sertifika ve başarı rozeti sistemi içerir.'),
        array('keywords' => array('tutor lms nasıl kurulur', 'tutor lms nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "Tutor LMS" ara ve kur. Ücretsiz sürümü temel kurs özelliklerini sunar. Pro sürüm gelişmiş quiz ve sertifika ekler.'),
        array('keywords' => array('tutor lms ne işe yarar', 'tutor lms ne ise yarar'), 'message' => 'Tutor LMS, modern arayüzlü bir WordPress kurs eklentisidir. Ön yüz kurs oluşturma, video dersler, quiz, sertifika ve Elementor entegrasyonu sunar.'),
        array('keywords' => array('hangi lms', 'lms karşılaştırma', 'lms önerisi', 'en iyi lms'), 'message' => 'WordPress LMS karşılaştırması: LearnDash (en güçlü, kurumsal), LifterLMS (kapsamlı, ücretsiz başlangıç), Tutor LMS (modern arayüz, Elementor uyumlu), Sensei LMS (WooCommerce entegrasyonu). Küçük projeler için Tutor LMS veya LifterLMS, büyük platformlar için LearnDash önerilir.'),

        // Popup / Lead Generation
        array('keywords' => array('optinmonster nasıl kurulur', 'optinmonster nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "OptinMonster" ara ve kur. optinmonster.com\'dan hesap açıp API key almanız gerekiyor. Ücretsiz plan sınırlı özellik sunar.'),
        array('keywords' => array('optinmonster ne işe yarar', 'optinmonster ne ise yarar'), 'message' => 'OptinMonster, çıkış niyeti popup\'ları, kaydırma kutuları, tam sayfa overlay ve daha fazlasıyla e-posta listesi büyütmek için kullanılır. A/B testi ve gelişmiş hedefleme sunar.'),
        array('keywords' => array('popup maker nasıl kurulur', 'popup maker nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "Popup Maker" ara ve kur. Ücretsiz sürümü temel popup ihtiyaçlarını karşılar.'),

        // 301 Yönlendirme
        array('keywords' => array('redirection eklentisi nasıl kurulur', '301 yönlendirme nasıl yapılır'), 'message' => 'Eklentiler → Yeni Ekle\'den "Redirection" ara ve kur. Araçlar → Redirection menüsünden eski URL\'yi yeni URL\'ye yönlendirebilirsin. 404 logları da otomatik tutulur.'),
        array('keywords' => array('redirection ne işe yarar', 'redirection eklentisi ne işe yarar'), 'message' => 'Redirection eklentisi, URL değişikliklerinde 301 yönlendirme yapmanı sağlar. SEO açısından kritik — eski URL\'leri yeni URL\'lere yönlendirmezsen Google sıralaması kaybedilir.'),

        // REST API
        array('keywords' => array('rest api nedir', 'wordpress rest api nedir'), 'message' => 'WordPress REST API, sitenizin verilerine JSON formatında erişim sağlar. /wp-json/wp/v2/posts gibi endpoint\'lerle yazıları, sayfaları ve özel içerikleri okuyup yazabilirsin. React, Vue veya mobil uygulama geliştirmek için kullanılır.'),
        array('keywords' => array('headless wordpress nedir', 'headless wp nedir'), 'message' => 'Headless WordPress\'te WordPress sadece içerik yönetimi (backend) için kullanılır, ön yüz React/Next.js/Vue gibi modern framework\'lerle ayrı geliştirilir. REST API veya GraphQL (WPGraphQL) üzerinden veri çekilir.'),

        // Cloudflare
        array('keywords' => array('cloudflare nasıl kurulur', 'cloudflare nasil kurulur', 'cloudflare wordpress kurulum'), 'message' => 'Cloudflare kurmak için: 1) cloudflare.com\'da ücretsiz hesap aç, 2) Domain\'ini ekle, 3) Cloudflare\'in verdiği nameserver\'ları domain kayıt şirketine gir, 4) WordPress eklentisini kur. DNS yayılması 24-48 saat sürebilir.'),
        array('keywords' => array('cloudflare ne işe yarar', 'cloudflare ne ise yarar'), 'message' => 'Cloudflare; CDN (içerik dağıtım ağı), DDoS koruması, ücretsiz SSL, DNS yönetimi ve önbellekleme sunar. Ücretsiz planı çoğu site için yeterli ve sitenizi hem hızlandırır hem korur.'),
        array('keywords' => array('cloudflare ücretsiz mi', 'cloudflare ucretsiz mi'), 'message' => 'Cloudflare\'in ücretsiz planı CDN, SSL, DDoS koruması ve temel güvenlik kurallarını içerir. Pro plan ~$20/ay ile gelişmiş WAF ve önbellek kuralları ekler.'),

        // Performans
        array('keywords' => array('core web vitals nedir', 'lcp nedir', 'cls nedir', 'inp nedir'), 'message' => 'Core Web Vitals, Google\'ın sayfa deneyimi ölçütleridir: LCP (en büyük içerik boyaması, <2.5sn olmalı), CLS (kümülatif düzen kayması, <0.1 olmalı), INP (sonraki boyamaya etkileşim, <200ms olmalı). Bu metrikler SEO sıralamasını etkiler.'),
        array('keywords' => array('lazy load nedir', 'lazy loading nedir', 'geciktirmeli yükleme'), 'message' => 'Lazy load, görsellerin ve videoların sadece ekrana geldiğinde yüklenmesini sağlar. Sayfa ilk yükleme hızını önemli ölçüde artırır. WP Rocket, LiteSpeed Cache ve Jetpack bu özelliği sunar. WordPress 5.5\'ten itibaren görsellere otomatik uygulanır.'),

        // Galeri
        array('keywords' => array('envira gallery nasıl kurulur', 'envira gallery ne işe yarar'), 'message' => 'Eklentiler → Yeni Ekle\'den "Envira Gallery" ara ve kur. Sürükle-bırak galeri oluşturucu, lightbox ve albüm desteği sunar. Ücretsiz sürümü temel galeri ihtiyaçlarını karşılar.'),
        array('keywords' => array('foogallery nasıl kurulur', 'foogallery ne işe yarar'), 'message' => 'Eklentiler → Yeni Ekle\'den "FooGallery" ara ve kur. Masonry, justified ve slider gibi farklı galeri düzenleri sunar. Ücretsiz sürümü oldukça kapsamlı.'),
        array('keywords' => array('en iyi galeri eklentisi', 'galeri eklentisi önerisi'), 'message' => 'WordPress galeri eklentisi karşılaştırması: Envira Gallery (hızlı, kullanıcı dostu), FooGallery (esnek düzenler), Modula (modern tasarım), NextGEN Gallery (en eski ve kapsamlı). Basit ihtiyaçlar için Gutenberg\'in yerleşik galeri bloğu da yeterli olabilir.'),

        // Sosyal kanıt
        array('keywords' => array('google reviews nasıl eklenir', 'google yorumları nasıl gösterilir'), 'message' => 'Google yorumlarını sitenizde göstermek için "WP Google Review Slider" veya "Google Reviews Widget" eklentisini kur. Google Places API key gerekiyor — Google Cloud Console\'dan ücretsiz alabilirsin.'),
        array('keywords' => array('trustpilot nasıl entegre edilir', 'trustpilot wordpress'), 'message' => 'Trustpilot\'un resmi WordPress eklentisini Eklentiler → Yeni Ekle\'den kurabilirsin. Trustpilot hesabından widget kodu alıp sayfana da ekleyebilirsin.'),

        // WooCommerce abonelik
        array('keywords' => array('woocommerce subscriptions nasıl kurulur', 'woocommerce abonelik nasıl kurulur'), 'message' => 'WooCommerce Subscriptions ücretlidir. woocommerce.com\'dan satın alıp indirdikten sonra Eklentiler → Eklenti Yükle\'den yükleyebilirsin. Stripe veya PayPal ile tekrarlayan ödeme alabilirsin.'),
        array('keywords' => array('woocommerce subscriptions ne işe yarar', 'woocommerce abonelik ne işe yarar'), 'message' => 'WooCommerce Subscriptions, aylık/yıllık tekrarlayan ödeme sistemi kurmanı sağlar. Abonelik planları, ücretsiz deneme, abonelik duraklatma ve yenileme e-postaları gibi özellikler içerir.'),

        // Güvenlik sertleştirme
        array('keywords' => array('wps hide login nasıl kurulur', 'login url nasıl değiştirilir'), 'message' => 'Eklentiler → Yeni Ekle\'den "WPS Hide Login" ara ve kur. Ayarlar → WPS Hide Login\'den yeni login URL\'ni belirle. Eski wp-admin ve wp-login.php URL\'leri 404 döndürür.'),
        array('keywords' => array('recaptcha nasıl eklenir', 'recaptcha nasıl kurulur'), 'message' => 'Google reCAPTCHA için: 1) google.com/recaptcha\'dan site key al, 2) Kullandığın form eklentisinin reCAPTCHA ayarlarına gir (CF7, WPForms, Gravity Forms hepsi destekler), 3) Key\'leri gir ve kaydet.'),
        array('keywords' => array('wordpress güvenlik kontrol listesi', 'wordpress security checklist'), 'message' => 'WordPress güvenlik kontrol listesi: ✓ Güncel tut (WP + eklentiler + temalar), ✓ Güçlü şifre kullan, ✓ "admin" kullanıcı adını değiştir, ✓ Login URL\'yi gizle, ✓ 2FA ekle, ✓ Wordfence kur, ✓ SSL aktif et, ✓ Düzenli yedek al, ✓ Gereksiz eklentileri kaldır, ✓ Dosya düzenlemeyi kapat.'),

        // CPT
        array('keywords' => array('custom post type nasıl oluşturulur', 'özel içerik türü nasıl oluşturulur'), 'message' => '"Custom Post Type UI" eklentisini kur. CPT UI → Yeni İçerik Türü Ekle\'den adı, etiketi ve ayarları belirle. ACF ile özel alanlar ekleyerek tam özelleştirilmiş içerik yapısı oluşturabilirsin.'),
        array('keywords' => array('custom post type ne işe yarar', 'özel içerik türü ne işe yarar'), 'message' => 'Custom Post Types, WordPress\'in varsayılan yazı ve sayfa yapısının ötesinde özel içerik türleri oluşturmanı sağlar. Portföy, etkinlik, ürün, ekip üyesi gibi yapılandırılmış içerikler için idealdir.'),

        // Genel sorular
        array('keywords' => array('wordpress güncellemesi nasıl yapılır', 'wordpress nasıl güncellenir'), 'message' => 'WordPress güncellemesi için Gösterge Paneli → Güncellemeler sayfasına git. Önce yedek al, sonra WordPress çekirdeğini, ardından eklentileri ve temaları güncelle. Otomatik güncelleme için wp-config.php\'ye define(\'WP_AUTO_UPDATE_CORE\', true); ekleyebilirsin.'),
        array('keywords' => array('wordpress yeniden kurulum', 'wordpress sıfırlama', 'wordpress reset'), 'message' => 'WordPress\'i sıfırlamak için "WP Reset" eklentisini kullanabilirsin. Tüm içerik ve ayarları siler ama WordPress kurulumunu korur. Dikkatli kullan — geri alınamaz!'),
        array('keywords' => array('wp config nedir', 'wp-config nedir', 'wp-config.php nedir'), 'message' => 'wp-config.php, WordPress\'in ana yapılandırma dosyasıdır. Veritabanı bağlantısı, güvenlik anahtarları, debug modu, bellek limiti gibi kritik ayarlar burada tanımlanır. FTP veya hosting dosya yöneticisinden erişilebilir.'),
        array('keywords' => array('htaccess nedir', '.htaccess nedir', 'htaccess ne işe yarar'), 'message' => '.htaccess, Apache web sunucusu için yapılandırma dosyasıdır. WordPress permalink\'leri, yönlendirmeler, güvenlik kuralları ve önbellek başlıkları burada tanımlanır. WordPress otomatik yönetir ama manuel düzenleme de yapılabilir.'),

        // Affiliate
        array('keywords' => array('affiliatewp nasıl kurulur', 'affiliatewp nasil kurulur'), 'message' => 'AffiliateWP ücretlidir. affiliatewp.com\'dan satın alıp indirdikten sonra Eklentiler → Eklenti Yükle\'den yükleyebilirsin. WooCommerce ve Easy Digital Downloads ile entegre çalışır.'),
        array('keywords' => array('affiliatewp ne işe yarar', 'affiliatewp ne ise yarar'), 'message' => 'AffiliateWP, WordPress sitenize ortaklık programı ekler. Affiliateler kayıt olur, özel linklerle satış yapar ve komisyon kazanır. Gerçek zamanlı raporlama ve otomatik ödeme özellikleri sunar.'),
        array('keywords' => array('pretty links nasıl kurulur', 'pretty links ne işe yarar'), 'message' => 'Eklentiler → Yeni Ekle\'den "Pretty Links" ara ve kur. Uzun affiliate linklerini yourdomain.com/go/urun gibi kısa ve temiz URL\'lere dönüştürür. Tıklama istatistikleri de tutar.'),
        array('keywords' => array('affiliate marketing nedir', 'ortaklık pazarlaması nedir'), 'message' => 'Affiliate marketing, başkalarının ürünlerini tanıtarak komisyon kazanma modelidir. WordPress\'te AffiliateWP ile kendi affiliate programını kurabilir veya Amazon, Trendyol gibi platformların affiliate programlarına katılabilirsin.'),

        // Checkout
        array('keywords' => array('cartflows nasıl kurulur', 'cartflows nasil kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "CartFlows" ara ve kur. WooCommerce\'in kurulu olması gerekiyor. Ücretsiz sürümü temel satış hunisi özelliklerini sunar.'),
        array('keywords' => array('cartflows ne işe yarar', 'cartflows ne ise yarar'), 'message' => 'CartFlows, WooCommerce için satış hunisi oluşturur. Özel checkout sayfaları, upsell/downsell teklifleri, sipariş tümsekleri ve A/B testi ile dönüşüm oranını artırır.'),
        array('keywords' => array('terk edilmiş sepet nasıl kurtarılır', 'abandoned cart nasıl çözülür'), 'message' => 'Terk edilmiş sepet kurtarma için: 1) "Abandoned Cart Lite" eklentisini kur, 2) Otomatik hatırlatma e-postaları ayarla, 3) İndirim kuponu ekle. FluentCRM ve Mailchimp de bu özelliği sunar. Ortalama %15-20 sepet kurtarma oranı elde edilebilir.'),

        // Video
        array('keywords' => array('presto player nasıl kurulur', 'presto player ne işe yarar'), 'message' => 'Eklentiler → Yeni Ekle\'den "Presto Player" ara ve kur. YouTube, Vimeo, Bunny.net ve yerel video desteği sunar. Notlar, e-posta toplama ve ilerleme takibi gibi özellikler içerir. LMS eklentileriyle mükemmel uyum sağlar.'),
        array('keywords' => array('bunny net nedir', 'bunny.net nedir', 'video cdn'), 'message' => 'Bunny.net, uygun fiyatlı bir video hosting ve CDN platformudur. WordPress\'e Presto Player veya özel entegrasyonla bağlanabilir. YouTube\'a alternatif olarak kendi videolarını barındırmak için idealdir.'),

        // Arama
        array('keywords' => array('searchwp nasıl kurulur', 'searchwp ne işe yarar'), 'message' => 'SearchWP ücretlidir. searchwp.com\'dan satın alıp indirdikten sonra yükleyebilirsin. WordPress\'in varsayılan aramasını tamamen değiştirir, özel alan ve içerik türlerinde de arama yapabilir.'),
        array('keywords' => array('relevanssi nasıl kurulur', 'relevanssi ne işe yarar'), 'message' => 'Eklentiler → Yeni Ekle\'den "Relevanssi" ara ve kur. Ücretsiz sürümü WordPress aramasını önemli ölçüde iyileştirir. Fuzzy matching, önem ağırlıklandırma ve arama vurgulama sunar.'),

        // EDD
        array('keywords' => array('easy digital downloads nasıl kurulur', 'edd nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "Easy Digital Downloads" ara ve kur. Ücretsiz sürümü temel dijital ürün satışı için yeterli. Stripe ve PayPal eklentileri ayrıca kurulur.'),
        array('keywords' => array('easy digital downloads ne işe yarar', 'edd ne işe yarar'), 'message' => 'Easy Digital Downloads (EDD), PDF, yazılım, müzik, fotoğraf gibi dijital ürünleri satmak için tasarlanmış bir e-ticaret eklentisidir. WooCommerce\'den daha hafif ve dijital odaklıdır.'),

        // Genel WordPress soruları devamı
        array('keywords' => array('wordpress multisite mi tekli mi', 'multisite ne zaman kullanılır'), 'message' => 'Multisite şu durumlarda idealdir: birden fazla siteyi tek panelden yönetmek, aynı temayı/eklentileri paylaşmak, ajans veya eğitim kurumu gibi çok siteli yapılar. Tek site için gereksiz karmaşıklık yaratır.'),
        array('keywords' => array('wordpress backup ne sıklıkla', 'ne kadar sıklıkla yedek alınmalı'), 'message' => 'Yedekleme sıklığı site aktivitesine göre değişir: aktif e-ticaret siteleri için günlük, blog için haftalık, statik siteler için aylık yedek önerilir. UpdraftPlus ile otomatik zamanlama yapabilirsin.'),
        array('keywords' => array('wordpress staging', 'test ortamı', 'staging site', 'geliştirme ortamı'), 'message' => 'Staging (test) ortamı için hosting sağlayıcınızın staging özelliğini kullan (SiteGround, Kinsta, WP Engine hepsi sunar). Alternatif olarak "WP Staging" eklentisiyle tek tıkla staging site oluşturabilirsin.'),

        // Etkinlik
        array('keywords' => array('the events calendar nasıl kurulur', 'events calendar nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "The Events Calendar" ara ve kur. Ücretsiz sürümü temel etkinlik ihtiyaçlarını karşılar. Bilet satışı için "Event Tickets" eklentisini de ekleyebilirsin.'),
        array('keywords' => array('the events calendar ne işe yarar', 'events calendar ne işe yarar'), 'message' => 'The Events Calendar, WordPress\'e etkinlik yönetimi ekler. Etkinlik oluşturma, takvim görünümü, liste görünümü, Google Maps entegrasyonu ve tekrarlayan etkinlikler sunar.'),
        array('keywords' => array('etkinlik bileti nasıl satılır', 'event ticket nasıl kurulur'), 'message' => '"Event Tickets" eklentisini The Events Calendar ile birlikte kur. Ücretsiz bilet için yeterli. Ücretli bilet için "Event Tickets Plus" veya WooCommerce entegrasyonu gerekir.'),

        // Harita
        array('keywords' => array('google maps api key nasıl alınır', 'google maps api key'), 'message' => 'Google Maps API key için: 1) console.cloud.google.com\'a git, 2) Yeni proje oluştur, 3) Maps JavaScript API\'yi etkinleştir, 4) Kimlik Bilgileri → API Key oluştur. Ücretsiz kullanım limiti çoğu site için yeterli.'),
        array('keywords' => array('wp google maps nasıl kurulur', 'harita eklentisi nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "WP Google Maps" ara ve kur. Google Maps API key girerek harita oluşturabilirsin. Shortcode ile sayfana ekleyebilirsin.'),

        // Sosyal giriş
        array('keywords' => array('nextend social login nasıl kurulur', 'google ile giriş nasıl eklenir'), 'message' => 'Eklentiler → Yeni Ekle\'den "Nextend Social Login" ara ve kur. Google için Google Cloud Console\'dan OAuth credentials oluşturman gerekiyor. Facebook için Meta Developer hesabı gerekir.'),
        array('keywords' => array('sosyal giriş neden kullanılır', 'social login faydası'), 'message' => 'Sosyal giriş, kullanıcıların yeni şifre oluşturmadan mevcut Google/Facebook hesaplarıyla giriş yapmasını sağlar. Kayıt oranını artırır, şifre unutma sorunlarını azaltır.'),

        // WooCommerce ürün tipleri
        array('keywords' => array('değişken ürün nasıl oluşturulur', 'varyasyonlu ürün nasıl yapılır'), 'message' => '1) Ürün ekle sayfasında "Ürün Tipi" → "Değişken Ürün" seç, 2) Özellikler sekmesinden renk/beden ekle ve "Varyasyonlar için kullan" işaretle, 3) Varyasyonlar sekmesinden "Tüm varyasyonları oluştur" tıkla, 4) Her varyasyon için fiyat ve stok gir.'),
        array('keywords' => array('woocommerce ürün görseli', 'ürün fotoğrafı', 'ürün galerisi woocommerce'), 'message' => 'Ürün ana görseli ve galeri görselleri ürün düzenleme ekranının sağ tarafından eklenir. Önerilen boyut: en az 800x800px, kare format. WooCommerce → Ayarlar → Ürünler\'den görsel boyutlarını ayarlayabilirsin.'),

        // İçerik planlama
        array('keywords' => array('editorial workflow nedir', 'içerik onay süreci', 'yayın onayı'), 'message' => 'WordPress\'te içerik onay süreci için "PublishPress" eklentisini kullanabilirsin. Editör onayı, içerik takvimi ve bildirimler sunar. Küçük ekipler için WordPress\'in yerleşik "İnceleme Bekliyor" durumu da yeterli olabilir.'),
        array('keywords' => array('publishpress nedir', 'publishpress nasıl kurulur'), 'message' => 'Eklentiler → Yeni Ekle\'den "PublishPress" ara ve kur. İçerik takvimi, özel yazı durumları, editör bildirimleri ve yorum sistemi sunar. Ekip halinde içerik üretimi için idealdir.'),

        // Genel son sorular
        array('keywords' => array('wordpress öğrenmek istiyorum', 'wordpress nasıl öğrenilir', 'wordpress eğitimi'), 'message' => 'WordPress öğrenmek için: 1) wordpress.org/documentation resmi dokümantasyon, 2) WPBeginner (wpbeginner.com) Türkçe ve İngilizce kaynaklar, 3) YouTube\'da ücretsiz kurslar, 4) Udemy\'de ücretli kurslar. En iyi yol: kendi test sitenizi kurarak pratik yapmak.'),
        array('keywords' => array('wordpress ajans', 'wordpress freelance', 'wordpress ile para kazanmak'), 'message' => 'WordPress ile para kazanma yolları: Freelance site yapımı, ajans kurma, premium tema/eklenti satışı, WordPress eğitimi verme, bakım hizmetleri sunma. Türkiye\'de WordPress geliştiricisi talebi oldukça yüksek.'),
        array('keywords' => array('wordpress lisans', 'wordpress ücretli mi', 'wordpress bedava mı'), 'message' => 'WordPress.org tamamen ücretsiz ve açık kaynaklıdır (GPL lisansı). Hosting, premium tema ve eklentiler için ödeme yapılır ama WordPress\'in kendisi ücretsizdir. WordPress.com\'un ücretli planları da mevcuttur.'),
    );

    foreach ($info_routes as $route) {
        foreach ($route['keywords'] as $keyword) {
            if (strpos($q, $keyword) !== false) {
                // route alanı varsa yönlendirme olarak döndür
                if (!empty($route['route'])) {
                    return $route['route'];
                }
                return array(
                    'success'     => false,
                    'message'     => $route['message'],
                    'suggestions' => !empty($route['suggestions']) ? $route['suggestions'] : array(),
                );
            }
        }
    }

    foreach ($routes as $route) {
        foreach ($route['keywords'] as $keyword) {
            if (strpos($q, $keyword) !== false) {
                if (!empty($route['plugin'])) {
                    if (!is_plugin_active($route['plugin'])) {
                        $plugin_name = $route['plugin_name'];
                        return array(
                            'success'     => false,
                            'message'     => $plugin_name . ' bu sitede kurulu görünmüyor ama sorun değil! ' . $plugin_name . ' hakkında her şeyi konuşabiliriz. Ne öğrenmek istersin?',
                            'suggestions' => array(
                                $plugin_name . ' nasıl kurulur',
                                $plugin_name . ' ne işe yarar',
                                $plugin_name . ' ücretsiz mi',
                            ),
                        );
                    }
                }

                return array(
                    'success'    => true,
                    'title'      => $route['title'],
                    'url'        => $route['url'],
                    'confidence' => $route['confidence'],
                    'category'   => $route['category'],
                    'source'     => $route['source'],
                    'message'    => $route['message'],
                    'next_steps' => !empty($route['next_steps']) ? $route['next_steps'] : array(),
                );
            }
        }
    }

    // --- Akıllı fallback: sorguya yakın kategori tahmin et ---
    $smart_suggestions = array(
        'woocommerce' => array(
            'keywords'    => array('magaza', 'mağaza', 'satis', 'satış', 'urun', 'ürün', 'siparis', 'sipariş', 'odeme', 'ödeme', 'kargo', 'e-ticaret', 'eticaret', 'stok'),
            'message'     => 'Bunu tam olarak bulamadım ama e-ticaret konusunda yardımcı olabilirim. Şunları deneyebilirsin:',
            'suggestions' => array('woocommerce sipariş', 'woocommerce ürün', 'woocommerce ödeme yöntemi', 'woocommerce kargo'),
        ),
        'elementor' => array(
            'keywords'    => array('tasarim', 'tasarım', 'sayfa', 'duzen', 'düzen', 'widget', 'blok', 'builder', 'header', 'footer', 'slider', 'banner'),
            'message'     => 'Bunu tam olarak bulamadım ama sayfa tasarımı konusunda yardımcı olabilirim. Şunları deneyebilirsin:',
            'suggestions' => array('elementor düzenleme', 'elementor header', 'elementor şablon', 'elementor global renk'),
        ),
        'seo' => array(
            'keywords'    => array('google', 'arama', 'seo', 'indexleme', 'sıralama', 'siralama', 'meta', 'anahtar kelime', 'keyword'),
            'message'     => 'Bunu tam olarak bulamadım ama SEO konusunda yardımcı olabilirim. Şunları deneyebilirsin:',
            'suggestions' => array('yoast seo ayarları', 'rank math nedir', 'site haritası', 'yoast ne işe yarar'),
        ),
        'guvenlik' => array(
            'keywords'    => array('guvenlik', 'güvenlik', 'sifre', 'şifre', 'giris', 'giriş', 'hack', 'virus', 'spam', 'engel', 'koruma', 'firewall'),
            'message'     => 'Bunu tam olarak bulamadım ama güvenlik konusunda yardımcı olabilirim. Şunları deneyebilirsin:',
            'suggestions' => array('wordfence nasıl kurulur', 'şifre değiştir', 'iki faktörlü doğrulama', 'brute force koruması'),
        ),
        'performans' => array(
            'keywords'    => array('hiz', 'hız', 'yavas', 'yavaş', 'cache', 'onbellek', 'önbellek', 'performans', 'optimize', 'yükleme'),
            'message'     => 'Bunu tam olarak bulamadım ama performans konusunda yardımcı olabilirim. Şunları deneyebilirsin:',
            'suggestions' => array('wordpress hızlandırma', 'wp rocket ne işe yarar', 'litespeed cache nasıl kurulur', 'görsel optimize'),
        ),
        'ceviri' => array(
            'keywords'    => array('dil', 'ceviri', 'çeviri', 'turkce', 'türkçe', 'ingilizce', 'almanca', 'fransizca', 'multilingual', 'cok dilli', 'çok dilli'),
            'message'     => 'Bunu tam olarak bulamadım ama çeviri konusunda yardımcı olabilirim. Şunları deneyebilirsin:',
            'suggestions' => array('loco translate ne işe yarar', 'wpml ne işe yarar', 'polylang nasıl kurulur', 'translatepress nedir'),
        ),
        'hata' => array(
            'keywords'    => array('hata', 'error', 'calismiyor', 'çalışmıyor', 'bozuk', 'acilmiyor', 'açılmıyor', 'gozukmuyor', 'görünmüyor', 'sorun', 'problem'),
            'message'     => 'Bunu tam olarak bulamadım ama hata çözümü konusunda yardımcı olabilirim. Şunları deneyebilirsin:',
            'suggestions' => array('beyaz ekran sorunu', '404 hatası', '500 sunucu hatası', 'kritik hata'),
        ),
        'eklenti' => array(
            'keywords'    => array('eklenti', 'plugin', 'kur', 'yukle', 'yükle', 'install', 'aktif', 'devre disi', 'devre dışı'),
            'message'     => 'Bunu tam olarak bulamadım ama eklenti yönetimi konusunda yardımcı olabilirim. Şunları deneyebilirsin:',
            'suggestions' => array('eklenti nasıl kurulur', 'eklenti güncelleme', 'eklenti çakışması', 'en iyi güvenlik eklentisi'),
        ),
        'tema' => array(
            'keywords'    => array('tema', 'theme', 'gorunum', 'görünüm', 'renk', 'font', 'yazi tipi', 'yazı tipi', 'tasarim', 'tasarım'),
            'message'     => 'Bunu tam olarak bulamadım ama tema konusunda yardımcı olabilirim. Şunları deneyebilirsin:',
            'suggestions' => array('astra ne işe yarar', 'divi nedir', 'child theme nedir', 'elementor ne işe yarar'),
        ),
    );

    foreach ($smart_suggestions as $cat) {
        foreach ($cat['keywords'] as $kw) {
            if (strpos($q, $kw) !== false) {
                return array(
                    'success'     => false,
                    'message'     => $cat['message'],
                    'suggestions' => $cat['suggestions'],
                );
            }
        }
    }

    $groq_active = !empty(aila_get_gemini_key());
    $fallback_msg = $groq_active
        ? 'Bunu tam olarak bulamadım. Soruyu biraz farklı yazabilir ya da aşağıdaki konulardan birini deneyebilirsin:'
        : 'Bunu tam olarak bulamadım. 💡 Groq API key girerek AI modunu aktifleştirirsen çok daha akıllı cevaplar alabilirim!';
    $fallback_suggestions = $groq_active
        ? array('woocommerce sipariş', 'elementor düzenleme', 'yoast seo ayarları', 'wordpress hızlandırma', 'wordfence nasıl kurulur')
        : array('groq key nasıl girerim', 'ai-la ayarları', 'woocommerce sipariş', 'elementor düzenleme');

    return array(
        'success'     => false,
        'message'     => $fallback_msg,
        'suggestions' => $fallback_suggestions,
    );
}

