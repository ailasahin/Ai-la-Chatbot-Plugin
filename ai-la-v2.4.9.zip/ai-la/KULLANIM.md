# Ai-la Kullanım Kılavuzu

## Ai-la Nedir?

Ai-la, WordPress yönetim panelinize entegre olan bir AI destekli asistanıdır. Doğal dilde sorular sorarak WordPress ayarlarını bulabilir, eklenti sorunlarını çözebilir ve adım adım rehberlik alabilirsiniz.

---

## Kurulum

### 1. Eklentiyi Yükleyin
1. WordPress admin paneline giriş yapın
2. **Eklentiler → Eklenti Yükle** menüsüne gidin
3. **Zip Yükle** butonuna tıklayın
4. `ai-la-v2.4.9.zip` dosyasını seçin
5. **Şimdi Yükle** → **Etkinleştir** butonlarına tıklayın

### 2. Groq API Key Alın (Opsiyonel ama Önerilir)
1. [console.groq.com/keys](https://console.groq.com/keys) adresine gidin
2. Ücretsiz hesap oluşturun
3. **Create API Key** butonuna tıklayın
4. Oluşturulan key'i kopyalayın

### 3. Key'i Girin
1. WordPress admin → **Ayarlar → Ai-la** sayfasına gidin
2. **Groq API Key** alanına key'i yapıştırın
3. **Kaydet** butonuna tıklayın
4. **Groq'u Test Et** butonuyla bağlantıyı doğrulayın

> Key girilmezse plugin keyword modu ile çalışır — 200+ konuda yine de yardımcı olur.

---

## Kullanım

### Chat Panelini Açma
- Admin panelinin **sağ alt köşesinde** Ai-la butonu bulunur
- Butona tıklayarak chat panelini açabilirsiniz
- Panel zaten açıksa **⌄** butonuyla küçültebilirsiniz

### Soru Sorma
- Alt kısımdaki metin alanına sorunuzu yazın
- **Enter** tuşuna basın veya **↑** butonuna tıklayın
- Ai-la cevabı birkaç saniye içinde verir

### Hızlı Butonlar
Açılış ekranındaki hızlı butonlara tıklayarak sık kullanılan konulara hızlıca erişebilirsiniz:
- 🖼 Logo
- 🛒 WooCommerce
- 🔍 SEO
- ✏️ Elementor
- ☰ Menü
- 👤 Yetkiler

### Sayfaya Yönlenme
Ai-la bir ayar sayfası bulduğunda **Sayfaya Git →** butonu gösterir. Bu butona tıkladığınızda:
1. İlgili sayfaya yönlendirilirsiniz
2. Chat paneli otomatik açılır
3. O sayfada ne yapmanız gerektiğini adım adım anlatır

### Sohbet Geçmişi
- Sohbet geçmişi otomatik kaydedilir
- Farklı sayfalara geçseniz bile konuşma devam eder
- **🗑** butonuyla geçmişi silebilirsiniz (onay ister)

---

## Neler Sorabilirsiniz?

### WordPress Ayarları
- "Logo nasıl değiştirilir?"
- "Menü nasıl oluşturulur?"
- "Kalıcı bağlantı ayarları nerede?"
- "Kullanıcı rolü nasıl değiştirilir?"

### Eklenti Sorunları
- "WooCommerce siparişleri nerede?"
- "Elementor şablonları nasıl kullanılır?"
- "Yoast SEO site haritası nasıl ayarlanır?"
- "WP Rocket cache nasıl temizlenir?"

### Hata Çözümleri
- "404 hatası nasıl çözülür?"
- "Beyaz ekran sorunu neden olur?"
- "SSL sertifikası nasıl kurulur?"
- "PHP bellek limiti nasıl artırılır?"

### Genel Bilgi
- "WooCommerce ücretsiz mi?"
- "Elementor Pro ne işe yarar?"
- "WordPress nasıl hızlandırılır?"
- "Groq key nasıl girerim?"

### Sohbet
- "Merhaba"
- "Nasılsın?"
- "Teşekkürler"
- "Şimdi ne yapacağım?"

---

## Ayarlar Sayfası

**Ayarlar → Ai-la** sayfasında:

| Bölüm | Açıklama |
|---|---|
| AI Modu | Groq aktif mi, keyword modu mu çalışıyor |
| Versiyon | Yüklü plugin versiyonu |
| Groq API Key | AI entegrasyonu için key girişi |
| Bağlantı Testi | Groq bağlantısını test etme butonu |

---

## Sık Sorulan Sorular

**Groq key olmadan çalışır mı?**
Evet. Key girilmezse 200+ WordPress konusunda keyword tabanlı cevaplar verir. Groq ile daha akıllı ve serbest cevaplar alırsınız.

**Groq ücretsiz mi?**
Evet. Groq'un ücretsiz planı günde 14.400 istek destekler, kart gerektirmez.

**Sohbet geçmişi nerede saklanır?**
Tarayıcının localStorage'ında. Sunucuya gönderilmez, sadece sizin tarayıcınızda kalır.

**Ziyaretçiler Ai-la'yı görebilir mi?**
Hayır. Sadece WordPress'e giriş yapmış admin kullanıcılar görebilir.

**Groq key'im çalınabilir mi?**
Key sadece Groq'a istek atmak için kullanılır. Hesap bilgilerinize erişim sağlamaz. Kota tüketimi olabilir, bu yüzden key'i paylaşmayın.

**Groq key'i nasıl değiştiririm?**
Ayarlar → Ai-la sayfasından istediğiniz zaman yeni key girebilirsiniz.

---

## Desteklenen Konular (Özet)

- WordPress core (50+ ayar sayfası)
- WooCommerce (sipariş, ürün, kargo, ödeme, stok, kupon, abonelik)
- Elementor + 7 eklenti paketi
- Yoast SEO, Rank Math
- Cache eklentileri (6 farklı)
- Çeviri eklentileri (WPML, Loco, Polylang, TranslatePress, Weglot)
- Güvenlik (Wordfence, 2FA, brute force)
- Hata kodları (404, 500, 403, SSL, memory limit)
- Hosting sorunları
- LMS, Rezervasyon, Marketplace, Affiliate
- 200+ genel bilgi sorusu

---

## Versiyon

**Ai-la v2.4.9** · Groq AI (Llama 3.3 70B) destekli
