(function(){
  const overlay   = document.getElementById('ailaOverlay');
  const launcher  = document.getElementById('openAila');
  const closeBtn  = document.getElementById('closeAila');
  const newChatBtn= document.getElementById('ailaNewChat');
  const sendBtn   = document.getElementById('ailaSend');
  const prompt    = document.getElementById('ailaPrompt');
  const messages  = document.getElementById('ailaMessages');
  const typingRow = document.getElementById('ailaTypingRow');

  if (!overlay || !launcher || !closeBtn || !sendBtn || !prompt || !messages || !typingRow) return;

  const STORAGE_KEY = 'aila_chat_history';
  const NEXT_KEY    = 'aila_next_steps';
  const MIN_KEY     = 'aila_minimized';
  const THEME_KEY   = 'aila_theme';

  function saveHistory() {
    const items = [];
    messages.querySelectorAll('.dynamic').forEach(n => items.push(n.outerHTML));
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); } catch(e) {}
  }

  function loadHistory() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return;
      JSON.parse(saved).forEach(html => {
        const tmp = document.createElement('div');
        tmp.innerHTML = html;
        const node = tmp.firstChild;
        if (node) messages.insertBefore(node, typingRow);
      });
      messages.scrollTop = messages.scrollHeight;
    } catch(e) {}
  }

  function clearHistory() {
    try { localStorage.removeItem(STORAGE_KEY); localStorage.removeItem(NEXT_KEY); } catch(e) {}
  }

  function saveNextSteps(title, steps) {
    try { localStorage.setItem(NEXT_KEY, JSON.stringify({title, steps})); } catch(e) {}
  }

  function popNextSteps() {
    try {
      const raw = localStorage.getItem(NEXT_KEY);
      if (!raw) return null;
      localStorage.removeItem(NEXT_KEY);
      return JSON.parse(raw);
    } catch(e) { return null; }
  }

  function openPanel() {
    overlay.classList.remove('hidden');
    launcher.classList.remove('visible');
    try { localStorage.removeItem(MIN_KEY); } catch(e) {}
    setTimeout(() => prompt.focus(), 100);
  }

  function minimizePanel() {
    overlay.classList.add('hidden');
    launcher.classList.add('visible');
    saveHistory();
    try { localStorage.setItem(MIN_KEY, '1'); } catch(e) {}
  }

  function resetChat() {
    if (!confirm('Sohbet geçmişi silinsin mi?')) return;
    messages.querySelectorAll('.dynamic').forEach(n => n.remove());
    typingRow.style.display = 'none';
    prompt.value = '';
    clearHistory();
  }

  function escapeHtml(text) {
    const d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
  }

  function addUserMessage(text) {
    const row = document.createElement('div');
    row.className = 'row user dynamic';
    row.innerHTML = '<div class="message user">' + escapeHtml(text) + '</div>';
    messages.insertBefore(row, typingRow);
    messages.scrollTop = messages.scrollHeight;
    saveHistory();
  }

  function addBotHtml(html) {
    const row = document.createElement('div');
    row.className = 'row dynamic';
    row.innerHTML = '<div class="message bot"><div class="bot-head"><div class="bot-mini">✦</div><div>Ai-la</div></div>' + html + '</div>';
    messages.insertBefore(row, typingRow);
    messages.scrollTop = messages.scrollHeight;
    saveHistory();
  }

  function renderNextSteps(title, steps) {
    let html = '<div class="next-steps">';
    html += '<div class="next-steps-title">📍 ' + escapeHtml(title) + '</div>';
    html += '<ol class="next-steps-list">';
    steps.forEach(s => { html += '<li>' + escapeHtml(s) + '</li>'; });
    html += '</ol><div class="next-steps-footer">Takıldığın adım olursa sor!</div></div>';
    addBotHtml(html);
  }

  function renderSuccess(data) {
    let html = '<div class="result-card">';
    html += '<div class="result-title">' + escapeHtml(data.title) + '</div>';
    html += '<div class="chips">';
    html += '<div class="chip primary">%' + escapeHtml(String(data.confidence)) + '</div>';
    html += '<div class="chip">' + escapeHtml(data.category) + '</div>';
    html += '</div>';
    html += '<div>' + escapeHtml(data.message) + '</div>';
    html += '<div class="actions">';
    const targetUrl = data.url + (data.url.indexOf('?') !== -1 ? '&' : '?') + 'aila_open=1';
    html += '<a class="btn btn-primary" href="' + escapeHtml(targetUrl) + '" data-title="' + escapeHtml(data.title) + '" data-steps="' + escapeHtml(JSON.stringify(data.next_steps || [])) + '">Sayfaya Git →</a>';
    if (data.source && !['WordPress Özelleştirici','Keyword','Gemini AI','Groq AI','Ai-la'].includes(data.source)) {
      html += '<span class="plugin-note">⚠ ' + escapeHtml(data.source) + ' kurulu değilse bu sayfa açılmayabilir.</span>';
    }
    html += '</div></div>';
    addBotHtml(html);
  }

  function renderFailure(data) {
    let html = '<div>' + escapeHtml(data.message || 'Bir hata oluştu.') + '</div>';
    if (Array.isArray(data.suggestions) && data.suggestions.length) {
      html += '<div class="quick-row">';
      data.suggestions.forEach(item => {
        html += '<button class="quick" type="button" data-query="' + escapeHtml(item) + '">' + escapeHtml(item) + '</button>';
      });
      html += '</div>';
    }
    addBotHtml(html);
  }

  function sendQuery(query) {
    if (!query) return;
    addUserMessage(query);
    prompt.value = '';
    prompt.style.height = 'auto';
    typingRow.style.display = 'flex';
    messages.scrollTop = messages.scrollHeight;

    const body = new URLSearchParams();
    body.append('action', 'aila_query');
    body.append('nonce', ailaData.nonce);
    body.append('query', query);
    body.append('current_url', window.location.href);
    body.append('current_page', document.title);

    fetch(ailaData.ajaxUrl, {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
      body: body.toString()
    })
    .then(r => r.json())
    .then(data => {
      typingRow.style.display = 'none';
      data.success ? renderSuccess(data) : renderFailure(data);
    })
    .catch(() => {
      typingRow.style.display = 'none';
      renderFailure({message: 'Bir hata oluştu. Lütfen tekrar deneyin.'});
    });
  }

  // Geçmişi yükle
  loadHistory();

  // Minimize durumunu kontrol et
  const wasMinimized = localStorage.getItem(MIN_KEY) === '1';
  if (wasMinimized) {
    overlay.classList.add('hidden');
    launcher.classList.add('visible');
  }

  // aila_open=1 parametresi
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('aila_open') === '1') {
    openPanel();
    const next = popNextSteps();
    if (next && next.steps && next.steps.length) {
      renderNextSteps(next.title, next.steps);
    } else {
      const hasPrev = messages.querySelectorAll('.dynamic').length > 0;
      if (hasPrev) {
        addBotHtml('<div>Seni buraya getirdim. Devam etmek için bir sonraki adımı sor!</div>');
      }
    }
    const cleanUrl = window.location.pathname + window.location.search.replace(/[?&]aila_open=1/, '').replace(/^&/, '?').replace(/\?$/, '');
    window.history.replaceState({}, '', cleanUrl || window.location.pathname);
  }

  // Textarea auto-resize
  prompt.addEventListener('input', () => {
    prompt.style.height = 'auto';
    prompt.style.height = Math.min(prompt.scrollHeight, 100) + 'px';
  });

  // Event listeners
  launcher.addEventListener('click', openPanel);
  closeBtn.addEventListener('click', minimizePanel);
  if (newChatBtn) newChatBtn.addEventListener('click', resetChat);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') minimizePanel(); });
  sendBtn.addEventListener('click', () => sendQuery(prompt.value.trim()));
  prompt.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendQuery(prompt.value.trim()); }
  });

  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-steps]');
    if (btn && btn.dataset.steps) {
      try {
        const steps = JSON.parse(btn.dataset.steps);
        const title = btn.dataset.title || '';
        if (steps.length) saveNextSteps(title, steps);
      } catch(err) {}
    }
    const quick = e.target.closest('.quick');
    if (quick && quick.dataset.query) sendQuery(quick.dataset.query);
  });
})();
